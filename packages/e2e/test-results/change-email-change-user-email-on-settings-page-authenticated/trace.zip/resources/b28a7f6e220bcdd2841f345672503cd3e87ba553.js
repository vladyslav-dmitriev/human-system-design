(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_08t000r._.css","static/chunks/06ux_next_dist_1vjm8jw._.js"],
    source: "dynamic"
});
