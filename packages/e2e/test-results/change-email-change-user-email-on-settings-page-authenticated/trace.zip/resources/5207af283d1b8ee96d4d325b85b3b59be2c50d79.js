(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/packages_i18n_src_messages_0n2p5dy._.js","static/chunks/_1p4tdbu._.js","static/chunks/06ux_next_1z5-p17._.js","static/chunks/1hn7_tailwind-merge_dist_bundle-mjs_mjs_04a_myf._.js","static/chunks/0fru_@radix-ui_react-select_dist_index_mjs_08e633s._.js","static/chunks/node_modules__pnpm_19qrx4k._.js"],
    source: "dynamic"
});
