(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_001txva._.js","static/chunks/node_modules__pnpm_0gd6e4v._.js"],
    source: "dynamic"
});
