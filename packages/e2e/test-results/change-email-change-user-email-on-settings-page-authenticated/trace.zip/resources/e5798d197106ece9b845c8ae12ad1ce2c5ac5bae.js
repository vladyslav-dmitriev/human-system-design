(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/i18n/src/messages/en/common.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_en_common_json_[json]_cjs_1tqqeul._.js",
  "static/chunks/packages_i18n_src_messages_en_common_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/en/common.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/uk/common.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_uk_common_json_[json]_cjs_0n3dmyj._.js",
  "static/chunks/packages_i18n_src_messages_uk_common_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/uk/common.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/en/profile.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_en_profile_json_[json]_cjs_1aby-d6._.js",
  "static/chunks/packages_i18n_src_messages_en_profile_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/en/profile.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/uk/profile.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_uk_profile_json_[json]_cjs_1rwczjd._.js",
  "static/chunks/packages_i18n_src_messages_uk_profile_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/uk/profile.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/en/auth.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_en_auth_json_[json]_cjs_0r-nalk._.js",
  "static/chunks/packages_i18n_src_messages_en_auth_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/en/auth.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/uk/auth.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_uk_auth_json_[json]_cjs_1y54612._.js",
  "static/chunks/packages_i18n_src_messages_uk_auth_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/uk/auth.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/en/todo.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_en_todo_json_[json]_cjs_1tjelom._.js",
  "static/chunks/packages_i18n_src_messages_en_todo_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/en/todo.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/uk/todo.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_uk_todo_json_[json]_cjs_0voaqx3._.js",
  "static/chunks/packages_i18n_src_messages_uk_todo_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/uk/todo.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/en/pricing.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_en_pricing_json_[json]_cjs_1c_zibj._.js",
  "static/chunks/packages_i18n_src_messages_en_pricing_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/en/pricing.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/uk/pricing.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_uk_pricing_json_[json]_cjs_0f8qo7h._.js",
  "static/chunks/packages_i18n_src_messages_uk_pricing_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/uk/pricing.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/en/checkout.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_en_checkout_json_[json]_cjs_1-06e2q._.js",
  "static/chunks/packages_i18n_src_messages_en_checkout_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/en/checkout.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
"[project]/packages/i18n/src/messages/uk/checkout.json.[json].cjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/packages_i18n_src_messages_uk_checkout_json_[json]_cjs_0k5nb2t._.js",
  "static/chunks/packages_i18n_src_messages_uk_checkout_json_[json]_cjs_1_x5z-8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/packages/i18n/src/messages/uk/checkout.json.[json].cjs [app-client] (ecmascript)");
    });
});
}),
]);