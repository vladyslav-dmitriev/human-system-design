(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_12y_zdo._.js","static/chunks/06ux_next_dist_compiled_next-devtools_index_0ers0if.js","static/chunks/06ux_next_dist_compiled_react-dom_0fo7j-h._.js","static/chunks/06ux_next_dist_compiled_react-server-dom-turbopack_1xgm-ap._.js","static/chunks/06ux_next_dist_compiled_1pq17zu._.js","static/chunks/06ux_next_dist_client_118w32_._.js","static/chunks/06ux_next_dist_1xp1mda._.js","static/chunks/0vvp_@swc_helpers_cjs_0vb02wp._.js"],
    source: "entry"
});
