(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@amplitude+analytics-connector@1.6.4/node_modules/@amplitude/analytics-connector/dist/analytics-connector.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnalyticsConnector",
    ()=>AnalyticsConnector
]);
var ApplicationContextProviderImpl = function() {
    function ApplicationContextProviderImpl() {}
    ApplicationContextProviderImpl.prototype.getApplicationContext = function() {
        return {
            versionName: this.versionName,
            language: getLanguage(),
            platform: 'Web',
            os: undefined,
            deviceModel: undefined
        };
    };
    return ApplicationContextProviderImpl;
}();
var getLanguage = function() {
    return typeof navigator !== 'undefined' && (navigator.languages && navigator.languages[0] || navigator.language) || '';
};
var EventBridgeImpl = function() {
    function EventBridgeImpl() {
        this.queue = [];
    }
    EventBridgeImpl.prototype.logEvent = function(event) {
        if (!this.receiver) {
            if (this.queue.length < 512) {
                this.queue.push(event);
            }
        } else {
            this.receiver(event);
        }
    };
    EventBridgeImpl.prototype.setEventReceiver = function(receiver) {
        this.receiver = receiver;
        if (this.queue.length > 0) {
            this.queue.forEach(function(event) {
                receiver(event);
            });
            this.queue = [];
        }
    };
    return EventBridgeImpl;
}();
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function() {
            if (o && i >= o.length) o = void 0;
            return {
                value: o && o[i++],
                done: !o
            };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while((n === void 0 || n-- > 0) && !(r = i.next()).done)ar.push(r.value);
    } catch (error) {
        e = {
            error: error
        };
    } finally{
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally{
            if (e) throw e.error;
        }
    }
    return ar;
}
typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
var isEqual = function(obj1, obj2) {
    var e_1, _a;
    var primitive = [
        'string',
        'number',
        'boolean',
        'undefined'
    ];
    var typeA = typeof obj1;
    var typeB = typeof obj2;
    if (typeA !== typeB) {
        return false;
    }
    try {
        for(var primitive_1 = __values(primitive), primitive_1_1 = primitive_1.next(); !primitive_1_1.done; primitive_1_1 = primitive_1.next()){
            var p = primitive_1_1.value;
            if (p === typeA) {
                return obj1 === obj2;
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (primitive_1_1 && !primitive_1_1.done && (_a = primitive_1.return)) _a.call(primitive_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    // check null
    if (obj1 == null && obj2 == null) {
        return true;
    } else if (obj1 == null || obj2 == null) {
        return false;
    }
    // if got here - objects
    if (obj1.length !== obj2.length) {
        return false;
    }
    //check if arrays
    var isArrayA = Array.isArray(obj1);
    var isArrayB = Array.isArray(obj2);
    if (isArrayA !== isArrayB) {
        return false;
    }
    if (isArrayA && isArrayB) {
        //arrays
        for(var i = 0; i < obj1.length; i++){
            if (!isEqual(obj1[i], obj2[i])) {
                return false;
            }
        }
    } else {
        //objects
        var sorted1 = Object.keys(obj1).sort();
        var sorted2 = Object.keys(obj2).sort();
        if (!isEqual(sorted1, sorted2)) {
            return false;
        }
        //compare object values
        var result_1 = true;
        Object.keys(obj1).forEach(function(key) {
            if (!isEqual(obj1[key], obj2[key])) {
                result_1 = false;
            }
        });
        return result_1;
    }
    return true;
};
var ID_OP_SET = '$set';
var ID_OP_UNSET = '$unset';
var ID_OP_CLEAR_ALL = '$clearAll';
// Polyfill for Object.entries
if (!Object.entries) {
    Object.entries = function(obj) {
        var ownProps = Object.keys(obj);
        var i = ownProps.length;
        var resArray = new Array(i);
        while(i--){
            resArray[i] = [
                ownProps[i],
                obj[ownProps[i]]
            ];
        }
        return resArray;
    };
}
var IdentityStoreImpl = function() {
    function IdentityStoreImpl() {
        this.identity = {
            userProperties: {}
        };
        this.listeners = new Set();
    }
    IdentityStoreImpl.prototype.editIdentity = function() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        var self = this;
        var actingUserProperties = __assign({}, this.identity.userProperties);
        var actingIdentity = __assign(__assign({}, this.identity), {
            userProperties: actingUserProperties
        });
        return {
            setUserId: function(userId) {
                actingIdentity.userId = userId;
                return this;
            },
            setDeviceId: function(deviceId) {
                actingIdentity.deviceId = deviceId;
                return this;
            },
            setUserProperties: function(userProperties) {
                actingIdentity.userProperties = userProperties;
                return this;
            },
            setOptOut: function(optOut) {
                actingIdentity.optOut = optOut;
                return this;
            },
            updateUserProperties: function(actions) {
                var e_1, _a, e_2, _b, e_3, _c;
                var actingProperties = actingIdentity.userProperties || {};
                try {
                    for(var _d = __values(Object.entries(actions)), _e = _d.next(); !_e.done; _e = _d.next()){
                        var _f = __read(_e.value, 2), action = _f[0], properties = _f[1];
                        switch(action){
                            case ID_OP_SET:
                                try {
                                    for(var _g = (e_2 = void 0, __values(Object.entries(properties))), _h = _g.next(); !_h.done; _h = _g.next()){
                                        var _j = __read(_h.value, 2), key = _j[0], value = _j[1];
                                        actingProperties[key] = value;
                                    }
                                } catch (e_2_1) {
                                    e_2 = {
                                        error: e_2_1
                                    };
                                } finally{
                                    try {
                                        if (_h && !_h.done && (_b = _g.return)) _b.call(_g);
                                    } finally{
                                        if (e_2) throw e_2.error;
                                    }
                                }
                                break;
                            case ID_OP_UNSET:
                                try {
                                    for(var _k = (e_3 = void 0, __values(Object.keys(properties))), _l = _k.next(); !_l.done; _l = _k.next()){
                                        var key = _l.value;
                                        delete actingProperties[key];
                                    }
                                } catch (e_3_1) {
                                    e_3 = {
                                        error: e_3_1
                                    };
                                } finally{
                                    try {
                                        if (_l && !_l.done && (_c = _k.return)) _c.call(_k);
                                    } finally{
                                        if (e_3) throw e_3.error;
                                    }
                                }
                                break;
                            case ID_OP_CLEAR_ALL:
                                actingProperties = {};
                                break;
                        }
                    }
                } catch (e_1_1) {
                    e_1 = {
                        error: e_1_1
                    };
                } finally{
                    try {
                        if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
                    } finally{
                        if (e_1) throw e_1.error;
                    }
                }
                actingIdentity.userProperties = actingProperties;
                return this;
            },
            commit: function() {
                self.setIdentity(actingIdentity);
                return this;
            }
        };
    };
    IdentityStoreImpl.prototype.getIdentity = function() {
        return __assign({}, this.identity);
    };
    IdentityStoreImpl.prototype.setIdentity = function(identity) {
        var originalIdentity = __assign({}, this.identity);
        this.identity = __assign({}, identity);
        if (!isEqual(originalIdentity, this.identity)) {
            this.listeners.forEach(function(listener) {
                listener(identity);
            });
        }
    };
    IdentityStoreImpl.prototype.addIdentityListener = function(listener) {
        this.listeners.add(listener);
    };
    IdentityStoreImpl.prototype.removeIdentityListener = function(listener) {
        this.listeners.delete(listener);
    };
    return IdentityStoreImpl;
}();
var safeGlobal = typeof globalThis !== 'undefined' ? globalThis : ("TURBOPACK compile-time truthy", 1) ? /*TURBOPACK member replacement*/ __turbopack_context__.g : "TURBOPACK unreachable";
var AnalyticsConnector = function() {
    function AnalyticsConnector() {
        this.identityStore = new IdentityStoreImpl();
        this.eventBridge = new EventBridgeImpl();
        this.applicationContextProvider = new ApplicationContextProviderImpl();
    }
    AnalyticsConnector.getInstance = function(instanceName) {
        if (!safeGlobal['analyticsConnectorInstances']) {
            safeGlobal['analyticsConnectorInstances'] = {};
        }
        if (!safeGlobal['analyticsConnectorInstances'][instanceName]) {
            safeGlobal['analyticsConnectorInstances'][instanceName] = new AnalyticsConnector();
        }
        return safeGlobal['analyticsConnectorInstances'][instanceName];
    };
    return AnalyticsConnector;
}();
;
}),
"[project]/node_modules/.pnpm/safe-json-stringify@1.2.0/node_modules/safe-json-stringify/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var hasProp = Object.prototype.hasOwnProperty;
function throwsMessage(err) {
    return '[Throws: ' + (err ? err.message : '?') + ']';
}
function safeGetValueFromPropertyOnObject(obj, property) {
    if (hasProp.call(obj, property)) {
        try {
            return obj[property];
        } catch (err) {
            return throwsMessage(err);
        }
    }
    return obj[property];
}
function ensureProperties(obj) {
    var seen = []; // store references to objects we have seen before
    function visit(obj) {
        if (obj === null || typeof obj !== 'object') {
            return obj;
        }
        if (seen.indexOf(obj) !== -1) {
            return '[Circular]';
        }
        seen.push(obj);
        if (typeof obj.toJSON === 'function') {
            try {
                var fResult = visit(obj.toJSON());
                seen.pop();
                return fResult;
            } catch (err) {
                return throwsMessage(err);
            }
        }
        if (Array.isArray(obj)) {
            var aResult = obj.map(visit);
            seen.pop();
            return aResult;
        }
        var result = Object.keys(obj).reduce(function(result, prop) {
            // prevent faulty defined getter properties
            result[prop] = visit(safeGetValueFromPropertyOnObject(obj, prop));
            return result;
        }, {});
        seen.pop();
        return result;
    }
    ;
    return visit(obj);
}
module.exports = function(data, replacer, space) {
    return JSON.stringify(ensureProperties(data), replacer, space);
};
module.exports.ensureProperties = ensureProperties;
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-page-view-tracking-browser@2.11.1/node_modules/@amplitude/plugin-page-view-tracking-browser/lib/esm/page-view-tracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PAGE_VIEW_SESSION_STORAGE_KEY",
    ()=>PAGE_VIEW_SESSION_STORAGE_KEY,
    "defaultPageViewEvent",
    ()=>defaultPageViewEvent,
    "pageViewTrackingPlugin",
    ()=>pageViewTrackingPlugin,
    "shouldTrackHistoryPageView",
    ()=>shouldTrackHistoryPageView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$campaign$2f$campaign$2d$parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/campaign/campaign-parser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/browser-storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$omit$2d$undefined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/omit-undefined.js [app-client] (ecmascript)");
;
;
var defaultPageViewEvent = '[Amplitude] Page Viewed';
var PAGE_VIEW_SESSION_STORAGE_KEY = 'AMP_PAGE_VIEW';
var pageViewTrackingPlugin = function(options) {
    if (options === void 0) {
        options = {};
    }
    var amplitude;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    var loggerProvider = undefined;
    var isTracking = false;
    var localConfig;
    var sessionStorage;
    var trackOn = options.trackOn, trackHistoryChanges = options.trackHistoryChanges, _a = options.eventType, eventType = _a === void 0 ? defaultPageViewEvent : _a;
    var getDecodeURI = function(locationStr) {
        var decodedLocationStr = locationStr;
        try {
            decodedLocationStr = decodeURI(locationStr);
        } catch (e) {
            /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error('Malformed URI sequence: ', e);
        }
        return decodedLocationStr;
    };
    var createPageViewEvent = function(pageViewId) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var locationHREF, _a;
            var _b;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_c) {
                switch(_c.label){
                    case 0:
                        locationHREF = getDecodeURI(typeof location !== 'undefined' && location.href || '');
                        _b = {
                            event_type: eventType
                        };
                        _a = [
                            {}
                        ];
                        return [
                            4 /*yield*/ ,
                            getCampaignParams()
                        ];
                    case 1:
                        return [
                            2 /*return*/ ,
                            (_b.event_properties = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"].apply(void 0, [
                                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"].apply(void 0, _a.concat([
                                    _c.sent()
                                ])),
                                {
                                    '[Amplitude] Page Domain': /* istanbul ignore next */ typeof location !== 'undefined' && location.hostname || '',
                                    '[Amplitude] Page Location': locationHREF,
                                    '[Amplitude] Page Path': /* istanbul ignore next */ typeof location !== 'undefined' && getDecodeURI(location.pathname) || '',
                                    '[Amplitude] Page Title': /* istanbul ignore next */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageTitle"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceSensitiveString"]),
                                    '[Amplitude] Page URL': locationHREF.split('?')[0],
                                    '[Amplitude] Page View ID': pageViewId
                                }
                            ]), _b)
                        ];
                }
            });
        });
    };
    var shouldTrackOnPageLoad = function() {
        return typeof trackOn === 'undefined' || typeof trackOn === 'function' && trackOn();
    };
    /* istanbul ignore next */ var previousURL = typeof location !== 'undefined' ? location.href : null;
    var trackHistoryPageView = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var newURL, shouldTrackPageView, pageViewId, _a, _b, _c;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_d) {
                switch(_d.label){
                    case 0:
                        newURL = location.href;
                        shouldTrackPageView = shouldTrackHistoryPageView(trackHistoryChanges, newURL, previousURL || '') && shouldTrackOnPageLoad();
                        // Note: Update `previousURL` in the same clock tick as `shouldTrackHistoryPageView()`
                        // This was previously done after `amplitude?.track(await createPageViewEvent());` and
                        // causes a concurrency issue where app triggers `pushState` twice with the same URL target
                        // but `previousURL` is only updated after the second `pushState` producing two page viewed events
                        previousURL = newURL;
                        if (!shouldTrackPageView) return [
                            3 /*break*/ ,
                            4
                        ];
                        pageViewId = void 0;
                        if (sessionStorage) {
                            pageViewId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
                            void sessionStorage.set(PAGE_VIEW_SESSION_STORAGE_KEY, {
                                pageViewId: pageViewId
                            });
                        }
                        /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.log('Tracking page view event');
                        if (!(amplitude === null || amplitude === void 0)) return [
                            3 /*break*/ ,
                            1
                        ];
                        _a = void 0;
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 1:
                        _c = (_b = amplitude).track;
                        return [
                            4 /*yield*/ ,
                            createPageViewEvent(pageViewId)
                        ];
                    case 2:
                        _a = _c.apply(_b, [
                            _d.sent()
                        ]);
                        _d.label = 3;
                    case 3:
                        _a;
                        _d.label = 4;
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /* istanbul ignore next */ var handlePageChange = function() {
        void trackHistoryPageView();
    };
    var plugin = {
        name: '@amplitude/plugin-page-view-tracking-browser',
        type: 'enrichment',
        setup: function(config, client) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var pageViewId, _a, _b;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_c) {
                    switch(_c.label){
                        case 0:
                            amplitude = client;
                            localConfig = config;
                            loggerProvider = config.loggerProvider;
                            loggerProvider.log('Installing @amplitude/plugin-page-view-tracking-browser');
                            isTracking = true;
                            if (globalScope) {
                                // init session storage
                                try {
                                    sessionStorage = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BrowserStorage"](globalScope.sessionStorage);
                                } catch (error) {
                                    /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.debug('sessionStorage is not available in this environment.');
                                }
                                globalScope.addEventListener('popstate', handlePageChange);
                                /* istanbul ignore next */ // There is no global browser listener for changes to history, so we have
                                // to modify pushState directly.
                                // https://stackoverflow.com/a/64927639
                                // eslint-disable-next-line @typescript-eslint/unbound-method
                                globalScope.history.pushState = new Proxy(globalScope.history.pushState, {
                                    apply: function(target, thisArg, _a) {
                                        var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 3), state = _b[0], unused = _b[1], url = _b[2];
                                        target.apply(thisArg, [
                                            state,
                                            unused,
                                            url
                                        ]);
                                        if (isTracking) {
                                            handlePageChange();
                                        }
                                    }
                                });
                            }
                            if (!shouldTrackOnPageLoad()) return [
                                3 /*break*/ ,
                                2
                            ];
                            loggerProvider.log('Tracking page view event');
                            pageViewId = void 0;
                            if (sessionStorage) {
                                pageViewId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
                                void sessionStorage.set(PAGE_VIEW_SESSION_STORAGE_KEY, {
                                    pageViewId: pageViewId
                                });
                            }
                            _b = (_a = amplitude).track;
                            return [
                                4 /*yield*/ ,
                                createPageViewEvent(pageViewId)
                            ];
                        case 1:
                            _b.apply(_a, [
                                _c.sent()
                            ]);
                            _c.label = 2;
                        case 2:
                            return [
                                2 /*return*/ 
                            ];
                    }
                });
            });
        },
        execute: function(event) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var pageViewId, pageViewSession, pageViewEvent;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    switch(_a.label){
                        case 0:
                            if (!(trackOn === 'attribution' && isCampaignEvent(event))) return [
                                3 /*break*/ ,
                                4
                            ];
                            /* istanbul ignore next */ // loggerProvider should be defined by the time execute is invoked
                            loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.log('Enriching campaign event to page view event with campaign parameters');
                            pageViewId = void 0;
                            if (!sessionStorage) return [
                                3 /*break*/ ,
                                2
                            ];
                            return [
                                4 /*yield*/ ,
                                sessionStorage.get(PAGE_VIEW_SESSION_STORAGE_KEY)
                            ];
                        case 1:
                            pageViewSession = _a.sent();
                            pageViewId = pageViewSession === null || pageViewSession === void 0 ? void 0 : pageViewSession.pageViewId;
                            _a.label = 2;
                        case 2:
                            return [
                                4 /*yield*/ ,
                                createPageViewEvent(pageViewId)
                            ];
                        case 3:
                            pageViewEvent = _a.sent();
                            event.event_type = pageViewEvent.event_type;
                            event.event_properties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event.event_properties), pageViewEvent.event_properties);
                            _a.label = 4;
                        case 4:
                            // Update the pageCounter for the page view event
                            if (localConfig && event.event_type === eventType) {
                                localConfig.pageCounter = !localConfig.pageCounter ? 1 : localConfig.pageCounter + 1;
                                event.event_properties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event.event_properties), {
                                    '[Amplitude] Page Counter': localConfig.pageCounter
                                });
                            }
                            return [
                                2 /*return*/ ,
                                event
                            ];
                    }
                });
            });
        },
        teardown: function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    if (globalScope) {
                        globalScope.removeEventListener('popstate', handlePageChange);
                        isTracking = false;
                    }
                    return [
                        2 /*return*/ 
                    ];
                });
            });
        }
    };
    return plugin;
};
var getCampaignParams = function() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
            switch(_b.label){
                case 0:
                    _a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$omit$2d$undefined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omitUndefined"];
                    return [
                        4 /*yield*/ ,
                        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$campaign$2f$campaign$2d$parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CampaignParser"]().parse()
                    ];
                case 1:
                    return [
                        2 /*return*/ ,
                        _a.apply(void 0, [
                            _b.sent()
                        ])
                    ];
            }
        });
    });
};
var isCampaignEvent = function(event) {
    if (event.event_type === '$identify' && event.user_properties) {
        var properties = event.user_properties;
        var $set = properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"].SET] || {};
        var $unset = properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"].UNSET] || {};
        var userProperties_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(Object.keys($set)), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(Object.keys($unset)), false);
        return Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_CAMPAIGN"]).every(function(value) {
            return userProperties_1.includes(value);
        });
    }
    return false;
};
var shouldTrackHistoryPageView = function(trackingOption, newURLStr, oldURLStr) {
    switch(trackingOption){
        case 'pathOnly':
            {
                if (oldURLStr == '') return true;
                var newURL = new URL(newURLStr);
                var oldURL = new URL(oldURLStr);
                var newBaseStr = newURL.origin + newURL.pathname;
                var oldBaseStr = oldURL.origin + oldURL.pathname;
                return newBaseStr !== oldBaseStr;
            }
        default:
            return newURLStr !== oldURLStr;
    }
};
}),
"[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/lib/Observable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Observable = void 0;
// === Symbol Support ===
const hasSymbol = (name)=>Boolean(Symbol[name]);
const getSymbol = (name)=>hasSymbol(name) ? Symbol[name] : '@@' + name;
const SymbolIterator = getSymbol('iterator');
const SymbolObservable = getSymbol('observable');
const SymbolSpecies = getSymbol('species'); // === Abstract Operations ===
function getMethod(obj, key) {
    let value = obj[key];
    if (value == null) return undefined;
    if (typeof value !== 'function') throw new TypeError(value + ' is not a function');
    return value;
}
function getSpecies(obj) {
    let ctor = obj.constructor;
    if (ctor !== undefined) {
        ctor = ctor[SymbolSpecies];
        if (ctor === null) {
            ctor = undefined;
        }
    }
    return ctor !== undefined ? ctor : Observable;
}
function isObservable(x) {
    return x instanceof Observable; // SPEC: Brand check
}
function hostReportError(e) {
    if (hostReportError.log) {
        hostReportError.log(e);
    } else {
        setTimeout(()=>{
            throw e;
        });
    }
}
function enqueue(fn) {
    Promise.resolve().then(()=>{
        try {
            fn();
        } catch (e) {
            hostReportError(e);
        }
    });
}
function cleanupSubscription(subscription) {
    let cleanup = subscription._cleanup;
    if (cleanup === undefined) return;
    subscription._cleanup = undefined;
    if (!cleanup) {
        return;
    }
    try {
        if (typeof cleanup === 'function') {
            cleanup();
        } else {
            let unsubscribe = getMethod(cleanup, 'unsubscribe');
            if (unsubscribe) {
                unsubscribe.call(cleanup);
            }
        }
    } catch (e) {
        hostReportError(e);
    }
}
function closeSubscription(subscription) {
    subscription._observer = undefined;
    subscription._queue = undefined;
    subscription._state = 'closed';
}
function flushSubscription(subscription) {
    let queue = subscription._queue;
    if (!queue) {
        return;
    }
    subscription._queue = undefined;
    subscription._state = 'ready';
    for(let i = 0; i < queue.length; ++i){
        notifySubscription(subscription, queue[i].type, queue[i].value);
        if (subscription._state === 'closed') break;
    }
}
function notifySubscription(subscription, type, value) {
    subscription._state = 'running';
    let observer = subscription._observer;
    try {
        let m = getMethod(observer, type);
        switch(type){
            case 'next':
                if (m) m.call(observer, value);
                break;
            case 'error':
                closeSubscription(subscription);
                if (m) m.call(observer, value);
                else throw value;
                break;
            case 'complete':
                closeSubscription(subscription);
                if (m) m.call(observer);
                break;
        }
    } catch (e) {
        hostReportError(e);
    }
    if (subscription._state === 'closed') cleanupSubscription(subscription);
    else if (subscription._state === 'running') subscription._state = 'ready';
}
function onNotify(subscription, type, value) {
    if (subscription._state === 'closed') return;
    if (subscription._state === 'buffering') {
        subscription._queue.push({
            type,
            value
        });
        return;
    }
    if (subscription._state !== 'ready') {
        subscription._state = 'buffering';
        subscription._queue = [
            {
                type,
                value
            }
        ];
        enqueue(()=>flushSubscription(subscription));
        return;
    }
    notifySubscription(subscription, type, value);
}
class Subscription {
    constructor(observer, subscriber){
        // ASSERT: observer is an object
        // ASSERT: subscriber is callable
        this._cleanup = undefined;
        this._observer = observer;
        this._queue = undefined;
        this._state = 'initializing';
        let self = this;
        let subscriptionObserver = {
            get closed () {
                return self._state === 'closed';
            },
            next (value) {
                onNotify(self, 'next', value);
            },
            error (value) {
                onNotify(self, 'error', value);
            },
            complete () {
                onNotify(self, 'complete');
            }
        };
        try {
            this._cleanup = subscriber.call(undefined, subscriptionObserver);
        } catch (e) {
            subscriptionObserver.error(e);
        }
        if (this._state === 'initializing') this._state = 'ready';
    }
    get closed() {
        return this._state === 'closed';
    }
    unsubscribe() {
        if (this._state !== 'closed') {
            closeSubscription(this);
            cleanupSubscription(this);
        }
    }
}
class Observable {
    constructor(subscriber){
        if (!(this instanceof Observable)) throw new TypeError('Observable cannot be called as a function');
        if (typeof subscriber !== 'function') throw new TypeError('Observable initializer must be a function');
        this._subscriber = subscriber;
    }
    subscribe(observer) {
        if (typeof observer !== 'object' || observer === null) {
            observer = {
                next: observer,
                error: arguments[1],
                complete: arguments[2]
            };
        }
        return new Subscription(observer, this._subscriber);
    }
    forEach(fn) {
        return new Promise((resolve, reject)=>{
            if (typeof fn !== 'function') {
                reject(new TypeError(fn + ' is not a function'));
                return;
            }
            function done() {
                subscription.unsubscribe();
                resolve();
            }
            let subscription = this.subscribe({
                next (value) {
                    try {
                        fn(value, done);
                    } catch (e) {
                        reject(e);
                        subscription.unsubscribe();
                    }
                },
                error: reject,
                complete: resolve
            });
        });
    }
    map(fn) {
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        let C = getSpecies(this);
        return new C((observer)=>this.subscribe({
                next (value) {
                    try {
                        value = fn(value);
                    } catch (e) {
                        return observer.error(e);
                    }
                    observer.next(value);
                },
                error (e) {
                    observer.error(e);
                },
                complete () {
                    observer.complete();
                }
            }));
    }
    filter(fn) {
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        let C = getSpecies(this);
        return new C((observer)=>this.subscribe({
                next (value) {
                    try {
                        if (!fn(value)) return;
                    } catch (e) {
                        return observer.error(e);
                    }
                    observer.next(value);
                },
                error (e) {
                    observer.error(e);
                },
                complete () {
                    observer.complete();
                }
            }));
    }
    reduce(fn) {
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        let C = getSpecies(this);
        let hasSeed = arguments.length > 1;
        let hasValue = false;
        let seed = arguments[1];
        let acc = seed;
        return new C((observer)=>this.subscribe({
                next (value) {
                    let first = !hasValue;
                    hasValue = true;
                    if (!first || hasSeed) {
                        try {
                            acc = fn(acc, value);
                        } catch (e) {
                            return observer.error(e);
                        }
                    } else {
                        acc = value;
                    }
                },
                error (e) {
                    observer.error(e);
                },
                complete () {
                    if (!hasValue && !hasSeed) return observer.error(new TypeError('Cannot reduce an empty sequence'));
                    observer.next(acc);
                    observer.complete();
                }
            }));
    }
    async all() {
        let values = [];
        await this.forEach((value)=>values.push(value));
        return values;
    }
    concat(...sources) {
        let C = getSpecies(this);
        return new C((observer)=>{
            let subscription;
            let index = 0;
            function startNext(next) {
                subscription = next.subscribe({
                    next (v) {
                        observer.next(v);
                    },
                    error (e) {
                        observer.error(e);
                    },
                    complete () {
                        if (index === sources.length) {
                            subscription = undefined;
                            observer.complete();
                        } else {
                            startNext(C.from(sources[index++]));
                        }
                    }
                });
            }
            startNext(this);
            return ()=>{
                if (subscription) {
                    subscription.unsubscribe();
                    subscription = undefined;
                }
            };
        });
    }
    flatMap(fn) {
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        let C = getSpecies(this);
        return new C((observer)=>{
            let subscriptions = [];
            let outer = this.subscribe({
                next (value) {
                    if (fn) {
                        try {
                            value = fn(value);
                        } catch (e) {
                            return observer.error(e);
                        }
                    }
                    let inner = C.from(value).subscribe({
                        next (value) {
                            observer.next(value);
                        },
                        error (e) {
                            observer.error(e);
                        },
                        complete () {
                            let i = subscriptions.indexOf(inner);
                            if (i >= 0) subscriptions.splice(i, 1);
                            completeIfDone();
                        }
                    });
                    subscriptions.push(inner);
                },
                error (e) {
                    observer.error(e);
                },
                complete () {
                    completeIfDone();
                }
            });
            function completeIfDone() {
                if (outer.closed && subscriptions.length === 0) observer.complete();
            }
            return ()=>{
                subscriptions.forEach((s)=>s.unsubscribe());
                outer.unsubscribe();
            };
        });
    }
    [SymbolObservable]() {
        return this;
    }
    static from(x) {
        let C = typeof this === 'function' ? this : Observable;
        if (x == null) throw new TypeError(x + ' is not an object');
        let method = getMethod(x, SymbolObservable);
        if (method) {
            let observable = method.call(x);
            if (Object(observable) !== observable) throw new TypeError(observable + ' is not an object');
            if (isObservable(observable) && observable.constructor === C) return observable;
            return new C((observer)=>observable.subscribe(observer));
        }
        if (hasSymbol('iterator')) {
            method = getMethod(x, SymbolIterator);
            if (method) {
                return new C((observer)=>{
                    enqueue(()=>{
                        if (observer.closed) return;
                        for (let item of method.call(x)){
                            observer.next(item);
                            if (observer.closed) return;
                        }
                        observer.complete();
                    });
                });
            }
        }
        if (Array.isArray(x)) {
            return new C((observer)=>{
                enqueue(()=>{
                    if (observer.closed) return;
                    for(let i = 0; i < x.length; ++i){
                        observer.next(x[i]);
                        if (observer.closed) return;
                    }
                    observer.complete();
                });
            });
        }
        throw new TypeError(x + ' is not observable');
    }
    static of(...items) {
        let C = typeof this === 'function' ? this : Observable;
        return new C((observer)=>{
            enqueue(()=>{
                if (observer.closed) return;
                for(let i = 0; i < items.length; ++i){
                    observer.next(items[i]);
                    if (observer.closed) return;
                }
                observer.complete();
            });
        });
    }
    static get [SymbolSpecies]() {
        return this;
    }
}
exports.Observable = Observable;
Object.defineProperty(Observable, Symbol('extensions'), {
    value: {
        symbol: SymbolObservable,
        hostReportError
    },
    configurable: true
});
}),
"[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/lib/Observable.js [app-client] (ecmascript)").Observable;
}),
"[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript) <export default as Observable>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Observable",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AMPLITUDE_NETWORK_REQUEST_EVENT",
    ()=>AMPLITUDE_NETWORK_REQUEST_EVENT,
    "IS_HEADER_CAPTURE_EXPERIMENTAL",
    ()=>IS_HEADER_CAPTURE_EXPERIMENTAL,
    "PLUGIN_NAME",
    ()=>PLUGIN_NAME
]);
var PLUGIN_NAME = '@amplitude/plugin-network-capture-browser';
var AMPLITUDE_NETWORK_REQUEST_EVENT = '[Amplitude] Network Request';
var IS_HEADER_CAPTURE_EXPERIMENTAL = true;
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/track-network-event.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "logNetworkAnalyticsEvent",
    ()=>logNetworkAnalyticsEvent,
    "parseHeaderCaptureRule",
    ()=>parseHeaderCaptureRule,
    "shouldTrackNetworkEvent",
    ()=>shouldTrackNetworkEvent,
    "trackNetworkEvents",
    ()=>trackNetworkEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/constants.js [app-client] (ecmascript)");
;
;
;
var DEFAULT_STATUS_CODE_RANGE = '500-599';
function wildcardMatch(str, pattern) {
    // Escape all regex special characters except for *
    var escapedPattern = pattern.replace(/[-[\]{}()+?.,\\^$|#\s]/g, '\\$&');
    // Replace * with .*
    var regexPattern = '^' + escapedPattern.replace(/\*/g, '.*') + '$';
    var regex = new RegExp(regexPattern);
    return regex.test(str);
}
function isStatusCodeInRange(statusCode, range) {
    var e_1, _a;
    var ranges = range.split(',');
    try {
        for(var ranges_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(ranges), ranges_1_1 = ranges_1.next(); !ranges_1_1.done; ranges_1_1 = ranges_1.next()){
            var r = ranges_1_1.value;
            var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(r.split('-').map(Number), 2), start = _b[0], end = _b[1];
            if (statusCode === start && end === undefined) {
                return true;
            }
            if (statusCode >= start && statusCode <= end) {
                return true;
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (ranges_1_1 && !ranges_1_1.done && (_a = ranges_1.return)) _a.call(ranges_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    return false;
}
function isCaptureRuleMatch(rule, hostname, status, url, method) {
    // check if the host is in the allowed hosts
    if (rule.hosts && !rule.hosts.find(function(host) {
        return wildcardMatch(hostname, host);
    })) {
        return;
    }
    // check if the URL is in the allowed URL patterns
    if (url && rule.urls && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUrlMatchAllowlist"])(url, rule.urls)) {
        return;
    }
    // check if the method is in the allowed methods
    if (method && rule.methods && !rule.methods.find(function(allowedMethod) {
        return method.toLowerCase() === allowedMethod.toLowerCase() || allowedMethod === '*';
    })) {
        return;
    }
    // check if the status code is in the allowed range
    if (status || status === 0) {
        var statusCodeRange = rule.statusCodeRange || DEFAULT_STATUS_CODE_RANGE;
        if (!isStatusCodeInRange(status, statusCodeRange)) {
            return false;
        }
    }
    return true;
}
function parseUrl(url) {
    var _a;
    if (!url) {
        return;
    }
    try {
        /* istanbul ignore next */ var currentHref = (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.location.href;
        var urlObj = new URL(url, currentHref);
        var query = urlObj.searchParams.toString();
        var fragment = urlObj.hash.replace('#', '');
        var href = urlObj.href;
        var host = urlObj.host;
        urlObj.hash = '';
        urlObj.search = '';
        var hrefWithoutQueryOrHash = urlObj.href;
        return {
            query: query,
            fragment: fragment,
            href: href,
            hrefWithoutQueryOrHash: hrefWithoutQueryOrHash,
            host: host
        };
    } catch (e) {
        /* istanbul ignore next */ return;
    }
}
function isAmplitudeNetworkRequestEvent(host, requestWrapper) {
    if (host.includes('amplitude.com')) {
        try {
            var body = requestWrapper.body;
            if (typeof body !== 'string') {
                return false;
            }
            var bodyObj = JSON.parse(body);
            var events = bodyObj.events;
            /* eslint-disable-next-line @typescript-eslint/no-unsafe-member-access */ if (events.find(function(event) {
                return event.event_type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_NETWORK_REQUEST_EVENT"];
            })) {
                return true;
            }
        } catch (e) {
        // do nothing
        }
    }
    return false;
}
function parseHeaderCaptureRule(rule) {
    if (typeof rule !== 'object' || rule === null) {
        // if rule is truthy or undefined, return SAFE_HEADERS
        if (rule) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAFE_HEADERS"]), false);
        } else if (rule === undefined) {
            /* istanbul ignore next */ var res = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IS_HEADER_CAPTURE_EXPERIMENTAL"] ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAFE_HEADERS"]), false);
            return res;
        }
        return;
    }
    // if the rule is defined but empty, return undefined
    if (rule.length === 0) {
        return;
    }
    return rule;
}
function isBodyCaptureRuleEmpty(rule) {
    var _a, _b, _c;
    /* istanbul ignore next */ return !((_a = rule === null || rule === void 0 ? void 0 : rule.allowlist) === null || _a === void 0 ? void 0 : _a.length) && !((_b = rule === null || rule === void 0 ? void 0 : rule.blocklist) === null || _b === void 0 ? void 0 : _b.length) && !((_c = rule === null || rule === void 0 ? void 0 : rule.excludelist) === null || _c === void 0 ? void 0 : _c.length);
}
function shouldTrackNetworkEvent(networkEvent, options) {
    var _a;
    if (options === void 0) {
        options = {};
    }
    var urlObj = parseUrl(networkEvent.url);
    /* istanbul ignore if */ if (!urlObj) {
        // if the URL failed to parse, do not track the event
        // this is a probably impossible case that would only happen if the URL is malformed
        /* istanbul ignore next */ return false;
    }
    var host = urlObj.host;
    // false if is amplitude request and not configured to track amplitude requests
    if (options.ignoreAmplitudeRequests !== false && (wildcardMatch(host, '*.amplitude.com') || wildcardMatch(host, 'amplitude.com'))) {
        return false;
    }
    // false if the host is in the ignore list
    if ((_a = options.ignoreHosts) === null || _a === void 0 ? void 0 : _a.find(function(ignoreHost) {
        return wildcardMatch(host, ignoreHost);
    })) {
        return false;
    }
    // false if the status code is not 500-599 and there are no captureRules
    if (!options.captureRules && networkEvent.status !== undefined && !isStatusCodeInRange(networkEvent.status, DEFAULT_STATUS_CODE_RANGE)) {
        return false;
    }
    if (options.captureRules) {
        // find the first capture rule, in reverse-order,
        // that is a match (true) or a miss (false)
        var isMatch_1;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(options.captureRules), false).reverse().find(function(rule) {
            isMatch_1 = isCaptureRuleMatch(rule, host, networkEvent.status, networkEvent.url, networkEvent.method);
            if (isMatch_1) {
                var responseHeadersRule = parseHeaderCaptureRule(rule.responseHeaders);
                if (networkEvent.responseWrapper && responseHeadersRule) {
                    var responseHeaders = networkEvent.responseWrapper.headers(responseHeadersRule);
                    if (responseHeaders) {
                        networkEvent.responseHeaders = responseHeaders;
                    }
                }
                // if requestHeaders rule is specified, enrich the event with the request headers
                var requestHeadersRule = parseHeaderCaptureRule(rule.requestHeaders);
                if (networkEvent.requestWrapper && requestHeadersRule) {
                    var requestHeaders = networkEvent.requestWrapper.headers(requestHeadersRule);
                    if (requestHeaders) {
                        networkEvent.requestHeaders = requestHeaders;
                    }
                }
                // if responseBody rule is specified, enrich the event with the response body
                if (networkEvent.responseWrapper && rule.responseBody && !isBodyCaptureRuleEmpty(rule.responseBody)) {
                    var excludelist = rule.responseBody.excludelist || rule.responseBody.blocklist;
                    networkEvent.responseBodyJson = networkEvent.responseWrapper.json(rule.responseBody.allowlist, excludelist);
                }
                // if requestBody rule is specified, enrich the event with the request body
                if (networkEvent.requestWrapper && rule.requestBody && !isBodyCaptureRuleEmpty(rule.requestBody)) {
                    var excludelist = rule.requestBody.excludelist || rule.requestBody.blocklist;
                    networkEvent.requestBodyJson = networkEvent.requestWrapper.json(rule.requestBody.allowlist, excludelist);
                }
            }
            return isMatch_1 !== undefined;
        });
        // if we found a miss (false) or no match (undefined),
        // then do not track the event
        if (!isMatch_1) {
            return false;
        }
    }
    // skip Amplitude network requests to "[Amplitude] Network Request" to avoid infinite loop
    if (networkEvent.requestWrapper && isAmplitudeNetworkRequestEvent(host, networkEvent.requestWrapper)) {
        return false;
    }
    return true;
}
function logNetworkAnalyticsEvent(networkAnalyticsEvent, request, amplitude, loggerProvider) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
        var _a, requestBody, responseBody;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
            switch(_b.label){
                case 0:
                    if (!(request.requestBodyJson || request.responseBodyJson)) return [
                        3 /*break*/ ,
                        2
                    ];
                    return [
                        4 /*yield*/ ,
                        Promise.all([
                            request.requestBodyJson,
                            request.responseBodyJson
                        ])
                    ];
                case 1:
                    _a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"].apply(void 0, [
                        _b.sent(),
                        2
                    ]), requestBody = _a[0], responseBody = _a[1];
                    if (requestBody) {
                        try {
                            networkAnalyticsEvent['[Amplitude] Request Body'] = JSON.stringify(requestBody);
                        } catch (e) {
                            /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.debug('Failed to stringify request body', e);
                        }
                    }
                    if (responseBody) {
                        try {
                            networkAnalyticsEvent['[Amplitude] Response Body'] = JSON.stringify(responseBody);
                        } catch (e) {
                            /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.debug('Failed to stringify response body');
                        }
                    }
                    _b.label = 2;
                case 2:
                    /* istanbul ignore next */ amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_NETWORK_REQUEST_EVENT"], networkAnalyticsEvent);
                    return [
                        2 /*return*/ 
                    ];
            }
        });
    });
}
function trackNetworkEvents(_a) {
    var allObservables = _a.allObservables, networkTrackingOptions = _a.networkTrackingOptions, amplitude = _a.amplitude, loggerProvider = _a.loggerProvider;
    var networkObservable = allObservables.networkObservable;
    var filteredNetworkObservable = networkObservable.filter(function(event) {
        // Only track network events that should be tracked
        return shouldTrackNetworkEvent(event.event, networkTrackingOptions);
    });
    return filteredNetworkObservable.subscribe(function(networkEvent) {
        var _a;
        var _b, _c;
        var request = networkEvent.event;
        // convert to NetworkAnalyticsEvent
        var urlObj = parseUrl(request.url);
        /* istanbul ignore if */ if (!urlObj) {
            // if the URL failed to parse, do not track the event
            // this is a very unlikely case, because URL() shouldn't throw an exception
            // when the URL is a valid URL
            /* istanbul ignore next */ return;
        }
        var responseBodySize = (_b = request.responseWrapper) === null || _b === void 0 ? void 0 : _b.bodySize;
        /* istanbul ignore next */ var requestBodySize = (_c = request.requestWrapper) === null || _c === void 0 ? void 0 : _c.bodySize;
        var networkAnalyticsEvent = (_a = {}, _a['[Amplitude] URL'] = urlObj.hrefWithoutQueryOrHash, _a['[Amplitude] URL Query'] = urlObj.query, _a['[Amplitude] URL Fragment'] = urlObj.fragment, _a['[Amplitude] Request Method'] = request.method, _a['[Amplitude] Status Code'] = request.status, _a['[Amplitude] Start Time'] = request.startTime, _a['[Amplitude] Completion Time'] = request.endTime, _a['[Amplitude] Duration'] = request.duration, _a['[Amplitude] Request Body Size'] = requestBodySize, _a['[Amplitude] Response Body Size'] = responseBodySize, _a['[Amplitude] Request Type'] = request.type, _a['[Amplitude] Request Headers'] = request.requestHeaders, _a['[Amplitude] Response Headers'] = request.responseHeaders, _a);
        // fire-and-forget promise that tracks the event
        void logNetworkAnalyticsEvent(networkAnalyticsEvent, request, amplitude, loggerProvider);
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/network-capture-plugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ObservablesEnum",
    ()=>ObservablesEnum,
    "networkCapturePlugin",
    ()=>networkCapturePlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$network$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/observers/network.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript) <export default as Observable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$track$2d$network$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/track-network-event.js [app-client] (ecmascript)");
;
;
;
;
;
var ObservablesEnum;
(function(ObservablesEnum) {
    ObservablesEnum["NetworkObservable"] = "networkObservable";
})(ObservablesEnum || (ObservablesEnum = {}));
var subscription;
var networkCapturePlugin = function(options) {
    if (options === void 0) {
        options = {};
    }
    var name = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLUGIN_NAME"];
    var type = 'enrichment';
    var logger;
    var addAdditionalEventProperties = function(event, type) {
        var baseEvent = {
            event: event,
            timestamp: Date.now(),
            type: type
        };
        return baseEvent;
    };
    // Create observables on events on the window
    var createObservables = function() {
        var _a;
        var networkObservable = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
            var callback = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$network$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NetworkEventCallback"](function(event) {
                var eventWithProperties = addAdditionalEventProperties(event, 'network');
                observer.next(eventWithProperties);
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$network$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networkObserver"].subscribe(callback, logger);
            return function() {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$network$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networkObserver"].unsubscribe(callback);
            };
        });
        return _a = {}, _a[ObservablesEnum.NetworkObservable] = networkObservable, _a;
    };
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var allObservables;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                /* istanbul ignore if */ if (typeof document === 'undefined') {
                    return [
                        2 /*return*/ 
                    ];
                }
                allObservables = createObservables();
                /* istanbul ignore next */ logger = config === null || config === void 0 ? void 0 : config.loggerProvider;
                subscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$track$2d$network$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackNetworkEvents"])({
                    allObservables: allObservables,
                    networkTrackingOptions: options,
                    amplitude: amplitude,
                    loggerProvider: logger
                });
                /* istanbul ignore next */ logger === null || logger === void 0 ? void 0 : logger.log("".concat(name, " has been successfully added."));
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    /* istanbul ignore next */ var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                subscription.unsubscribe();
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/network-capture-plugin.js [app-client] (ecmascript) <export networkCapturePlugin as plugin>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "plugin",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$network$2d$capture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networkCapturePlugin"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$network$2d$capture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/network-capture-plugin.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-web-vitals-browser@1.1.33/node_modules/@amplitude/plugin-web-vitals-browser/lib/esm/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PLUGIN_NAME",
    ()=>PLUGIN_NAME,
    "WEB_VITALS_EVENT_NAME",
    ()=>WEB_VITALS_EVENT_NAME
]);
var PLUGIN_NAME = 'web-vitals-browser';
var WEB_VITALS_EVENT_NAME = '[Amplitude] Web Vitals';
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-web-vitals-browser@1.1.33/node_modules/@amplitude/plugin-web-vitals-browser/lib/esm/web-vitals-plugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "webVitalsPlugin",
    ()=>webVitalsPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$web$2d$vitals$2d$browser$40$1$2e$1$2e$33$2f$node_modules$2f40$amplitude$2f$plugin$2d$web$2d$vitals$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-web-vitals-browser@1.1.33/node_modules/@amplitude/plugin-web-vitals-browser/lib/esm/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$web$2d$vitals$40$5$2e$1$2e$0$2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/web-vitals@5.1.0/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript)");
;
;
;
;
function getMetricStartTime(metric) {
    var _a;
    /* istanbul ignore next */ var startTime = ((_a = metric.entries[0]) === null || _a === void 0 ? void 0 : _a.startTime) || 0;
    return performance.timeOrigin + startTime;
}
function processMetric(metric) {
    return {
        value: metric.value,
        rating: metric.rating,
        delta: metric.delta,
        navigationType: metric.navigationType,
        id: metric.id,
        timestamp: Math.floor(getMetricStartTime(metric)),
        navigationStart: Math.floor(performance.timeOrigin)
    };
}
var webVitalsPlugin = function() {
    var visibilityListener = null;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    var doc = globalScope === null || globalScope === void 0 ? void 0 : globalScope.document;
    var location = globalScope === null || globalScope === void 0 ? void 0 : globalScope.location;
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var locationHref, webVitalsPayload;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (doc === undefined) {
                    return [
                        2 /*return*/ 
                    ];
                }
                locationHref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(/* istanbul ignore next */ (location === null || location === void 0 ? void 0 : location.href) || '', config.loggerProvider);
                webVitalsPayload = {
                    '[Amplitude] Page Domain': /* istanbul ignore next */ (location === null || location === void 0 ? void 0 : location.hostname) || '',
                    '[Amplitude] Page Location': locationHref,
                    '[Amplitude] Page Path': (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(/* istanbul ignore next */ (location === null || location === void 0 ? void 0 : location.pathname) || '', config.loggerProvider),
                    '[Amplitude] Page Title': /* istanbul ignore next */ typeof document !== 'undefined' && document.title || '',
                    '[Amplitude] Page URL': (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(locationHref.split('?')[0], config.loggerProvider)
                };
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$web$2d$vitals$40$5$2e$1$2e$0$2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onLCP"])(function(metric) {
                    webVitalsPayload['[Amplitude] LCP'] = processMetric(metric);
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$web$2d$vitals$40$5$2e$1$2e$0$2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onFCP"])(function(metric) {
                    webVitalsPayload['[Amplitude] FCP'] = processMetric(metric);
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$web$2d$vitals$40$5$2e$1$2e$0$2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onINP"])(function(metric) {
                    webVitalsPayload['[Amplitude] INP'] = processMetric(metric);
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$web$2d$vitals$40$5$2e$1$2e$0$2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onCLS"])(function(metric) {
                    webVitalsPayload['[Amplitude] CLS'] = processMetric(metric);
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$web$2d$vitals$40$5$2e$1$2e$0$2f$node_modules$2f$web$2d$vitals$2f$dist$2f$web$2d$vitals$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onTTFB"])(function(metric) {
                    webVitalsPayload['[Amplitude] TTFB'] = processMetric(metric);
                });
                visibilityListener = function() {
                    if (doc.visibilityState === 'hidden' && visibilityListener) {
                        amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$web$2d$vitals$2d$browser$40$1$2e$1$2e$33$2f$node_modules$2f40$amplitude$2f$plugin$2d$web$2d$vitals$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEB_VITALS_EVENT_NAME"], webVitalsPayload);
                        doc.removeEventListener('visibilitychange', visibilityListener);
                        visibilityListener = null;
                    }
                };
                doc.addEventListener('visibilitychange', visibilityListener);
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (visibilityListener) {
                    /* istanbul ignore next */ doc === null || doc === void 0 ? void 0 : doc.removeEventListener('visibilitychange', visibilityListener);
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$web$2d$vitals$2d$browser$40$1$2e$1$2e$33$2f$node_modules$2f40$amplitude$2f$plugin$2d$web$2d$vitals$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PLUGIN_NAME"],
        type: 'enrichment',
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
}),
"[project]/node_modules/.pnpm/web-vitals@5.1.0/node_modules/web-vitals/dist/web-vitals.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CLSThresholds",
    ()=>b,
    "FCPThresholds",
    ()=>y,
    "INPThresholds",
    ()=>B,
    "LCPThresholds",
    ()=>q,
    "TTFBThresholds",
    ()=>H,
    "onCLS",
    ()=>L,
    "onFCP",
    ()=>E,
    "onINP",
    ()=>S,
    "onLCP",
    ()=>x,
    "onTTFB",
    ()=>$
]);
let e = -1;
const t = (t)=>{
    addEventListener("pageshow", (n)=>{
        n.persisted && (e = n.timeStamp, t(n));
    }, !0);
}, n = (e, t, n, i)=>{
    let s, o;
    return (r)=>{
        t.value >= 0 && (r || i) && (o = t.value - (s ?? 0), (o || void 0 === s) && (s = t.value, t.delta = o, t.rating = ((e, t)=>e > t[1] ? "poor" : e > t[0] ? "needs-improvement" : "good")(t.value, n), e(t)));
    };
}, i = (e)=>{
    requestAnimationFrame(()=>requestAnimationFrame(()=>e()));
}, s = ()=>{
    const e = performance.getEntriesByType("navigation")[0];
    if (e && e.responseStart > 0 && e.responseStart < performance.now()) return e;
}, o = ()=>{
    const e = s();
    return e?.activationStart ?? 0;
}, r = (t, n = -1)=>{
    const i = s();
    let r = "navigate";
    e >= 0 ? r = "back-forward-cache" : i && (document.prerendering || o() > 0 ? r = "prerender" : document.wasDiscarded ? r = "restore" : i.type && (r = i.type.replace(/_/g, "-")));
    return {
        name: t,
        value: n,
        rating: "good",
        delta: 0,
        entries: [],
        id: `v5-${Date.now()}-${Math.floor(8999999999999 * Math.random()) + 1e12}`,
        navigationType: r
    };
}, c = new WeakMap;
function a(e, t) {
    return c.get(e) || c.set(e, new t), c.get(e);
}
class d {
    t;
    i = 0;
    o = [];
    h(e) {
        if (e.hadRecentInput) return;
        const t = this.o[0], n = this.o.at(-1);
        this.i && t && n && e.startTime - n.startTime < 1e3 && e.startTime - t.startTime < 5e3 ? (this.i += e.value, this.o.push(e)) : (this.i = e.value, this.o = [
            e
        ]), this.t?.(e);
    }
}
const h = (e, t, n = {})=>{
    try {
        if (PerformanceObserver.supportedEntryTypes.includes(e)) {
            const i = new PerformanceObserver((e)=>{
                Promise.resolve().then(()=>{
                    t(e.getEntries());
                });
            });
            return i.observe({
                type: e,
                buffered: !0,
                ...n
            }), i;
        }
    } catch  {}
}, f = (e)=>{
    let t = !1;
    return ()=>{
        t || (e(), t = !0);
    };
};
let u = -1;
const l = new Set, m = ()=>"hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0, p = (e)=>{
    if ("hidden" === document.visibilityState) {
        if ("visibilitychange" === e.type) for (const e of l)e();
        isFinite(u) || (u = "visibilitychange" === e.type ? e.timeStamp : 0, removeEventListener("prerenderingchange", p, !0));
    }
}, v = ()=>{
    if (u < 0) {
        const e = o(), n = document.prerendering ? void 0 : globalThis.performance.getEntriesByType("visibility-state").filter((t)=>"hidden" === t.name && t.startTime > e)[0]?.startTime;
        u = n ?? m(), addEventListener("visibilitychange", p, !0), addEventListener("prerenderingchange", p, !0), t(()=>{
            setTimeout(()=>{
                u = m();
            });
        });
    }
    return {
        get firstHiddenTime () {
            return u;
        },
        onHidden (e) {
            l.add(e);
        }
    };
}, g = (e)=>{
    document.prerendering ? addEventListener("prerenderingchange", ()=>e(), !0) : e();
}, y = [
    1800,
    3e3
], E = (e, s = {})=>{
    g(()=>{
        const c = v();
        let a, d = r("FCP");
        const f = h("paint", (e)=>{
            for (const t of e)"first-contentful-paint" === t.name && (f.disconnect(), t.startTime < c.firstHiddenTime && (d.value = Math.max(t.startTime - o(), 0), d.entries.push(t), a(!0)));
        });
        f && (a = n(e, d, y, s.reportAllChanges), t((t)=>{
            d = r("FCP"), a = n(e, d, y, s.reportAllChanges), i(()=>{
                d.value = performance.now() - t.timeStamp, a(!0);
            });
        }));
    });
}, b = [
    .1,
    .25
], L = (e, s = {})=>{
    const o = v();
    E(f(()=>{
        let c, f = r("CLS", 0);
        const u = a(s, d), l = (e)=>{
            for (const t of e)u.h(t);
            u.i > f.value && (f.value = u.i, f.entries = u.o, c());
        }, m = h("layout-shift", l);
        m && (c = n(e, f, b, s.reportAllChanges), o.onHidden(()=>{
            l(m.takeRecords()), c(!0);
        }), t(()=>{
            u.i = 0, f = r("CLS", 0), c = n(e, f, b, s.reportAllChanges), i(()=>c());
        }), setTimeout(c));
    }));
};
let P = 0, T = 1 / 0, _ = 0;
const M = (e)=>{
    for (const t of e)t.interactionId && (T = Math.min(T, t.interactionId), _ = Math.max(_, t.interactionId), P = _ ? (_ - T) / 7 + 1 : 0);
};
let w;
const C = ()=>w ? P : performance.interactionCount ?? 0, I = ()=>{
    "interactionCount" in performance || w || (w = h("event", M, {
        type: "event",
        buffered: !0,
        durationThreshold: 0
    }));
};
let F = 0;
class k {
    u = [];
    l = new Map;
    m;
    p;
    v() {
        F = C(), this.u.length = 0, this.l.clear();
    }
    L() {
        const e = Math.min(this.u.length - 1, Math.floor((C() - F) / 50));
        return this.u[e];
    }
    h(e) {
        if (this.m?.(e), !e.interactionId && "first-input" !== e.entryType) return;
        const t = this.u.at(-1);
        let n = this.l.get(e.interactionId);
        if (n || this.u.length < 10 || e.duration > t.P) {
            if (n ? e.duration > n.P ? (n.entries = [
                e
            ], n.P = e.duration) : e.duration === n.P && e.startTime === n.entries[0].startTime && n.entries.push(e) : (n = {
                id: e.interactionId,
                entries: [
                    e
                ],
                P: e.duration
            }, this.l.set(n.id, n), this.u.push(n)), this.u.sort((e, t)=>t.P - e.P), this.u.length > 10) {
                const e = this.u.splice(10);
                for (const t of e)this.l.delete(t.id);
            }
            this.p?.(n);
        }
    }
}
const A = (e)=>{
    const t = globalThis.requestIdleCallback || setTimeout;
    "hidden" === document.visibilityState ? e() : (e = f(e), addEventListener("visibilitychange", e, {
        once: !0,
        capture: !0
    }), t(()=>{
        e(), removeEventListener("visibilitychange", e, {
            capture: !0
        });
    }));
}, B = [
    200,
    500
], S = (e, i = {})=>{
    if (!globalThis.PerformanceEventTiming || !("interactionId" in PerformanceEventTiming.prototype)) return;
    const s = v();
    g(()=>{
        I();
        let o, c = r("INP");
        const d = a(i, k), f = (e)=>{
            A(()=>{
                for (const t of e)d.h(t);
                const t = d.L();
                t && t.P !== c.value && (c.value = t.P, c.entries = t.entries, o());
            });
        }, u = h("event", f, {
            durationThreshold: i.durationThreshold ?? 40
        });
        o = n(e, c, B, i.reportAllChanges), u && (u.observe({
            type: "first-input",
            buffered: !0
        }), s.onHidden(()=>{
            f(u.takeRecords()), o(!0);
        }), t(()=>{
            d.v(), c = r("INP"), o = n(e, c, B, i.reportAllChanges);
        }));
    });
};
class N {
    m;
    h(e) {
        this.m?.(e);
    }
}
const q = [
    2500,
    4e3
], x = (e, s = {})=>{
    g(()=>{
        const c = v();
        let d, u = r("LCP");
        const l = a(s, N), m = (e)=>{
            s.reportAllChanges || (e = e.slice(-1));
            for (const t of e)l.h(t), t.startTime < c.firstHiddenTime && (u.value = Math.max(t.startTime - o(), 0), u.entries = [
                t
            ], d());
        }, p = h("largest-contentful-paint", m);
        if (p) {
            d = n(e, u, q, s.reportAllChanges);
            const o = f(()=>{
                m(p.takeRecords()), p.disconnect(), d(!0);
            }), c = (e)=>{
                e.isTrusted && (A(o), removeEventListener(e.type, c, {
                    capture: !0
                }));
            };
            for (const e of [
                "keydown",
                "click",
                "visibilitychange"
            ])addEventListener(e, c, {
                capture: !0
            });
            t((t)=>{
                u = r("LCP"), d = n(e, u, q, s.reportAllChanges), i(()=>{
                    u.value = performance.now() - t.timeStamp, d(!0);
                });
            });
        }
    });
}, H = [
    800,
    1800
], O = (e)=>{
    document.prerendering ? g(()=>O(e)) : "complete" !== document.readyState ? addEventListener("load", ()=>O(e), !0) : setTimeout(e);
}, $ = (e, i = {})=>{
    let c = r("TTFB"), a = n(e, c, H, i.reportAllChanges);
    O(()=>{
        const d = s();
        d && (c.value = Math.max(d.responseStart - o(), 0), c.entries = [
            d
        ], a(!0), t(()=>{
            c = r("TTFB", 0), a = n(e, c, H, i.reportAllChanges), a(!0);
        }));
    });
};
;
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-event-property-attribution-browser@0.2.1/node_modules/@amplitude/plugin-event-property-attribution-browser/lib/esm/event-property-tracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "eventPropertyTrackingPlugin",
    ()=>eventPropertyTrackingPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$campaign$2f$campaign$2d$parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/campaign/campaign-parser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$omit$2d$undefined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/omit-undefined.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)");
;
;
var ATTRIBUTION_EVENT_TYPE = '[Amplitude] Attribution';
var EVENT_PROPERTY_EXCLUDED_EVENT_TYPES = new Set([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].IDENTIFY,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].GROUP_IDENTIFY
]);
var toEventPropertyCampaign = function(campaign) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$omit$2d$undefined$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["omitUndefined"])(campaign);
};
var eventPropertyTrackingPlugin = function(options) {
    var _a;
    if (options === void 0) {
        options = {};
    }
    var fallbackAttributionEvent = (_a = options.fallbackAttributionEvent) !== null && _a !== void 0 ? _a : false;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    var amplitude;
    var loggerProvider;
    var eventPropertyCampaign = {};
    var isTracking = false;
    var isProxied = false;
    var originalPushState;
    var originalReplaceState;
    var installedPushState;
    var installedReplaceState;
    var updateCampaignState = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var currentCampaign;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        return [
                            4 /*yield*/ ,
                            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$campaign$2f$campaign$2d$parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CampaignParser"]().parse()
                        ];
                    case 1:
                        currentCampaign = _a.sent();
                        eventPropertyCampaign = toEventPropertyCampaign(currentCampaign);
                        if (fallbackAttributionEvent) {
                            /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.log('Tracking attribution fallback event.');
                            /* istanbul ignore next */ amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(ATTRIBUTION_EVENT_TYPE, eventPropertyCampaign);
                        }
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    var onHistoryChange = function() {
        // CampaignParser.parse() is async by type, but its current implementation computes synchronously.
        // In the Browser SDK, this history-triggered refresh starts immediately and reaches its continuation
        // before Timeline.scheduleApply(0) runs event enrichment, so pushState()/replaceState() followed by
        // track() in the same tick does not currently race. Revisit this assumption if campaign parsing or
        // timeline scheduling becomes truly async in the future.
        void updateCampaignState();
    };
    var createHistoryStateProxy = function(method) {
        return new Proxy(method, {
            apply: function(target, thisArg, args) {
                Reflect.apply(target, thisArg, args);
                if (isTracking) {
                    onHistoryChange();
                }
            }
        });
    };
    return {
        name: '@amplitude/plugin-event-property-attribution-browser',
        type: 'enrichment',
        setup: function(config, client) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    switch(_a.label){
                        case 0:
                            amplitude = client;
                            loggerProvider = config.loggerProvider;
                            isTracking = true;
                            loggerProvider.log('Installing event property attribution tracking.');
                            return [
                                4 /*yield*/ ,
                                updateCampaignState()
                            ];
                        case 1:
                            _a.sent();
                            if (!globalScope) {
                                return [
                                    2 /*return*/ 
                                ];
                            }
                            globalScope.addEventListener('popstate', onHistoryChange);
                            if (!isProxied) {
                                // There is no global browser listener for history mutations, so proxy both methods.
                                originalPushState = Reflect.get(globalScope.history, 'pushState');
                                originalReplaceState = Reflect.get(globalScope.history, 'replaceState');
                                /* istanbul ignore next */ if (!originalPushState || !originalReplaceState) {
                                    return [
                                        2 /*return*/ 
                                    ];
                                }
                                installedPushState = createHistoryStateProxy(originalPushState);
                                globalScope.history.pushState = installedPushState;
                                installedReplaceState = createHistoryStateProxy(originalReplaceState);
                                globalScope.history.replaceState = installedReplaceState;
                                isProxied = true;
                            }
                            return [
                                2 /*return*/ 
                            ];
                    }
                });
            });
        },
        execute: function(event) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    if (EVENT_PROPERTY_EXCLUDED_EVENT_TYPES.has(event.event_type)) {
                        return [
                            2 /*return*/ ,
                            event
                        ];
                    }
                    event.event_properties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, eventPropertyCampaign), event.event_properties);
                    return [
                        2 /*return*/ ,
                        event
                    ];
                });
            });
        },
        teardown: function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var currentPushState, currentReplaceState;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    if (globalScope) {
                        globalScope.removeEventListener('popstate', onHistoryChange);
                        currentPushState = Reflect.get(globalScope.history, 'pushState');
                        currentReplaceState = Reflect.get(globalScope.history, 'replaceState');
                        if (isProxied && currentPushState === installedPushState && originalPushState) {
                            globalScope.history.pushState = originalPushState;
                        }
                        if (isProxied && currentReplaceState === installedReplaceState && originalReplaceState) {
                            globalScope.history.replaceState = originalReplaceState;
                        }
                    }
                    isTracking = false;
                    isProxied = false;
                    originalPushState = undefined;
                    originalReplaceState = undefined;
                    installedPushState = undefined;
                    installedReplaceState = undefined;
                    eventPropertyCampaign = {};
                    return [
                        2 /*return*/ 
                    ];
                });
            });
        }
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-page-url-enrichment-browser@0.7.11/node_modules/@amplitude/plugin-page-url-enrichment-browser/lib/esm/page-url-enrichment.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CURRENT_PAGE_STORAGE_KEY",
    ()=>CURRENT_PAGE_STORAGE_KEY,
    "EXCLUDED_DEFAULT_EVENT_TYPES",
    ()=>EXCLUDED_DEFAULT_EVENT_TYPES,
    "PREVIOUS_PAGE_STORAGE_KEY",
    ()=>PREVIOUS_PAGE_STORAGE_KEY,
    "URL_INFO_STORAGE_KEY",
    ()=>URL_INFO_STORAGE_KEY,
    "isPageUrlEnrichmentEnabled",
    ()=>isPageUrlEnrichmentEnabled,
    "pageUrlEnrichmentPlugin",
    ()=>pageUrlEnrichmentPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/browser-storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)");
;
;
var CURRENT_PAGE_STORAGE_KEY = 'AMP_CURRENT_PAGE';
var PREVIOUS_PAGE_STORAGE_KEY = 'AMP_PREVIOUS_PAGE';
var URL_INFO_STORAGE_KEY = 'AMP_URL_INFO';
var PreviousPageType;
(function(PreviousPageType) {
    PreviousPageType["Direct"] = "direct";
    PreviousPageType["Internal"] = "internal";
    PreviousPageType["External"] = "external";
})(PreviousPageType || (PreviousPageType = {}));
var EXCLUDED_DEFAULT_EVENT_TYPES = new Set([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].IDENTIFY,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].GROUP_IDENTIFY,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].REVENUE
]);
var isPageUrlEnrichmentEnabled = function(option) {
    if (typeof option === 'boolean') {
        return option;
    }
    if (typeof option === 'object' && option !== null && 'pageUrlEnrichment' in option) {
        return Boolean(option.pageUrlEnrichment);
    }
    return false;
};
var pageUrlEnrichmentPlugin = function(_a) {
    var _b = _a === void 0 ? {} : _a, _c = _b.internalDomains, internalDomains = _c === void 0 ? [] : _c;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    var sessionStorage = undefined;
    var isStorageEnabled = false;
    var loggerProvider = undefined;
    var isProxied = false;
    var isTracking = false;
    var getHostname = function(url) {
        var hostname;
        try {
            var decodedUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(url, loggerProvider);
            hostname = new URL(decodedUrl).hostname;
        } catch (e) {
            /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error('Could not parse URL: ', e);
        }
        return hostname;
    };
    var getPrevPageType = function(previousPage) {
        var currentDomain = typeof location !== 'undefined' && location.hostname || '';
        var previousPageDomain = previousPage ? getHostname(previousPage) : undefined;
        if (!previousPageDomain) {
            return PreviousPageType.Direct;
        }
        var isCurrentInternal = internalDomains.some(function(domain) {
            return currentDomain.indexOf(domain) !== -1;
        });
        var isPrevInternal = internalDomains.some(function(domain) {
            return previousPageDomain.indexOf(domain) !== -1;
        });
        if (currentDomain === previousPageDomain || isPrevInternal && isCurrentInternal) {
            return PreviousPageType.Internal;
        }
        return PreviousPageType.External;
    };
    var saveURLInfo = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var URLInfo, currentURL, storedCurrentURL, previousURL;
            var _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        if (!(sessionStorage && isStorageEnabled)) return [
                            3 /*break*/ ,
                            3
                        ];
                        return [
                            4 /*yield*/ ,
                            sessionStorage.get(URL_INFO_STORAGE_KEY)
                        ];
                    case 1:
                        URLInfo = _b.sent();
                        currentURL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(typeof location !== 'undefined' && location.href || '');
                        storedCurrentURL = (URLInfo === null || URLInfo === void 0 ? void 0 : URLInfo[CURRENT_PAGE_STORAGE_KEY]) || '';
                        previousURL = void 0;
                        if (currentURL === storedCurrentURL) {
                            previousURL = (URLInfo === null || URLInfo === void 0 ? void 0 : URLInfo[PREVIOUS_PAGE_STORAGE_KEY]) || '';
                        } else if (storedCurrentURL) {
                            previousURL = storedCurrentURL;
                        } else {
                            previousURL = document.referrer || '';
                        }
                        return [
                            4 /*yield*/ ,
                            sessionStorage.set(URL_INFO_STORAGE_KEY, (_a = {}, _a[CURRENT_PAGE_STORAGE_KEY] = currentURL, _a[PREVIOUS_PAGE_STORAGE_KEY] = previousURL, _a))
                        ];
                    case 2:
                        _b.sent();
                        _b.label = 3;
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    var saveUrlInfoWrapper = function() {
        void saveURLInfo();
    };
    var plugin = {
        name: '@amplitude/plugin-page-url-enrichment-browser',
        type: 'enrichment',
        setup: function(config, _) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var referrer, referrerHostname, currentHostname, currentURL, existingURLInfo, storedCurrentURL, arrivedFromDifferentOrigin;
                var _a;
                var _b;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_c) {
                    switch(_c.label){
                        case 0:
                            loggerProvider = config.loggerProvider;
                            loggerProvider.log('Installing @amplitude/plugin-page-url-enrichment-browser');
                            isTracking = true;
                            if (!globalScope) return [
                                3 /*break*/ ,
                                7
                            ];
                            try {
                                sessionStorage = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BrowserStorage"](globalScope.sessionStorage);
                            } catch (error) {
                                /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.debug('sessionStorage is not available in this environment.');
                            }
                            return [
                                4 /*yield*/ ,
                                sessionStorage === null || sessionStorage === void 0 ? void 0 : sessionStorage.isEnabled()
                            ];
                        case 1:
                            isStorageEnabled = (_b = _c.sent()) !== null && _b !== void 0 ? _b : false;
                            if (!(sessionStorage && isStorageEnabled)) return [
                                3 /*break*/ ,
                                6
                            ];
                            referrer = typeof document !== 'undefined' && document.referrer || '';
                            referrerHostname = referrer ? getHostname(referrer) : undefined;
                            currentHostname = typeof location !== 'undefined' && location.hostname || '';
                            currentURL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(typeof location !== 'undefined' && location.href || '');
                            return [
                                4 /*yield*/ ,
                                sessionStorage.get(URL_INFO_STORAGE_KEY)
                            ];
                        case 2:
                            existingURLInfo = _c.sent();
                            storedCurrentURL = (existingURLInfo === null || existingURLInfo === void 0 ? void 0 : existingURLInfo[CURRENT_PAGE_STORAGE_KEY]) || '';
                            arrivedFromDifferentOrigin = !!referrerHostname && referrerHostname !== currentHostname && storedCurrentURL !== currentURL;
                            if (!arrivedFromDifferentOrigin) return [
                                3 /*break*/ ,
                                4
                            ];
                            // sessionStorage survives same-tab cross-origin trips (siteA -> external -> siteA),
                            // leaving stale "current" that would wrongly become "previous". document.referrer
                            // is the truthful previous, so overwrite — at the cost of dropping the prior siteA page.
                            return [
                                4 /*yield*/ ,
                                sessionStorage.set(URL_INFO_STORAGE_KEY, (_a = {}, _a[CURRENT_PAGE_STORAGE_KEY] = currentURL, _a[PREVIOUS_PAGE_STORAGE_KEY] = referrer, _a))
                            ];
                        case 3:
                            // sessionStorage survives same-tab cross-origin trips (siteA -> external -> siteA),
                            // leaving stale "current" that would wrongly become "previous". document.referrer
                            // is the truthful previous, so overwrite — at the cost of dropping the prior siteA page.
                            _c.sent();
                            return [
                                3 /*break*/ ,
                                6
                            ];
                        case 4:
                            return [
                                4 /*yield*/ ,
                                saveURLInfo()
                            ];
                        case 5:
                            _c.sent();
                            _c.label = 6;
                        case 6:
                            globalScope.addEventListener('popstate', saveUrlInfoWrapper);
                            if (!isProxied) {
                                /* istanbul ignore next */ // There is no global browser listener for changes to history, so we have
                                // to modify pushState and replaceState directly.
                                // https://stackoverflow.com/a/64927639
                                // eslint-disable-next-line @typescript-eslint/unbound-method
                                globalScope.history.pushState = new Proxy(globalScope.history.pushState, {
                                    apply: function(target, thisArg, _a) {
                                        var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 3), state = _b[0], unused = _b[1], url = _b[2];
                                        target.apply(thisArg, [
                                            state,
                                            unused,
                                            url
                                        ]);
                                        if (isTracking) {
                                            saveUrlInfoWrapper();
                                        }
                                    }
                                });
                                // eslint-disable-next-line @typescript-eslint/unbound-method
                                globalScope.history.replaceState = new Proxy(globalScope.history.replaceState, {
                                    apply: function(target, thisArg, _a) {
                                        var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 3), state = _b[0], unused = _b[1], url = _b[2];
                                        target.apply(thisArg, [
                                            state,
                                            unused,
                                            url
                                        ]);
                                        if (isTracking) {
                                            saveUrlInfoWrapper();
                                        }
                                    }
                                });
                                isProxied = true;
                            }
                            _c.label = 7;
                        case 7:
                            return [
                                2 /*return*/ 
                            ];
                    }
                });
            });
        },
        execute: function(event) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var locationHREF, URLInfo, previousPage;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    switch(_a.label){
                        case 0:
                            locationHREF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(typeof location !== 'undefined' && location.href || '');
                            if (!(sessionStorage && isStorageEnabled)) return [
                                3 /*break*/ ,
                                2
                            ];
                            return [
                                4 /*yield*/ ,
                                sessionStorage.get(URL_INFO_STORAGE_KEY)
                            ];
                        case 1:
                            URLInfo = _a.sent();
                            previousPage = (URLInfo === null || URLInfo === void 0 ? void 0 : URLInfo[PREVIOUS_PAGE_STORAGE_KEY]) || '';
                            // no need to proceed to add additional properties if the event is one of the default event types to be excluded
                            if (EXCLUDED_DEFAULT_EVENT_TYPES.has(event.event_type)) {
                                return [
                                    2 /*return*/ ,
                                    event
                                ];
                            }
                            event.event_properties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event.event_properties || {}), {
                                '[Amplitude] Page Domain': addIfNotExist(event, '[Amplitude] Page Domain', typeof location !== 'undefined' && location.hostname || ''),
                                '[Amplitude] Page Location': addIfNotExist(event, '[Amplitude] Page Location', locationHREF),
                                '[Amplitude] Page Path': addIfNotExist(event, '[Amplitude] Page Path', typeof location !== 'undefined' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(location.pathname) || ''),
                                '[Amplitude] Page Title': addIfNotExist(event, '[Amplitude] Page Title', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageTitle"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceSensitiveString"])),
                                '[Amplitude] Page URL': addIfNotExist(event, '[Amplitude] Page URL', locationHREF.split('?')[0]),
                                '[Amplitude] Previous Page Location': previousPage,
                                '[Amplitude] Previous Page Type': getPrevPageType(previousPage)
                            });
                            _a.label = 2;
                        case 2:
                            return [
                                2 /*return*/ ,
                                event
                            ];
                    }
                });
            });
        },
        teardown: function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    switch(_a.label){
                        case 0:
                            if (globalScope) {
                                globalScope.removeEventListener('popstate', saveUrlInfoWrapper);
                                isTracking = false;
                            }
                            if (!(sessionStorage && isStorageEnabled)) return [
                                3 /*break*/ ,
                                2
                            ];
                            return [
                                4 /*yield*/ ,
                                sessionStorage.set(URL_INFO_STORAGE_KEY, {})
                            ];
                        case 1:
                            _a.sent();
                            _a.label = 2;
                        case 2:
                            return [
                                2 /*return*/ 
                            ];
                    }
                });
            });
        }
    };
    return plugin;
};
function addIfNotExist(event, key, value) {
    if (!event.event_properties) {
        event.event_properties = {};
    }
    if (event.event_properties[key] === undefined) {
        return value;
    }
    return event.event_properties[key];
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-custom-enrichment-browser@0.1.9/node_modules/@amplitude/plugin-custom-enrichment-browser/lib/esm/custom-enrichment.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "customEnrichmentPlugin",
    ()=>customEnrichmentPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var customEnrichmentPlugin = function() {
    var loggerProvider;
    var unsubscribe;
    var enrichEvent;
    function isCustomEnrichmentConfig(config) {
        // 1. Check if it's an object and not null
        if (typeof config !== 'object' || config === null) {
            return false;
        }
        // 2. Validate specific properties exist and are the correct type
        return 'body' in config && typeof config.body === 'string';
    }
    function createEnrichEvent(body) {
        if (body) {
            try {
                // eslint-disable-next-line @typescript-eslint/no-unsafe-call, @typescript-eslint/no-implied-eval
                var fn = new Function('return ' + body)();
                if (typeof fn === 'function') {
                    return fn;
                }
                loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error('Custom enrichment body did not evaluate to a function');
            } catch (error) {
                loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error('Could not create custom enrichment function', error);
            }
        }
        return function(event) {
            return event;
        };
    }
    var plugin = {
        name: '@amplitude/plugin-custom-enrichment-browser',
        type: 'enrichment',
        setup: function(config, _) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var subscriptionId_1;
                var _a;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                    loggerProvider = config.loggerProvider;
                    loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.log('Installing @amplitude/plugin-custom-enrichment-browser');
                    // Fetch remote config for custom enrichment in a non-blocking manner
                    if ((_a = config.remoteConfig) === null || _a === void 0 ? void 0 : _a.fetchRemoteConfig) {
                        if (!config.remoteConfigClient) {
                            // TODO(xinyi): Diagnostics.recordEvent
                            loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.debug('Remote config client is not provided, skipping remote config fetch');
                        } else {
                            subscriptionId_1 = config.remoteConfigClient.subscribe('configs.analyticsSDK.browserSDK.customEnrichment', 'all', function(remoteConfig) {
                                if (remoteConfig && isCustomEnrichmentConfig(remoteConfig)) {
                                    enrichEvent = createEnrichEvent(remoteConfig.body || '');
                                } else {
                                    // if there is no valid body, clear enrich event
                                    enrichEvent = createEnrichEvent('');
                                }
                            });
                            unsubscribe = function() {
                                var _a;
                                return (_a = config.remoteConfigClient) === null || _a === void 0 ? void 0 : _a.unsubscribe(subscriptionId_1);
                            };
                        }
                    }
                    return [
                        2 /*return*/ 
                    ];
                });
            });
        },
        execute: function(event) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                var _a;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                    if (enrichEvent) {
                        try {
                            return [
                                2 /*return*/ ,
                                (_a = enrichEvent(event)) !== null && _a !== void 0 ? _a : null
                            ];
                        } catch (error) {
                            loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error('Could not execute custom enrichment function', error);
                            return [
                                2 /*return*/ ,
                                event
                            ];
                        }
                    }
                    return [
                        2 /*return*/ ,
                        event
                    ];
                });
            });
        },
        teardown: function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    if (unsubscribe) {
                        unsubscribe();
                    }
                    return [
                        2 /*return*/ 
                    ];
                });
            });
        }
    };
    return plugin;
};
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>LoaderCircle
]);
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M21 12a9 9 0 1 1-6.219-8.56",
            key: "13zald"
        }
    ]
];
const LoaderCircle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("loader-circle", __iconNode);
;
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Loader2",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ArrowRight
]);
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ],
    [
        "path",
        {
            d: "m12 5 7 7-7 7",
            key: "xquz4c"
        }
    ]
];
const ArrowRight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("arrow-right", __iconNode);
;
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowRight",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/github.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Github
]);
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",
            key: "tonef"
        }
    ],
    [
        "path",
        {
            d: "M9 18c-4.51 2-5-2-7-2",
            key: "9comsn"
        }
    ]
];
const Github = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("github", __iconNode);
;
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/github.js [app-client] (ecmascript) <export default as Github>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Github",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$github$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$github$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/github.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ArrowLeft
]);
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m12 19-7-7 7-7",
            key: "1l729n"
        }
    ],
    [
        "path",
        {
            d: "M19 12H5",
            key: "x3x0zl"
        }
    ]
];
const ArrowLeft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("arrow-left", __iconNode);
;
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-client] (ecmascript) <export default as ArrowLeft>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowLeft",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Minus
]);
/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ]
];
const Minus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("minus", __iconNode);
;
}),
"[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Minus",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$525$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.525.0_react@19.2.7/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@radix-ui+react-primitive@2.1.4_@types+react-dom@19.1.1_@types+react@19.1.0__@types+react@19._ugsbwe42xvwei3vnw5viohut6m/node_modules/@radix-ui/react-primitive/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Primitive",
    ()=>Primitive,
    "Root",
    ()=>Root,
    "dispatchDiscreteCustomEvent",
    ()=>dispatchDiscreteCustomEvent
]);
// src/primitive.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$2$2e$4_$40$types$2b$react$40$19$2e$1$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-slot@1.2.4_@types+react@19.1.0_react@19.2.7/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
var NODES = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
];
var Primitive = NODES.reduce((primitive, node)=>{
    const Slot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$2$2e$4_$40$types$2b$react$40$19$2e$1$2e$0_react$40$19$2e$2$2e$7$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSlot"])(`Primitive.${node}`);
    const Node = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
        const { asChild, ...primitiveProps } = props;
        const Comp = asChild ? Slot : node;
        if (typeof window !== "undefined") {
            window[Symbol.for("radix-ui")] = true;
        }
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Comp, {
            ...primitiveProps,
            ref: forwardedRef
        });
    });
    Node.displayName = `Primitive.${node}`;
    return {
        ...primitive,
        [node]: Node
    };
}, {});
function dispatchDiscreteCustomEvent(target, event) {
    if (target) __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"](()=>target.dispatchEvent(event));
}
var Root = Primitive;
;
}),
"[project]/node_modules/.pnpm/@radix-ui+react-separator@1.1.8_@types+react-dom@19.1.1_@types+react@19.1.0__@types+react@19._ry3oblddhhvdvfxsdb5k3bzb4y/node_modules/@radix-ui/react-separator/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Root",
    ()=>Root,
    "Separator",
    ()=>Separator
]);
// src/separator.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$4_$40$types$2b$react$2d$dom$40$19$2e$1$2e$1_$40$types$2b$react$40$19$2e$1$2e$0_$5f40$types$2b$react$40$19$2e$_ugsbwe42xvwei3vnw5viohut6m$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-primitive@2.1.4_@types+react-dom@19.1.1_@types+react@19.1.0__@types+react@19._ugsbwe42xvwei3vnw5viohut6m/node_modules/@radix-ui/react-primitive/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
var NAME = "Separator";
var DEFAULT_ORIENTATION = "horizontal";
var ORIENTATIONS = [
    "horizontal",
    "vertical"
];
var Separator = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((props, forwardedRef)=>{
    const { decorative, orientation: orientationProp = DEFAULT_ORIENTATION, ...domProps } = props;
    const orientation = isValidOrientation(orientationProp) ? orientationProp : DEFAULT_ORIENTATION;
    const ariaOrientation = orientation === "vertical" ? orientation : void 0;
    const semanticProps = decorative ? {
        role: "none"
    } : {
        "aria-orientation": ariaOrientation,
        role: "separator"
    };
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$primitive$40$2$2e$1$2e$4_$40$types$2b$react$2d$dom$40$19$2e$1$2e$1_$40$types$2b$react$40$19$2e$1$2e$0_$5f40$types$2b$react$40$19$2e$_ugsbwe42xvwei3vnw5viohut6m$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$primitive$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Primitive"].div, {
        "data-orientation": orientation,
        ...semanticProps,
        ...domProps,
        ref: forwardedRef
    });
});
Separator.displayName = NAME;
function isValidOrientation(orientation) {
    return ORIENTATIONS.includes(orientation);
}
var Root = Separator;
;
}),
"[project]/node_modules/.pnpm/@marsidev+react-turnstile@1.5.3_react-dom@19.2.7_react@19.2.7__react@19.2.7/node_modules/@marsidev/react-turnstile/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_CONTAINER_ID",
    ()=>d,
    "DEFAULT_ONLOAD_NAME",
    ()=>f,
    "DEFAULT_SCRIPT_ID",
    ()=>u,
    "SCRIPT_URL",
    ()=>l,
    "Turnstile",
    ()=>S
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
var c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(({ as: e = `div`, ...t }, n)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {
        ...t,
        ref: n
    }));
const l = `https://challenges.cloudflare.com/turnstile/v0/api.js`, u = `cf-turnstile-script`, d = `cf-turnstile`, f = `onloadTurnstileCallback`, p = (e)=>!!document.getElementById(e), m = ({ render: e = `explicit`, onLoadCallbackName: t = f, scriptOptions: { nonce: n = ``, defer: r = !0, async: i = !0, id: a = ``, appendTo: o, onError: s, crossOrigin: c = `` } = {} })=>{
    let u = a || `cf-turnstile-script`;
    if (p(u)) return;
    let d = document.createElement(`script`);
    d.id = u, d.src = `${l}?onload=${t}&render=${e}`, !document.querySelector(`script[src="${d.src}"]`) && (d.defer = !!r, d.async = !!i, n && d.setAttribute(`nonce`, n), c && (d.crossOrigin = c), s && (d.onerror = s, delete window[t]), (o === `body` ? document.body : document.getElementsByTagName(`head`)[0]).appendChild(d));
}, h = {
    normal: {
        width: 300,
        height: 65
    },
    compact: {
        width: 150,
        height: 140
    },
    invisible: {
        width: 0,
        height: 0,
        overflow: `hidden`
    },
    flexible: {
        minWidth: 300,
        width: `100%`,
        height: 65
    },
    interactionOnly: {
        width: `fit-content`,
        height: `auto`,
        display: `flex`
    }
};
function g(e) {
    if (e !== `invisible` && e !== `interactionOnly`) return e;
}
function _(e = u) {
    let [t, r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let t = ()=>{
            p(e) && r(!0);
        }, n = new MutationObserver(t);
        return n.observe(document, {
            childList: !0,
            subtree: !0
        }), t(), ()=>{
            n.disconnect();
        };
    }, [
        e
    ]), t;
}
let v = `unloaded`, y;
const b = new Promise((e, t)=>{
    y = {
        resolve: e,
        reject: t
    }, v === `ready` && e(void 0);
}), x = (e = f)=>(v === `unloaded` && (v = `loading`, window[e] = ()=>{
        y.resolve(), v = `ready`, delete window[e];
    }), b), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])((e, l)=>{
    let { scriptOptions: u, options: d = {}, siteKey: f, onWidgetLoad: p, onSuccess: y, onExpire: b, onError: S, onBeforeInteractive: C, onAfterInteractive: w, onUnsupported: T, onTimeout: E, onLoadScript: D, id: O, style: k, as: A = `div`, injectScript: j = !0, rerenderOnCallbackChange: M = !1, ...N } = e, P = d.size, F = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>P === void 0 ? {} : d.execution === `execute` ? h.invisible : d.appearance === `interaction-only` ? h.interactionOnly : h[P], [
        d.execution,
        P,
        d.appearance
    ]), [I, L] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(F()), R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [z, B] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), V = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(void 0), H = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), U = O || `cf-turnstile`, W = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        onSuccess: y,
        onError: S,
        onExpire: b,
        onBeforeInteractive: C,
        onAfterInteractive: w,
        onUnsupported: T,
        onTimeout: E
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        M || (W.current = {
            onSuccess: y,
            onError: S,
            onExpire: b,
            onBeforeInteractive: C,
            onAfterInteractive: w,
            onUnsupported: T,
            onTimeout: E
        });
    });
    let G = u?.id || `cf-turnstile-script`, K = _(G), q = u?.onLoadCallbackName || `onloadTurnstileCallback`, J = d.appearance || `always`, Y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            sitekey: f,
            action: d.action,
            cData: d.cData,
            theme: d.theme || `auto`,
            language: d.language || `auto`,
            tabindex: d.tabIndex,
            "response-field": d.responseField,
            "response-field-name": d.responseFieldName,
            size: g(P),
            retry: d.retry || `auto`,
            "retry-interval": d.retryInterval || 8e3,
            "refresh-expired": d.refreshExpired || `auto`,
            "refresh-timeout": d.refreshTimeout || `auto`,
            execution: d.execution || `render`,
            appearance: d.appearance || `always`,
            "feedback-enabled": d.feedbackEnabled ?? !0,
            callback: (e)=>{
                H.current = !0, M ? y?.(e) : W.current.onSuccess?.(e);
            },
            "error-callback": M ? S : (...e)=>W.current.onError?.(...e),
            "expired-callback": M ? b : (...e)=>W.current.onExpire?.(...e),
            "before-interactive-callback": M ? C : (...e)=>W.current.onBeforeInteractive?.(...e),
            "after-interactive-callback": M ? w : (...e)=>W.current.onAfterInteractive?.(...e),
            "unsupported-callback": M ? T : (...e)=>W.current.onUnsupported?.(...e),
            "timeout-callback": M ? E : (...e)=>W.current.onTimeout?.(...e)
        }), [
        d.action,
        d.appearance,
        d.cData,
        d.execution,
        d.language,
        d.refreshExpired,
        d.responseField,
        d.responseFieldName,
        d.retry,
        d.retryInterval,
        d.tabIndex,
        d.theme,
        d.feedbackEnabled,
        d.refreshTimeout,
        f,
        P,
        M,
        M ? y : null,
        M ? S : null,
        M ? b : null,
        M ? C : null,
        M ? w : null,
        M ? T : null,
        M ? E : null
    ]), X = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>typeof window < `u` && !!window.turnstile, []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
        j && !z && (x(q), m({
            onLoadCallbackName: q,
            scriptOptions: {
                ...u,
                id: G
            }
        }));
    }, [
        j,
        z,
        u,
        G,
        q
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
        v !== `ready` && x(q).then(()=>B(!0)).catch(console.error);
    }, [
        q
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
        if (!R.current || !z) return;
        let e = !1;
        return (async ()=>{
            e || !R.current || (V.current = window.turnstile.render(R.current, Y), V.current && p?.(V.current));
        })(), ()=>{
            e = !0, V.current && (window.turnstile.remove(V.current), H.current = !1);
        };
    }, [
        U,
        z,
        Y
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(l, ()=>{
        let { turnstile: e } = window;
        return {
            getResponse () {
                if (!e?.getResponse || !V.current || !X()) {
                    console.warn(`Turnstile has not been loaded`);
                    return;
                }
                return e.getResponse(V.current);
            },
            async getResponsePromise (e = 3e4, t = 100) {
                return new Promise((n, r)=>{
                    let i, a = async ()=>{
                        if (H.current && window.turnstile && V.current) try {
                            let e = window.turnstile.getResponse(V.current);
                            return i && clearTimeout(i), e ? n(e) : r(Error(`No response received`));
                        } catch (e) {
                            return i && clearTimeout(i), console.warn(`Failed to get response`, e), r(Error(`Failed to get response`));
                        }
                        i ||= setTimeout(()=>{
                            i && clearTimeout(i), r(Error(`Timeout`));
                        }, e), await new Promise((e)=>setTimeout(e, t)), await a();
                    };
                    a();
                });
            },
            reset () {
                if (!e?.reset || !V.current || !X()) {
                    console.warn(`Turnstile has not been loaded`);
                    return;
                }
                d.execution === `execute` && L(h.invisible);
                try {
                    H.current = !1, e.reset(V.current);
                } catch (e) {
                    console.warn(`Failed to reset Turnstile widget ${V.current}`, e);
                }
            },
            remove () {
                if (!e?.remove || !V.current || !X()) {
                    console.warn(`Turnstile has not been loaded`);
                    return;
                }
                L(h.invisible), H.current = !1, e.remove(V.current), V.current = null;
            },
            render () {
                if (!e?.render || !R.current || !X() || V.current) {
                    console.warn(`Turnstile has not been loaded or container not found`);
                    return;
                }
                let t = e.render(R.current, Y);
                return V.current = t, V.current && p?.(V.current), d.execution !== `execute` && L(P ? h[P] : {}), t;
            },
            execute () {
                if (d.execution !== `execute`) {
                    console.warn(`Execution mode is not set to "execute"`);
                    return;
                }
                if (!e?.execute || !R.current || !V.current || !X()) {
                    console.warn(`Turnstile has not been loaded or container not found`);
                    return;
                }
                e.execute(R.current), L(P ? h[P] : {});
            },
            isExpired () {
                return !e?.isExpired || !V.current || !X() ? (console.warn(`Turnstile has not been loaded`), !1) : e.isExpired(V.current);
            }
        };
    }, [
        V,
        d.execution,
        P,
        Y,
        R,
        X,
        z,
        p
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (z || !K) return;
        if (window.turnstile) {
            B(!0);
            return;
        }
        let e = setInterval(()=>{
            window.turnstile && (B(!0), clearInterval(e));
        }, 50);
        return ()=>{
            clearInterval(e);
        };
    }, [
        z,
        K
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        L(F());
    }, [
        d.execution,
        P,
        J
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        !K || typeof D != `function` || D();
    }, [
        K
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(c, {
        ref: R,
        as: A,
        id: U,
        style: {
            ...I,
            ...k
        },
        ...N
    });
});
S.displayName = `Turnstile`;
;
}),
"[project]/node_modules/.pnpm/input-otp@1.4.2_react-dom@19.2.7_react@19.2.7__react@19.2.7/node_modules/input-otp/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OTPInput",
    ()=>Lt,
    "OTPInputContext",
    ()=>jt,
    "REGEXP_ONLY_CHARS",
    ()=>Jt,
    "REGEXP_ONLY_DIGITS",
    ()=>Kt,
    "REGEXP_ONLY_DIGITS_AND_CHARS",
    ()=>Qt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.7_@babel+core@7.29.7_@opentelemetry+api@1.9.1_@playwright+test@1.61.1_react-dom@19._oaiqmtf7py6tq5l47izuf7xccm/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var Bt = Object.defineProperty, At = Object.defineProperties;
var kt = Object.getOwnPropertyDescriptors;
var Y = Object.getOwnPropertySymbols;
var gt = Object.prototype.hasOwnProperty, Et = Object.prototype.propertyIsEnumerable;
var vt = (r, s, e)=>s in r ? Bt(r, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[s] = e, St = (r, s)=>{
    for(var e in s || (s = {}))gt.call(s, e) && vt(r, e, s[e]);
    if (Y) for (var e of Y(s))Et.call(s, e) && vt(r, e, s[e]);
    return r;
}, bt = (r, s)=>At(r, kt(s));
var Pt = (r, s)=>{
    var e = {};
    for(var u in r)gt.call(r, u) && s.indexOf(u) < 0 && (e[u] = r[u]);
    if (r != null && Y) for (var u of Y(r))s.indexOf(u) < 0 && Et.call(r, u) && (e[u] = r[u]);
    return e;
};
;
function ht(r) {
    let s = setTimeout(r, 0), e = setTimeout(r, 10), u = setTimeout(r, 50);
    return [
        s,
        e,
        u
    ];
}
;
function _t(r) {
    let s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "_t.useEffect": ()=>{
            s.current = r;
        }
    }["_t.useEffect"]), s.current;
}
;
var Ot = 18, wt = 40, Gt = `${wt}px`, xt = [
    "[data-lastpass-icon-root]",
    "com-1password-button",
    "[data-dashlanecreated]",
    '[style$="2147483647 !important;"]'
].join(",");
function Tt({ containerRef: r, inputRef: s, pushPasswordManagerStrategy: e, isFocused: u }) {
    let [P, D] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [G, H] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [F, W] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), Z = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Tt.useMemo[Z]": ()=>e === "none" ? !1 : (e === "increase-width" || e === "experimental-no-flickering") && P && G
    }["Tt.useMemo[Z]"], [
        P,
        G,
        e
    ]), T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Tt.useCallback[T]": ()=>{
            let f = r.current, h = s.current;
            if (!f || !h || F || e === "none") return;
            let a = f, B = a.getBoundingClientRect().left + a.offsetWidth, A = a.getBoundingClientRect().top + a.offsetHeight / 2, z = B - Ot, q = A;
            document.querySelectorAll(xt).length === 0 && document.elementFromPoint(z, q) === f || (D(!0), W(!0));
        }
    }["Tt.useCallback[T]"], [
        r,
        s,
        F,
        e
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Tt.useEffect": ()=>{
            let f = r.current;
            if (!f || e === "none") return;
            function h() {
                let A = window.innerWidth - f.getBoundingClientRect().right;
                H(A >= wt);
            }
            h();
            let a = setInterval(h, 1e3);
            return ({
                "Tt.useEffect": ()=>{
                    clearInterval(a);
                }
            })["Tt.useEffect"];
        }
    }["Tt.useEffect"], [
        r,
        e
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Tt.useEffect": ()=>{
            let f = u || document.activeElement === s.current;
            if (e === "none" || !f) return;
            let h = setTimeout(T, 0), a = setTimeout(T, 2e3), B = setTimeout(T, 5e3), A = setTimeout({
                "Tt.useEffect.A": ()=>{
                    W(!0);
                }
            }["Tt.useEffect.A"], 6e3);
            return ({
                "Tt.useEffect": ()=>{
                    clearTimeout(h), clearTimeout(a), clearTimeout(B), clearTimeout(A);
                }
            })["Tt.useEffect"];
        }
    }["Tt.useEffect"], [
        s,
        u,
        e,
        T
    ]), {
        hasPWMBadge: P,
        willPushPWMBadge: Z,
        PWM_BADGE_SPACE_WIDTH: Gt
    };
}
var jt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({}), Lt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((A, B)=>{
    var z = A, { value: r, onChange: s, maxLength: e, textAlign: u = "left", pattern: P, placeholder: D, inputMode: G = "numeric", onComplete: H, pushPasswordManagerStrategy: F = "increase-width", pasteTransformer: W, containerClassName: Z, noScriptCSSFallback: T = Nt, render: f, children: h } = z, a = Pt(z, [
        "value",
        "onChange",
        "maxLength",
        "textAlign",
        "pattern",
        "placeholder",
        "inputMode",
        "onComplete",
        "pushPasswordManagerStrategy",
        "pasteTransformer",
        "containerClassName",
        "noScriptCSSFallback",
        "render",
        "children"
    ]);
    var X, lt, ut, dt, ft;
    let [q, nt] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](typeof a.defaultValue == "string" ? a.defaultValue : ""), i = r != null ? r : q, I = _t(i), x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[x]": (t)=>{
            s == null || s(t), nt(t);
        }
    }["Lt.useCallback[x]"], [
        s
    ]), m = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[m]": ()=>P ? typeof P == "string" ? new RegExp(P) : P : null
    }["Lt.useMemo[m]"], [
        P
    ]), l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), K = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), J = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        value: i,
        onChange: x,
        isIOS: typeof window != "undefined" && ((lt = (X = window == null ? void 0 : window.CSS) == null ? void 0 : X.supports) == null ? void 0 : lt.call(X, "-webkit-touch-callout", "none"))
    }), V = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]({
        prev: [
            (ut = l.current) == null ? void 0 : ut.selectionStart,
            (dt = l.current) == null ? void 0 : dt.selectionEnd,
            (ft = l.current) == null ? void 0 : ft.selectionDirection
        ]
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](B, {
        "Lt.useImperativeHandle": ()=>l.current
    }["Lt.useImperativeHandle"], []), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            let t = l.current, o = K.current;
            if (!t || !o) return;
            J.current.value !== t.value && J.current.onChange(t.value), V.current.prev = [
                t.selectionStart,
                t.selectionEnd,
                t.selectionDirection
            ];
            function d() {
                if (document.activeElement !== t) {
                    L(null), N(null);
                    return;
                }
                let c = t.selectionStart, b = t.selectionEnd, mt = t.selectionDirection, v = t.maxLength, C = t.value, _ = V.current.prev, g = -1, E = -1, w;
                if (C.length !== 0 && c !== null && b !== null) {
                    let Dt = c === b, Ht = c === C.length && C.length < v;
                    if (Dt && !Ht) {
                        let y = c;
                        if (y === 0) g = 0, E = 1, w = "forward";
                        else if (y === v) g = y - 1, E = y, w = "backward";
                        else if (v > 1 && C.length > 1) {
                            let et = 0;
                            if (_[0] !== null && _[1] !== null) {
                                w = y < _[1] ? "backward" : "forward";
                                let Wt = _[0] === _[1] && _[0] < v;
                                w === "backward" && !Wt && (et = -1);
                            }
                            g = et + y, E = et + y + 1;
                        }
                    }
                    g !== -1 && E !== -1 && g !== E && l.current.setSelectionRange(g, E, w);
                }
                let pt = g !== -1 ? g : c, Rt = E !== -1 ? E : b, yt = w != null ? w : mt;
                L(pt), N(Rt), V.current.prev = [
                    pt,
                    Rt,
                    yt
                ];
            }
            if (document.addEventListener("selectionchange", d, {
                capture: !0
            }), d(), document.activeElement === t && Q(!0), !document.getElementById("input-otp-style")) {
                let c = document.createElement("style");
                if (c.id = "input-otp-style", document.head.appendChild(c), c.sheet) {
                    let b = "background: transparent !important; color: transparent !important; border-color: transparent !important; opacity: 0 !important; box-shadow: none !important; -webkit-box-shadow: none !important; -webkit-text-fill-color: transparent !important;";
                    $(c.sheet, "[data-input-otp]::selection { background: transparent !important; color: transparent !important; }"), $(c.sheet, `[data-input-otp]:autofill { ${b} }`), $(c.sheet, `[data-input-otp]:-webkit-autofill { ${b} }`), $(c.sheet, "@supports (-webkit-touch-callout: none) { [data-input-otp] { letter-spacing: -.6em !important; font-weight: 100 !important; font-stretch: ultra-condensed; font-optical-sizing: none !important; left: -1px !important; right: 1px !important; } }"), $(c.sheet, "[data-input-otp] + * { pointer-events: all !important; }");
                }
            }
            let R = {
                "Lt.useEffect.R": ()=>{
                    o && o.style.setProperty("--root-height", `${t.clientHeight}px`);
                }
            }["Lt.useEffect.R"];
            R();
            let p = new ResizeObserver(R);
            return p.observe(t), ({
                "Lt.useEffect": ()=>{
                    document.removeEventListener("selectionchange", d, {
                        capture: !0
                    }), p.disconnect();
                }
            })["Lt.useEffect"];
        }
    }["Lt.useEffect"], []);
    let [ot, rt] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [j, Q] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](!1), [M, L] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null), [k, N] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            ht({
                "Lt.useEffect": ()=>{
                    var R, p, c, b;
                    (R = l.current) == null || R.dispatchEvent(new Event("input"));
                    let t = (p = l.current) == null ? void 0 : p.selectionStart, o = (c = l.current) == null ? void 0 : c.selectionEnd, d = (b = l.current) == null ? void 0 : b.selectionDirection;
                    t !== null && o !== null && (L(t), N(o), V.current.prev = [
                        t,
                        o,
                        d
                    ]);
                }
            }["Lt.useEffect"]);
        }
    }["Lt.useEffect"], [
        i,
        j
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "Lt.useEffect": ()=>{
            I !== void 0 && i !== I && I.length < e && i.length === e && (H == null || H(i));
        }
    }["Lt.useEffect"], [
        e,
        H,
        I,
        i
    ]);
    let O = Tt({
        containerRef: K,
        inputRef: l,
        pushPasswordManagerStrategy: F,
        isFocused: j
    }), st = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[st]": (t)=>{
            let o = t.currentTarget.value.slice(0, e);
            if (o.length > 0 && m && !m.test(o)) {
                t.preventDefault();
                return;
            }
            typeof I == "string" && o.length < I.length && document.dispatchEvent(new Event("selectionchange")), x(o);
        }
    }["Lt.useCallback[st]"], [
        e,
        x,
        I,
        m
    ]), at = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[at]": ()=>{
            var t;
            if (l.current) {
                let o = Math.min(l.current.value.length, e - 1), d = l.current.value.length;
                (t = l.current) == null || t.setSelectionRange(o, d), L(o), N(d);
            }
            Q(!0);
        }
    }["Lt.useCallback[at]"], [
        e
    ]), ct = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "Lt.useCallback[ct]": (t)=>{
            var g, E;
            let o = l.current;
            if (!W && (!J.current.isIOS || !t.clipboardData || !o)) return;
            let d = t.clipboardData.getData("text/plain"), R = W ? W(d) : d;
            t.preventDefault();
            let p = (g = l.current) == null ? void 0 : g.selectionStart, c = (E = l.current) == null ? void 0 : E.selectionEnd, v = (p !== c ? i.slice(0, p) + R + i.slice(c) : i.slice(0, p) + R + i.slice(p)).slice(0, e);
            if (v.length > 0 && m && !m.test(v)) return;
            o.value = v, x(v);
            let C = Math.min(v.length, e - 1), _ = v.length;
            o.setSelectionRange(C, _), L(C), N(_);
        }
    }["Lt.useCallback[ct]"], [
        e,
        x,
        m,
        i
    ]), It = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[It]": ()=>({
                position: "relative",
                cursor: a.disabled ? "default" : "text",
                userSelect: "none",
                WebkitUserSelect: "none",
                pointerEvents: "none"
            })
    }["Lt.useMemo[It]"], [
        a.disabled
    ]), it = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[it]": ()=>({
                position: "absolute",
                inset: 0,
                width: O.willPushPWMBadge ? `calc(100% + ${O.PWM_BADGE_SPACE_WIDTH})` : "100%",
                clipPath: O.willPushPWMBadge ? `inset(0 ${O.PWM_BADGE_SPACE_WIDTH} 0 0)` : void 0,
                height: "100%",
                display: "flex",
                textAlign: u,
                opacity: "1",
                color: "transparent",
                pointerEvents: "all",
                background: "transparent",
                caretColor: "transparent",
                border: "0 solid transparent",
                outline: "0 solid transparent",
                boxShadow: "none",
                lineHeight: "1",
                letterSpacing: "-.5em",
                fontSize: "var(--root-height)",
                fontFamily: "monospace",
                fontVariantNumeric: "tabular-nums"
            })
    }["Lt.useMemo[it]"], [
        O.PWM_BADGE_SPACE_WIDTH,
        O.willPushPWMBadge,
        u
    ]), Mt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[Mt]": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("input", bt(St({
                autoComplete: a.autoComplete || "one-time-code"
            }, a), {
                "data-input-otp": !0,
                "data-input-otp-placeholder-shown": i.length === 0 || void 0,
                "data-input-otp-mss": M,
                "data-input-otp-mse": k,
                inputMode: G,
                pattern: m == null ? void 0 : m.source,
                "aria-placeholder": D,
                style: it,
                maxLength: e,
                value: i,
                ref: l,
                onPaste: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        ct(t), (o = a.onPaste) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onChange: st,
                onMouseOver: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        rt(!0), (o = a.onMouseOver) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onMouseLeave: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        rt(!1), (o = a.onMouseLeave) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onFocus: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        at(), (o = a.onFocus) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"],
                onBlur: {
                    "Lt.useMemo[Mt]": (t)=>{
                        var o;
                        Q(!1), (o = a.onBlur) == null || o.call(a, t);
                    }
                }["Lt.useMemo[Mt]"]
            }))
    }["Lt.useMemo[Mt]"], [
        st,
        at,
        ct,
        G,
        it,
        e,
        k,
        M,
        a,
        m == null ? void 0 : m.source,
        i
    ]), tt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[tt]": ()=>({
                slots: Array.from({
                    length: e
                }).map({
                    "Lt.useMemo[tt]": (t, o)=>{
                        var c;
                        let d = j && M !== null && k !== null && (M === k && o === M || o >= M && o < k), R = i[o] !== void 0 ? i[o] : null, p = i[0] !== void 0 ? null : (c = D == null ? void 0 : D[o]) != null ? c : null;
                        return {
                            char: R,
                            placeholderChar: p,
                            isActive: d,
                            hasFakeCaret: d && R === null
                        };
                    }
                }["Lt.useMemo[tt]"]),
                isFocused: j,
                isHovering: !a.disabled && ot
            })
    }["Lt.useMemo[tt]"], [
        j,
        ot,
        e,
        k,
        M,
        a.disabled,
        i
    ]), Ct = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Lt.useMemo[Ct]": ()=>f ? f(tt) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](jt.Provider, {
                value: tt
            }, h)
    }["Lt.useMemo[Ct]"], [
        h,
        tt,
        f
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, T !== null && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("noscript", null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("style", null, T)), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("div", {
        ref: K,
        "data-input-otp-container": !0,
        style: It,
        className: Z
    }, Ct, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$7_$40$babel$2b$core$40$7$2e$29$2e$7_$40$opentelemetry$2b$api$40$1$2e$9$2e$1_$40$playwright$2b$test$40$1$2e$61$2e$1_react$2d$dom$40$19$2e$_oaiqmtf7py6tq5l47izuf7xccm$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("div", {
        style: {
            position: "absolute",
            inset: 0,
            pointerEvents: "none"
        }
    }, Mt)));
});
Lt.displayName = "Input";
function $(r, s) {
    try {
        r.insertRule(s);
    } catch (e) {
        console.error("input-otp could not insert CSS rule:", s);
    }
}
var Nt = `
[data-input-otp] {
  --nojs-bg: white !important;
  --nojs-fg: black !important;

  background-color: var(--nojs-bg) !important;
  color: var(--nojs-fg) !important;
  caret-color: var(--nojs-fg) !important;
  letter-spacing: .25em !important;
  text-align: center !important;
  border: 1px solid var(--nojs-fg) !important;
  border-radius: 4px !important;
  width: 100% !important;
}
@media (prefers-color-scheme: dark) {
  [data-input-otp] {
    --nojs-bg: black !important;
    --nojs-fg: white !important;
  }
}`;
var Kt = "^\\d+$", Jt = "^[a-zA-Z]+$", Qt = "^[a-zA-Z0-9]+$";
;
}),
]);

//# sourceMappingURL=node_modules__pnpm_1cpqu6k._.js.map