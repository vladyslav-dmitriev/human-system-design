(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LogLevel",
    ()=>LogLevel
]);
var LogLevel;
(function(LogLevel) {
    LogLevel[LogLevel["None"] = 0] = "None";
    LogLevel[LogLevel["Error"] = 1] = "Error";
    LogLevel[LogLevel["Warn"] = 2] = "Warn";
    LogLevel[LogLevel["Verbose"] = 3] = "Verbose";
    LogLevel[LogLevel["Debug"] = 4] = "Debug";
})(LogLevel || (LogLevel = {}));
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/debug.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "debugWrapper",
    ()=>debugWrapper,
    "getClientLogConfig",
    ()=>getClientLogConfig,
    "getClientStates",
    ()=>getClientStates,
    "getStacktrace",
    ()=>getStacktrace,
    "getValueByStringPath",
    ()=>getValueByStringPath
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)");
;
;
var getStacktrace = function(ignoreDepth) {
    if (ignoreDepth === void 0) {
        ignoreDepth = 0;
    }
    var trace = new Error().stack || '';
    return trace.split('\n').slice(2 + ignoreDepth).map(function(text) {
        return text.trim();
    });
};
var getClientLogConfig = function(client) {
    return function() {
        var _a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, client.config), logger = _a.loggerProvider, logLevel = _a.logLevel;
        return {
            logger: logger,
            logLevel: logLevel
        };
    };
};
var getValueByStringPath = function(obj, path) {
    var e_1, _a;
    path = path.replace(/\[(\w+)\]/g, '.$1'); // convert indexes to properties
    path = path.replace(/^\./, ''); // strip a leading dot
    try {
        for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(path.split('.')), _c = _b.next(); !_c.done; _c = _b.next()){
            var attr = _c.value;
            if (attr in obj) {
                obj = obj[attr];
            } else {
                return;
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    return obj;
};
var getClientStates = function(client, paths) {
    return function() {
        var e_2, _a;
        var res = {};
        try {
            for(var paths_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(paths), paths_1_1 = paths_1.next(); !paths_1_1.done; paths_1_1 = paths_1.next()){
                var path = paths_1_1.value;
                res[path] = getValueByStringPath(client, path);
            }
        } catch (e_2_1) {
            e_2 = {
                error: e_2_1
            };
        } finally{
            try {
                if (paths_1_1 && !paths_1_1.done && (_a = paths_1.return)) _a.call(paths_1);
            } finally{
                if (e_2) throw e_2.error;
            }
        }
        return res;
    };
};
var debugWrapper = function(fn, fnName, getLogConfig, getStates, fnContext) {
    if (fnContext === void 0) {
        fnContext = null;
    }
    return function() {
        var args = [];
        for(var _i = 0; _i < arguments.length; _i++){
            args[_i] = arguments[_i];
        }
        var _a = getLogConfig(), logger = _a.logger, logLevel = _a.logLevel;
        // return early if possible to reduce overhead
        if (logLevel && logLevel < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Debug || !logLevel || !logger) {
            return fn.apply(fnContext, args);
        }
        var debugContext = {
            type: 'invoke public method',
            name: fnName,
            args: args,
            stacktrace: getStacktrace(1),
            time: {
                start: new Date().toISOString()
            },
            states: {}
        };
        if (getStates && debugContext.states) {
            debugContext.states.before = getStates();
        }
        var result = fn.apply(fnContext, args);
        if (result && result.promise) {
            // if result is a promise, add the callback
            result.promise.then(function() {
                if (getStates && debugContext.states) {
                    debugContext.states.after = getStates();
                }
                if (debugContext.time) {
                    debugContext.time.end = new Date().toISOString();
                }
                logger.debug(JSON.stringify(debugContext, null, 2));
            });
        } else {
            if (getStates && debugContext.states) {
                debugContext.states.after = getStates();
            }
            if (debugContext.time) {
                debugContext.time.end = new Date().toISOString();
            }
            logger.debug(JSON.stringify(debugContext, null, 2));
        }
        return result;
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IdentifyOperation",
    ()=>IdentifyOperation,
    "SpecialEventType",
    ()=>SpecialEventType
]);
var IdentifyOperation;
(function(IdentifyOperation) {
    // Base Operations to set values
    IdentifyOperation["SET"] = "$set";
    IdentifyOperation["SET_ONCE"] = "$setOnce";
    // Operations around modifying existing values
    IdentifyOperation["ADD"] = "$add";
    IdentifyOperation["APPEND"] = "$append";
    IdentifyOperation["PREPEND"] = "$prepend";
    IdentifyOperation["REMOVE"] = "$remove";
    // Operations around appending values *if* they aren't present
    IdentifyOperation["PREINSERT"] = "$preInsert";
    IdentifyOperation["POSTINSERT"] = "$postInsert";
    // Operations around removing properties/values
    IdentifyOperation["UNSET"] = "$unset";
    IdentifyOperation["CLEAR_ALL"] = "$clearAll";
})(IdentifyOperation || (IdentifyOperation = {}));
var SpecialEventType;
(function(SpecialEventType) {
    SpecialEventType["IDENTIFY"] = "$identify";
    SpecialEventType["GROUP_IDENTIFY"] = "$groupidentify";
    SpecialEventType["REVENUE"] = "revenue_amount";
})(SpecialEventType || (SpecialEventType = {}));
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AMPLITUDE_BATCH_SERVER_URL",
    ()=>AMPLITUDE_BATCH_SERVER_URL,
    "AMPLITUDE_PREFIX",
    ()=>AMPLITUDE_PREFIX,
    "AMPLITUDE_SERVER_URL",
    ()=>AMPLITUDE_SERVER_URL,
    "BASE_CAMPAIGN",
    ()=>BASE_CAMPAIGN,
    "DCLID",
    ()=>DCLID,
    "DEFAULT_INSTANCE_NAME",
    ()=>DEFAULT_INSTANCE_NAME,
    "EMPTY_VALUE",
    ()=>EMPTY_VALUE,
    "EU_AMPLITUDE_BATCH_SERVER_URL",
    ()=>EU_AMPLITUDE_BATCH_SERVER_URL,
    "EU_AMPLITUDE_SERVER_URL",
    ()=>EU_AMPLITUDE_SERVER_URL,
    "FBCLID",
    ()=>FBCLID,
    "FORBIDDEN_HEADERS",
    ()=>FORBIDDEN_HEADERS,
    "GBRAID",
    ()=>GBRAID,
    "GCLID",
    ()=>GCLID,
    "KO_CLICK_ID",
    ()=>KO_CLICK_ID,
    "LI_FAT_ID",
    ()=>LI_FAT_ID,
    "MKTG",
    ()=>MKTG,
    "MSCLKID",
    ()=>MSCLKID,
    "RDT_CID",
    ()=>RDT_CID,
    "SAFE_HEADERS",
    ()=>SAFE_HEADERS,
    "STORAGE_PREFIX",
    ()=>STORAGE_PREFIX,
    "TTCLID",
    ()=>TTCLID,
    "TWCLID",
    ()=>TWCLID,
    "UNSET_VALUE",
    ()=>UNSET_VALUE,
    "UTM_CAMPAIGN",
    ()=>UTM_CAMPAIGN,
    "UTM_CONTENT",
    ()=>UTM_CONTENT,
    "UTM_ID",
    ()=>UTM_ID,
    "UTM_MEDIUM",
    ()=>UTM_MEDIUM,
    "UTM_SOURCE",
    ()=>UTM_SOURCE,
    "UTM_TERM",
    ()=>UTM_TERM,
    "WBRAID",
    ()=>WBRAID
]);
var UNSET_VALUE = '-';
var AMPLITUDE_PREFIX = 'AMP';
var STORAGE_PREFIX = "".concat(AMPLITUDE_PREFIX, "_unsent");
var DEFAULT_INSTANCE_NAME = '$default_instance';
var AMPLITUDE_SERVER_URL = 'https://api2.amplitude.com/2/httpapi';
var EU_AMPLITUDE_SERVER_URL = 'https://api.eu.amplitude.com/2/httpapi';
var AMPLITUDE_BATCH_SERVER_URL = 'https://api2.amplitude.com/batch';
var EU_AMPLITUDE_BATCH_SERVER_URL = 'https://api.eu.amplitude.com/batch';
var UTM_CAMPAIGN = 'utm_campaign';
var UTM_CONTENT = 'utm_content';
var UTM_ID = 'utm_id';
var UTM_MEDIUM = 'utm_medium';
var UTM_SOURCE = 'utm_source';
var UTM_TERM = 'utm_term';
var DCLID = 'dclid';
var FBCLID = 'fbclid';
var GBRAID = 'gbraid';
var GCLID = 'gclid';
var KO_CLICK_ID = 'ko_click_id';
var LI_FAT_ID = 'li_fat_id';
var MSCLKID = 'msclkid';
var RDT_CID = 'rdt_cid';
var TTCLID = 'ttclid';
var TWCLID = 'twclid';
var WBRAID = 'wbraid';
var EMPTY_VALUE = 'EMPTY';
var BASE_CAMPAIGN = {
    utm_campaign: undefined,
    utm_content: undefined,
    utm_id: undefined,
    utm_medium: undefined,
    utm_source: undefined,
    utm_term: undefined,
    referrer: undefined,
    referring_domain: undefined,
    dclid: undefined,
    gbraid: undefined,
    gclid: undefined,
    fbclid: undefined,
    ko_click_id: undefined,
    li_fat_id: undefined,
    msclkid: undefined,
    rdt_cid: undefined,
    ttclid: undefined,
    twclid: undefined,
    wbraid: undefined
};
var MKTG = 'MKTG';
var SAFE_HEADERS = [
    'access-control-allow-origin',
    'access-control-allow-credentials',
    'access-control-expose-headers',
    'access-control-max-age',
    'access-control-allow-methods',
    'access-control-allow-headers',
    'accept-patch',
    'accept-ranges',
    'age',
    'allow',
    'alt-svc',
    'cache-control',
    'connection',
    'content-disposition',
    'content-encoding',
    'content-language',
    'content-length',
    'content-location',
    'content-md5',
    'content-range',
    'content-type',
    'date',
    'delta-base',
    'etag',
    'expires',
    'im',
    'last-modified',
    'link',
    'location',
    'permanent',
    'p3p',
    'pragma',
    'proxy-authenticate',
    'public-key-pins',
    'retry-after',
    'server',
    'status',
    'strict-transport-security',
    'trailer',
    'transfer-encoding',
    'tk',
    'upgrade',
    'vary',
    'via',
    'warning',
    'www-authenticate',
    'x-b3-traceid',
    'x-frame-options'
];
var FORBIDDEN_HEADERS = [
    'authorization',
    'cookie',
    'set-cookie'
];
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/valid-properties.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isValidObject",
    ()=>isValidObject,
    "isValidProperties",
    ()=>isValidProperties
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var MAX_PROPERTY_KEYS = 1000;
var isValidObject = function(properties) {
    if (Object.keys(properties).length > MAX_PROPERTY_KEYS) {
        return false;
    }
    for(var key in properties){
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        var value = properties[key];
        if (!isValidProperties(key, value)) return false;
    }
    return true;
};
var isValidProperties = function(property, value) {
    var e_1, _a;
    if (typeof property !== 'string') return false;
    if (Array.isArray(value)) {
        var isValid = true;
        try {
            for(var value_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(value), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()){
                var valueElement = value_1_1.value;
                if (Array.isArray(valueElement)) {
                    return false;
                } else if (typeof valueElement === 'object') {
                    isValid = isValid && isValidObject(valueElement);
                } else if (![
                    'number',
                    'string'
                ].includes(typeof valueElement)) {
                    return false;
                }
                if (!isValid) {
                    return false;
                }
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (value_1_1 && !value_1_1.done && (_a = value_1.return)) _a.call(value_1);
            } finally{
                if (e_1) throw e_1.error;
            }
        }
    } else if (value === null || value === undefined) {
        return false;
    } else if (typeof value === 'object') {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
        return isValidObject(value);
    } else if (![
        'number',
        'string',
        'boolean'
    ].includes(typeof value)) {
        return false;
    }
    return true;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/identify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Identify",
    ()=>Identify,
    "IdentifyOperation",
    ()=>IdentifyOperation,
    "OrderedIdentifyOperations",
    ()=>OrderedIdentifyOperations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$valid$2d$properties$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/valid-properties.js [app-client] (ecmascript)");
;
;
;
var Identify = function() {
    function Identify() {
        this._propertySet = new Set();
        this._properties = {};
    }
    Identify.prototype.getUserProperties = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this._properties);
    };
    Identify.prototype.set = function(property, value) {
        this._safeSet(IdentifyOperation.SET, property, value);
        return this;
    };
    Identify.prototype.setOnce = function(property, value) {
        this._safeSet(IdentifyOperation.SET_ONCE, property, value);
        return this;
    };
    Identify.prototype.append = function(property, value) {
        this._safeSet(IdentifyOperation.APPEND, property, value);
        return this;
    };
    Identify.prototype.prepend = function(property, value) {
        this._safeSet(IdentifyOperation.PREPEND, property, value);
        return this;
    };
    Identify.prototype.postInsert = function(property, value) {
        this._safeSet(IdentifyOperation.POSTINSERT, property, value);
        return this;
    };
    Identify.prototype.preInsert = function(property, value) {
        this._safeSet(IdentifyOperation.PREINSERT, property, value);
        return this;
    };
    Identify.prototype.remove = function(property, value) {
        this._safeSet(IdentifyOperation.REMOVE, property, value);
        return this;
    };
    Identify.prototype.add = function(property, value) {
        this._safeSet(IdentifyOperation.ADD, property, value);
        return this;
    };
    Identify.prototype.unset = function(property) {
        this._safeSet(IdentifyOperation.UNSET, property, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNSET_VALUE"]);
        return this;
    };
    Identify.prototype.clearAll = function() {
        // When clear all happens, all properties are unset. Reset the entire object.
        this._properties = {};
        this._properties[IdentifyOperation.CLEAR_ALL] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNSET_VALUE"];
        return this;
    };
    // Returns whether or not this set actually worked.
    Identify.prototype._safeSet = function(operation, property, value) {
        if (this._validate(operation, property, value)) {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            var userPropertyMap = this._properties[operation];
            if (userPropertyMap === undefined) {
                userPropertyMap = {};
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                this._properties[operation] = userPropertyMap;
            }
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            userPropertyMap[property] = value;
            this._propertySet.add(property);
            return true;
        }
        return false;
    };
    Identify.prototype._validate = function(operation, property, value) {
        if (this._properties[IdentifyOperation.CLEAR_ALL] !== undefined) {
            // clear all already set. Skipping operation;
            return false;
        }
        if (this._propertySet.has(property)) {
            // Property already used. Skipping operation
            return false;
        }
        if (operation === IdentifyOperation.ADD) {
            return typeof value === 'number';
        }
        if (operation !== IdentifyOperation.UNSET && operation !== IdentifyOperation.REMOVE) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$valid$2d$properties$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidProperties"])(property, value);
        }
        return true;
    };
    return Identify;
}();
;
var IdentifyOperation;
(function(IdentifyOperation) {
    // Base Operations to set values
    IdentifyOperation["SET"] = "$set";
    IdentifyOperation["SET_ONCE"] = "$setOnce";
    // Operations around modifying existing values
    IdentifyOperation["ADD"] = "$add";
    IdentifyOperation["APPEND"] = "$append";
    IdentifyOperation["PREPEND"] = "$prepend";
    IdentifyOperation["REMOVE"] = "$remove";
    // Operations around appending values *if* they aren't present
    IdentifyOperation["PREINSERT"] = "$preInsert";
    IdentifyOperation["POSTINSERT"] = "$postInsert";
    // Operations around removing properties/values
    IdentifyOperation["UNSET"] = "$unset";
    IdentifyOperation["CLEAR_ALL"] = "$clearAll";
})(IdentifyOperation || (IdentifyOperation = {}));
var OrderedIdentifyOperations = [
    IdentifyOperation.CLEAR_ALL,
    IdentifyOperation.UNSET,
    IdentifyOperation.SET,
    IdentifyOperation.SET_ONCE,
    IdentifyOperation.ADD,
    IdentifyOperation.APPEND,
    IdentifyOperation.PREPEND,
    IdentifyOperation.PREINSERT,
    IdentifyOperation.POSTINSERT,
    IdentifyOperation.REMOVE
];
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/messages.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CLIENT_NOT_INITIALIZED",
    ()=>CLIENT_NOT_INITIALIZED,
    "INVALID_API_KEY",
    ()=>INVALID_API_KEY,
    "MAX_RETRIES_EXCEEDED_MESSAGE",
    ()=>MAX_RETRIES_EXCEEDED_MESSAGE,
    "MISSING_API_KEY_MESSAGE",
    ()=>MISSING_API_KEY_MESSAGE,
    "OPT_OUT_MESSAGE",
    ()=>OPT_OUT_MESSAGE,
    "SUCCESS_MESSAGE",
    ()=>SUCCESS_MESSAGE,
    "UNEXPECTED_ERROR_MESSAGE",
    ()=>UNEXPECTED_ERROR_MESSAGE
]);
var SUCCESS_MESSAGE = 'Event tracked successfully';
var UNEXPECTED_ERROR_MESSAGE = 'Unexpected error occurred';
var MAX_RETRIES_EXCEEDED_MESSAGE = 'Event rejected due to exceeded retry count';
var OPT_OUT_MESSAGE = 'Event skipped due to optOut config';
var MISSING_API_KEY_MESSAGE = 'Event rejected due to missing API key';
var INVALID_API_KEY = 'Invalid API key';
var CLIENT_NOT_INITIALIZED = 'Client not initialized';
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/status.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** The status of an event. */ __turbopack_context__.s([
    "Status",
    ()=>Status
]);
var Status;
(function(Status) {
    /** The status could not be determined. */ Status["Unknown"] = "unknown";
    /** The event was skipped due to configuration or callbacks. */ Status["Skipped"] = "skipped";
    /** The event was sent successfully. */ Status["Success"] = "success";
    /** A user or device in the payload is currently rate limited and should try again later. */ Status["RateLimit"] = "rate_limit";
    /** The sent payload was too large to be processed. */ Status["PayloadTooLarge"] = "payload_too_large";
    /** The event could not be processed. */ Status["Invalid"] = "invalid";
    /** A server-side error ocurred during submission. */ Status["Failed"] = "failed";
    /** a server or client side error occuring when a request takes too long and is cancelled */ Status["Timeout"] = "Timeout";
    /** NodeJS runtime environment error.. E.g. disconnected from network */ Status["SystemError"] = "SystemError";
})(Status || (Status = {}));
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/result-builder.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildResult",
    ()=>buildResult
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/status.js [app-client] (ecmascript)");
;
var buildResult = function(event, code, message) {
    if (code === void 0) {
        code = 0;
    }
    if (message === void 0) {
        message = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Unknown;
    }
    return {
        event: event,
        code: code,
        message: message
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable no-restricted-globals */ /* Only file allowed to access to globalThis, window, self */ __turbopack_context__.s([
    "getGlobalScope",
    ()=>getGlobalScope
]);
var getGlobalScope = function() {
    // This should only be used for integrations with Amplitude that are not running in a browser environment
    //   We need to specify the name of the global variable as a string to prevent it from being minified
    var ampIntegrationContextName = 'ampIntegrationContext';
    if (typeof globalThis !== 'undefined' && typeof globalThis[ampIntegrationContextName] !== 'undefined') {
        return globalThis[ampIntegrationContextName];
    }
    if (typeof globalThis !== 'undefined') {
        return globalThis;
    }
    if (typeof window !== 'undefined') {
        return window;
    }
    if (typeof self !== 'undefined') {
        return self;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        return /*TURBOPACK member replacement*/ __turbopack_context__.g;
    }
    //TURBOPACK unreachable
    ;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UUID",
    ()=>UUID
]);
/**
 * Source: [jed's gist's comment]{@link https://gist.github.com/jed/982883?permalink_comment_id=3223002#gistcomment-3223002}.
 * Returns a random v4 UUID of the form xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx,
 * where each x is replaced with a random hexadecimal digit from 0 to f, and
 * y is replaced with a random hexadecimal digit from 8 to b.
 * Used to generate UUIDs for deviceIds.
 * @private
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
var legacyUUID = function(a) {
    return a // if the placeholder was passed, return
     ? (a ^ Math.random() * // in which case
    16 >> a / 4) // 8 to 11
    .toString(16) // in hexadecimal
     : (String(1e7) + // 10000000 +
    String(-1e3) + // -1000 +
    String(-4e3) + // -4000 +
    String(-8e3) + // -80000000 +
    String(-1e11)) // -100000000000,
    .replace(// replacing
    /[018]/g, UUID);
};
var hex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(Array(256).keys()), false).map(function(index) {
    return index.toString(16).padStart(2, '0');
});
var UUID = function(a) {
    var _a;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore next */ if (!((_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.crypto) === null || _a === void 0 ? void 0 : _a.getRandomValues)) {
        // Fallback to legacy UUID generation if crypto is not available
        return legacyUUID(a);
    }
    var r = globalScope.crypto.getRandomValues(new Uint8Array(16));
    r[6] = r[6] & 0x0f | 0x40;
    r[8] = r[8] & 0x3f | 0x80;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(r.entries()), false).map(function(_a) {
        var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), index = _b[0], int = _b[1];
        return [
            4,
            6,
            8,
            10
        ].includes(index) ? "-".concat(hex[int]) : hex[int];
    }).join('');
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/timeline.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Timeline",
    ()=>Timeline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/result-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
;
;
;
var Timeline = function() {
    function Timeline(client) {
        this.client = client;
        this.queue = [];
        // Flag to guarantee one schedule apply is running
        this.applying = false;
        this.plugins = [];
        // Locks plugin names synchronously before `await plugin.setup?.()` so a concurrent
        // register() with the same name bails. plugins[] only contains fully-installed plugins,
        // so this map is the only source of truth for in-flight installs. Cleared per-name by
        // deregister() and en masse by reset().
        this.pluginStatus = new Map();
        this._optOutListeners = [];
    }
    Timeline.prototype.register = function(plugin, config) {
        var _a, _b;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var name;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_c) {
                switch(_c.label){
                    case 0:
                        if (plugin.name === undefined) {
                            plugin.name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
                            this.loggerProvider.warn("Plugin name is undefined.\n      Generating a random UUID for plugin name: ".concat(plugin.name, ".\n      Set a name for the plugin to prevent it from being added multiple times."));
                        }
                        name = plugin.name;
                        if (this.pluginStatus.has(name)) {
                            this.loggerProvider.warn("Plugin with name ".concat(name, " already exists, skipping registration"));
                            return [
                                2 /*return*/ 
                            ];
                        }
                        plugin.type = (_a = plugin.type) !== null && _a !== void 0 ? _a : 'enrichment';
                        // Lock the name synchronously to close the TOCTOU window across `await setup`.
                        // If setup throws, the entry stays as 'locked' and blocks future re-registration —
                        // a same-named plugin would just fail again, so retry isn't useful.
                        this.pluginStatus.set(name, 'locked');
                        return [
                            4 /*yield*/ ,
                            (_b = plugin.setup) === null || _b === void 0 ? void 0 : _b.call(plugin, config, this.client)
                        ];
                    case 1:
                        _c.sent();
                        // reset() may have cleared the status map while setup was awaiting.
                        if (this.pluginStatus.get(name) !== 'locked') {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        this.plugins.push(plugin);
                        this.pluginStatus.set(name, 'installed');
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Timeline.prototype.deregister = function(pluginName, config) {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var index, plugin;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        // Clear the status first so a name stuck in 'locked' (mid-install, or setup() threw)
                        // can be unlocked via deregister(). Map.delete is a no-op if the key is missing.
                        this.pluginStatus.delete(pluginName);
                        index = this.plugins.findIndex(function(plugin) {
                            return plugin.name === pluginName;
                        });
                        if (index === -1) {
                            config.loggerProvider.warn("Plugin with name ".concat(pluginName, " does not exist, skipping deregistration"));
                            return [
                                2 /*return*/ 
                            ];
                        }
                        plugin = this.plugins[index];
                        this.plugins.splice(index, 1);
                        return [
                            4 /*yield*/ ,
                            (_a = plugin.teardown) === null || _a === void 0 ? void 0 : _a.call(plugin)
                        ];
                    case 1:
                        _b.sent();
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Timeline.prototype.reset = function(client) {
        this._clearOptOutListeners();
        this.applying = false;
        var plugins = this.plugins;
        plugins.map(function(plugin) {
            var _a;
            return (_a = plugin.teardown) === null || _a === void 0 ? void 0 : _a.call(plugin);
        });
        this.plugins = [];
        this.pluginStatus.clear();
        this.client = client;
    };
    Timeline.prototype.push = function(event) {
        var _this = this;
        return new Promise(function(resolve) {
            _this.queue.push([
                event,
                resolve
            ]);
            _this.scheduleApply(0);
        });
    };
    Timeline.prototype.scheduleApply = function(timeout) {
        var _this = this;
        if (this.applying) return;
        this.applying = true;
        setTimeout(function() {
            void _this.apply(_this.queue.shift()).then(function() {
                _this.applying = false;
                if (_this.queue.length > 0) {
                    _this.scheduleApply(0);
                }
            });
        }, timeout);
    };
    Timeline.prototype.apply = function(item) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var _a, event, _b, resolve, before, before_1, before_1_1, plugin, e, e_1_1, enrichment, enrichment_1, enrichment_1_1, plugin, e, e_2_1, destination, executeDestinations;
            var e_1, _c, e_2, _d;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_e) {
                switch(_e.label){
                    case 0:
                        if (!item) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        _a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(item, 1), event = _a[0];
                        _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(item, 2), resolve = _b[1];
                        // Log initial event
                        this.loggerProvider.log('Timeline.apply: Initial event', event);
                        before = this.plugins.filter(function(plugin) {
                            return plugin.type === 'before';
                        });
                        _e.label = 1;
                    case 1:
                        _e.trys.push([
                            1,
                            6,
                            7,
                            8
                        ]);
                        before_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(before), before_1_1 = before_1.next();
                        _e.label = 2;
                    case 2:
                        if (!!before_1_1.done) return [
                            3 /*break*/ ,
                            5
                        ];
                        plugin = before_1_1.value;
                        /* istanbul ignore if */ if (!plugin.execute) {
                            // do nothing
                            return [
                                3 /*break*/ ,
                                4
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            plugin.execute((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event))
                        ];
                    case 3:
                        e = _e.sent();
                        if (e === null) {
                            this.loggerProvider.log("Timeline.apply: Event filtered out by before plugin '".concat(String(plugin.name), "', event: ").concat(JSON.stringify(event)));
                            resolve({
                                event: event,
                                code: 0,
                                message: ''
                            });
                            return [
                                2 /*return*/ 
                            ];
                        } else {
                            event = e;
                            this.loggerProvider.log("Timeline.apply: Event after before plugin '".concat(String(plugin.name), "', event: ").concat(JSON.stringify(event)));
                        }
                        _e.label = 4;
                    case 4:
                        before_1_1 = before_1.next();
                        return [
                            3 /*break*/ ,
                            2
                        ];
                    case 5:
                        return [
                            3 /*break*/ ,
                            8
                        ];
                    case 6:
                        e_1_1 = _e.sent();
                        e_1 = {
                            error: e_1_1
                        };
                        return [
                            3 /*break*/ ,
                            8
                        ];
                    case 7:
                        try {
                            if (before_1_1 && !before_1_1.done && (_c = before_1.return)) _c.call(before_1);
                        } finally{
                            if (e_1) throw e_1.error;
                        }
                        return [
                            7 /*endfinally*/ 
                        ];
                    case 8:
                        enrichment = this.plugins.filter(function(plugin) {
                            return plugin.type === 'enrichment' || plugin.type === undefined;
                        });
                        _e.label = 9;
                    case 9:
                        _e.trys.push([
                            9,
                            14,
                            15,
                            16
                        ]);
                        enrichment_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(enrichment), enrichment_1_1 = enrichment_1.next();
                        _e.label = 10;
                    case 10:
                        if (!!enrichment_1_1.done) return [
                            3 /*break*/ ,
                            13
                        ];
                        plugin = enrichment_1_1.value;
                        /* istanbul ignore if */ if (!plugin.execute) {
                            // do nothing
                            return [
                                3 /*break*/ ,
                                12
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            plugin.execute((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event))
                        ];
                    case 11:
                        e = _e.sent();
                        if (e === null) {
                            this.loggerProvider.log("Timeline.apply: Event filtered out by enrichment plugin '".concat(String(plugin.name), "', event: ").concat(JSON.stringify(event)));
                            resolve({
                                event: event,
                                code: 0,
                                message: ''
                            });
                            return [
                                2 /*return*/ 
                            ];
                        } else {
                            event = e;
                            this.loggerProvider.log("Timeline.apply: Event after enrichment plugin '".concat(String(plugin.name), "', event: ").concat(JSON.stringify(event)));
                        }
                        _e.label = 12;
                    case 12:
                        enrichment_1_1 = enrichment_1.next();
                        return [
                            3 /*break*/ ,
                            10
                        ];
                    case 13:
                        return [
                            3 /*break*/ ,
                            16
                        ];
                    case 14:
                        e_2_1 = _e.sent();
                        e_2 = {
                            error: e_2_1
                        };
                        return [
                            3 /*break*/ ,
                            16
                        ];
                    case 15:
                        try {
                            if (enrichment_1_1 && !enrichment_1_1.done && (_d = enrichment_1.return)) _d.call(enrichment_1);
                        } finally{
                            if (e_2) throw e_2.error;
                        }
                        return [
                            7 /*endfinally*/ 
                        ];
                    case 16:
                        destination = this.plugins.filter(function(plugin) {
                            return plugin.type === 'destination';
                        });
                        // Log final event before sending to destinations
                        this.loggerProvider.log("Timeline.apply: Final event before destinations, event: ".concat(JSON.stringify(event)));
                        executeDestinations = destination.map(function(plugin) {
                            var eventClone = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event);
                            return plugin.execute(eventClone).catch(function(e) {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildResult"])(eventClone, 0, String(e));
                            });
                        });
                        void Promise.all(executeDestinations).then(function(_a) {
                            var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 1), result = _b[0];
                            var resolveResult = result || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildResult"])(event, 100, 'Event not tracked, no destination plugins on the instance');
                            resolve(resolveResult);
                        });
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Timeline.prototype.flush = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var queue, destination, executeDestinations;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        queue = this.queue;
                        this.queue = [];
                        return [
                            4 /*yield*/ ,
                            Promise.all(queue.map(function(item) {
                                return _this.apply(item);
                            }))
                        ];
                    case 1:
                        _a.sent();
                        destination = this.plugins.filter(function(plugin) {
                            return plugin.type === 'destination';
                        });
                        executeDestinations = destination.map(function(plugin) {
                            return plugin.flush && plugin.flush();
                        });
                        return [
                            4 /*yield*/ ,
                            Promise.all(executeDestinations)
                        ];
                    case 2:
                        _a.sent();
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Timeline.prototype.addOptOutListener = function(cb) {
        this._optOutListeners.push(cb);
    };
    Timeline.prototype._clearOptOutListeners = function() {
        this._optOutListeners = [];
    };
    Timeline.prototype.onIdentityChanged = function(identity) {
        this.plugins.forEach(function(plugin) {
            var _a;
            // Intentionally to not await plugin.onIdentityChanged() for non-blocking.
            // Ignore optional channing next line for test coverage.
            // If the plugin doesn't implement it, it won't be called.
            /* istanbul ignore next */ void ((_a = plugin.onIdentityChanged) === null || _a === void 0 ? void 0 : _a.call(plugin, identity));
        });
    };
    Timeline.prototype.onSessionIdChanged = function(sessionId) {
        this.plugins.forEach(function(plugin) {
            var _a;
            // Intentionally to not await plugin.onSessionIdChanged() for non-blocking.
            // Ignore optional channing next line for test coverage.
            // If the plugin doesn't implement it, it won't be called.
            /* istanbul ignore next */ void ((_a = plugin.onSessionIdChanged) === null || _a === void 0 ? void 0 : _a.call(plugin, sessionId));
        });
    };
    Timeline.prototype.onOptOutChanged = function(optOut) {
        this.plugins.forEach(function(plugin) {
            var _a;
            // Intentionally to not await plugin.onOptOutChanged() for non-blocking.
            // Ignore optional channing next line for test coverage.
            // If the plugin doesn't implement it, it won't be called.
            /* istanbul ignore next */ void ((_a = plugin.onOptOutChanged) === null || _a === void 0 ? void 0 : _a.call(plugin, optOut));
        });
        void this._callOptOutListeners(optOut);
    };
    Timeline.prototype._callOptOutListeners = function(optOut) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var _a, _b, listener, e_3, e_4_1;
            var e_4, _c;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_d) {
                switch(_d.label){
                    case 0:
                        _d.trys.push([
                            0,
                            7,
                            8,
                            9
                        ]);
                        _a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(this._optOutListeners), _b = _a.next();
                        _d.label = 1;
                    case 1:
                        if (!!_b.done) return [
                            3 /*break*/ ,
                            6
                        ];
                        listener = _b.value;
                        _d.label = 2;
                    case 2:
                        _d.trys.push([
                            2,
                            4,
                            ,
                            5
                        ]);
                        return [
                            4 /*yield*/ ,
                            listener(optOut)
                        ];
                    case 3:
                        _d.sent();
                        return [
                            3 /*break*/ ,
                            5
                        ];
                    case 4:
                        e_3 = _d.sent();
                        /* istanbul ignore next */ this.loggerProvider.error('Error calling optOut listener', e_3);
                        return [
                            3 /*break*/ ,
                            5
                        ];
                    case 5:
                        _b = _a.next();
                        return [
                            3 /*break*/ ,
                            1
                        ];
                    case 6:
                        return [
                            3 /*break*/ ,
                            9
                        ];
                    case 7:
                        e_4_1 = _d.sent();
                        e_4 = {
                            error: e_4_1
                        };
                        return [
                            3 /*break*/ ,
                            9
                        ];
                    case 8:
                        try {
                            if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                        } finally{
                            if (e_4) throw e_4.error;
                        }
                        return [
                            7 /*endfinally*/ 
                        ];
                    case 9:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Timeline.prototype.onReset = function() {
        this.plugins.forEach(function(plugin) {
            var _a;
            // Intentionally to not await plugin.onReset() for non-blocking.
            // Ignore optional channing next line for test coverage.
            // If the plugin doesn't implement it, it won't be called.
            /* istanbul ignore next */ void ((_a = plugin.onReset) === null || _a === void 0 ? void 0 : _a.call(plugin));
        });
    };
    return Timeline;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/event-builder.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createGroupEvent",
    ()=>createGroupEvent,
    "createGroupIdentifyEvent",
    ()=>createGroupIdentifyEvent,
    "createIdentifyEvent",
    ()=>createIdentifyEvent,
    "createRevenueEvent",
    ()=>createRevenueEvent,
    "createTrackEvent",
    ()=>createTrackEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/identify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)");
;
;
;
var createTrackEvent = function(eventInput, eventProperties, eventOptions) {
    var baseEvent = typeof eventInput === 'string' ? {
        event_type: eventInput
    } : eventInput;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, baseEvent), eventOptions), eventProperties && {
        event_properties: eventProperties
    });
};
var createIdentifyEvent = function(identify, eventOptions) {
    var identifyEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, eventOptions), {
        event_type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].IDENTIFY,
        user_properties: identify.getUserProperties()
    });
    return identifyEvent;
};
var createGroupIdentifyEvent = function(groupType, groupName, identify, eventOptions) {
    var _a;
    var groupIdentify = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, eventOptions), {
        event_type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].GROUP_IDENTIFY,
        group_properties: identify.getUserProperties(),
        groups: (_a = {}, _a[groupType] = groupName, _a)
    });
    return groupIdentify;
};
var createGroupEvent = function(groupType, groupName, eventOptions) {
    var _a;
    var identify = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Identify"]();
    identify.set(groupType, groupName);
    var groupEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, eventOptions), {
        event_type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].IDENTIFY,
        user_properties: identify.getUserProperties(),
        groups: (_a = {}, _a[groupType] = groupName, _a)
    });
    return groupEvent;
};
var createRevenueEvent = function(revenue, eventOptions) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, eventOptions), {
        event_type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].REVENUE,
        event_properties: revenue.getEventProperties()
    });
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/return-wrapper.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "returnWrapper",
    ()=>returnWrapper
]);
var returnWrapper = function(awaitable) {
    return {
        promise: awaitable || Promise.resolve()
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/core-client.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AmplitudeCore",
    ()=>AmplitudeCore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/identify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/messages.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$timeline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/timeline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/event-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/result-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/return-wrapper.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
var AmplitudeCore = function() {
    function AmplitudeCore(name) {
        if (name === void 0) {
            name = '$default';
        }
        this.initializing = false;
        this.isReady = false;
        this.q = [];
        this.dispatchQ = [];
        this.logEvent = this.track.bind(this);
        this.timeline = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$timeline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timeline"](this);
        this.name = name;
    }
    AmplitudeCore.prototype._init = function(config) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        this.config = config;
                        this.timeline.reset(this);
                        this.timeline.loggerProvider = this.config.loggerProvider;
                        return [
                            4 /*yield*/ ,
                            this.runQueuedFunctions('q')
                        ];
                    case 1:
                        _a.sent();
                        this.isReady = true;
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    AmplitudeCore.prototype.runQueuedFunctions = function(queueName) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var queuedFunctions, queuedFunctions_1, queuedFunctions_1_1, queuedFunction, val, e_1_1;
            var e_1, _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        queuedFunctions = this[queueName];
                        this[queueName] = [];
                        _b.label = 1;
                    case 1:
                        _b.trys.push([
                            1,
                            8,
                            9,
                            10
                        ]);
                        queuedFunctions_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(queuedFunctions), queuedFunctions_1_1 = queuedFunctions_1.next();
                        _b.label = 2;
                    case 2:
                        if (!!queuedFunctions_1_1.done) return [
                            3 /*break*/ ,
                            7
                        ];
                        queuedFunction = queuedFunctions_1_1.value;
                        val = queuedFunction();
                        if (!(val && 'promise' in val)) return [
                            3 /*break*/ ,
                            4
                        ];
                        return [
                            4 /*yield*/ ,
                            val.promise
                        ];
                    case 3:
                        _b.sent();
                        return [
                            3 /*break*/ ,
                            6
                        ];
                    case 4:
                        return [
                            4 /*yield*/ ,
                            val
                        ];
                    case 5:
                        _b.sent();
                        _b.label = 6;
                    case 6:
                        queuedFunctions_1_1 = queuedFunctions_1.next();
                        return [
                            3 /*break*/ ,
                            2
                        ];
                    case 7:
                        return [
                            3 /*break*/ ,
                            10
                        ];
                    case 8:
                        e_1_1 = _b.sent();
                        e_1 = {
                            error: e_1_1
                        };
                        return [
                            3 /*break*/ ,
                            10
                        ];
                    case 9:
                        try {
                            if (queuedFunctions_1_1 && !queuedFunctions_1_1.done && (_a = queuedFunctions_1.return)) _a.call(queuedFunctions_1);
                        } finally{
                            if (e_1) throw e_1.error;
                        }
                        return [
                            7 /*endfinally*/ 
                        ];
                    case 10:
                        if (!this[queueName].length) return [
                            3 /*break*/ ,
                            12
                        ];
                        return [
                            4 /*yield*/ ,
                            this.runQueuedFunctions(queueName)
                        ];
                    case 11:
                        _b.sent();
                        _b.label = 12;
                    case 12:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    AmplitudeCore.prototype.track = function(eventInput, eventProperties, eventOptions) {
        var event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTrackEvent"])(eventInput, eventProperties, eventOptions);
        // Update client user properties immediately and synchronously
        this.userProperties = this.getOperationAppliedUserProperties(event.user_properties);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.dispatch(event));
    };
    AmplitudeCore.prototype.identify = function(identify, eventOptions) {
        var event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createIdentifyEvent"])(identify, eventOptions);
        // Update client user properties immediately and synchronously
        this.userProperties = this.getOperationAppliedUserProperties(event.user_properties);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.dispatch(event));
    };
    AmplitudeCore.prototype.groupIdentify = function(groupType, groupName, identify, eventOptions) {
        var event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGroupIdentifyEvent"])(groupType, groupName, identify, eventOptions);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.dispatch(event));
    };
    AmplitudeCore.prototype.setGroup = function(groupType, groupName, eventOptions) {
        var event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGroupEvent"])(groupType, groupName, eventOptions);
        // Update client user properties immediately and synchronously
        this.userProperties = this.getOperationAppliedUserProperties(event.user_properties);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.dispatch(event));
    };
    AmplitudeCore.prototype.revenue = function(revenue, eventOptions) {
        var event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRevenueEvent"])(revenue, eventOptions);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.dispatch(event));
    };
    AmplitudeCore.prototype.add = function(plugin) {
        if (!this.isReady) {
            this.q.push(this._addPlugin.bind(this, plugin));
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])();
        }
        return this._addPlugin(plugin);
    };
    AmplitudeCore.prototype._addPlugin = function(plugin) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.timeline.register(plugin, this.config));
    };
    AmplitudeCore.prototype.remove = function(pluginName) {
        if (!this.isReady) {
            this.q.push(this._removePlugin.bind(this, pluginName));
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])();
        }
        return this._removePlugin(pluginName);
    };
    AmplitudeCore.prototype._removePlugin = function(pluginName) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.timeline.deregister(pluginName, this.config));
    };
    AmplitudeCore.prototype.dispatchWithCallback = function(event, callback) {
        if (!this.isReady) {
            return callback((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildResult"])(event, 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLIENT_NOT_INITIALIZED"]));
        }
        void this.process(event).then(callback);
    };
    AmplitudeCore.prototype.dispatch = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (!this.isReady) {
                    return [
                        2 /*return*/ ,
                        new Promise(function(resolve) {
                            _this.dispatchQ.push(_this.dispatchWithCallback.bind(_this, event, resolve));
                        })
                    ];
                }
                return [
                    2 /*return*/ ,
                    this.process(event)
                ];
            });
        });
    };
    /**
     *
     * This method applies identify operations to user properties and
     * returns a single object representing the final user property state.
     *
     * This is a best-effort api that only supports $set, $clearAll, and $unset.
     * Other operations are not supported and are ignored.
     *
     * Operations are applied on top of current client state (this.userProperties).
     *
     * @param userProperties The new user properties object from identify() or setIdentity().
     * @returns A key-value object user properties without operations.
     *
     * @example
     * Input:
     * {
     *   $set: { plan: 'premium' },
     *   custom_flag: true
     * }
     *
     * Output:
     * {
     *   plan: 'premium',
     *   custom_flag: true
     * }
     */ AmplitudeCore.prototype.getOperationAppliedUserProperties = function(userProperties) {
        var _a;
        var base = (_a = this.userProperties) !== null && _a !== void 0 ? _a : {};
        var updatedProperties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, base);
        if (userProperties === undefined) {
            return updatedProperties;
        }
        // Keep non-operation keys for later merge
        var nonOpProperties = {};
        Object.keys(userProperties).forEach(function(key) {
            if (!Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"]).includes(key)) {
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-ignore
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                nonOpProperties[key] = userProperties[key];
            }
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OrderedIdentifyOperations"].forEach(function(operation) {
            // Skip when key is an operation.
            if (!Object.keys(userProperties).includes(operation)) return;
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            var opProperties = userProperties[operation];
            switch(operation){
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"].CLEAR_ALL:
                    // Due to operation order, the following line will never execute.
                    /* istanbul ignore next */ Object.keys(updatedProperties).forEach(function(prop) {
                        delete updatedProperties[prop];
                    });
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"].UNSET:
                    Object.keys(opProperties).forEach(function(prop) {
                        delete updatedProperties[prop];
                    });
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"].SET:
                    Object.assign(updatedProperties, opProperties);
                    break;
            }
        });
        // Merge non-operation properties.
        // Custom properties should not be affected by operations.
        // https://github.com/amplitude/nova/blob/343f678ded83c032e83b189796b3c2be161b48f5/src/main/java/com/amplitude/userproperty/model/ModifyUserPropertiesIdent.java#L79-L83
        Object.assign(updatedProperties, nonOpProperties);
        return updatedProperties;
    };
    AmplitudeCore.prototype.process = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var result, e_2, message, result;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        // skip event processing if opt out
                        if (this.config.optOut) {
                            return [
                                2 /*return*/ ,
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildResult"])(event, 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OPT_OUT_MESSAGE"])
                            ];
                        }
                        if (event.event_type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"].IDENTIFY) {
                            // Do not update this.userProperties here.
                            // It is only set synchronously in identify() or setIdentity()
                            this.timeline.onIdentityChanged({
                                userProperties: this.userProperties
                            });
                        }
                        return [
                            4 /*yield*/ ,
                            this.timeline.push(event)
                        ];
                    case 1:
                        result = _a.sent();
                        result.code === 200 ? this.config.loggerProvider.log(result.message) : result.code === 100 ? this.config.loggerProvider.warn(result.message) : this.config.loggerProvider.error(result.message);
                        return [
                            2 /*return*/ ,
                            result
                        ];
                    case 2:
                        e_2 = _a.sent();
                        message = String(e_2);
                        this.config.loggerProvider.error(message);
                        result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildResult"])(event, 0, message);
                        return [
                            2 /*return*/ ,
                            result
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    AmplitudeCore.prototype.setOptOut = function(optOut) {
        if (!this.isReady) {
            this.q.push(this._setOptOut.bind(this, Boolean(optOut)));
            return;
        }
        this._setOptOut(optOut);
    };
    AmplitudeCore.prototype._setOptOut = function(optOut) {
        if (this.config.optOut !== optOut) {
            this.config.optOut = Boolean(optOut);
            this.timeline.onOptOutChanged(optOut);
        }
    };
    AmplitudeCore.prototype.flush = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this.timeline.flush());
    };
    AmplitudeCore.prototype.plugin = function(name) {
        var plugin = this.timeline.plugins.find(function(plugin) {
            return plugin.name === name;
        });
        if (plugin === undefined) {
            this.config.loggerProvider.debug("Cannot find plugin with name ".concat(name));
            return undefined;
        }
        return plugin;
    };
    AmplitudeCore.prototype.plugins = function(pluginClass) {
        return this.timeline.plugins.filter(function(plugin) {
            return plugin instanceof pluginClass;
        });
    };
    return AmplitudeCore;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/chunk.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Creates an array of elements split into groups the length of size.
// If array can't be split evenly, the final chunk will be the remaining elements.
// Works similary as https://lodash.com/docs/4.17.15#chunk
__turbopack_context__.s([
    "chunk",
    ()=>chunk
]);
var chunk = function(arr, size) {
    var chunkSize = Math.max(size, 1);
    return arr.reduce(function(chunks, element, index) {
        var chunkIndex = Math.floor(index / chunkSize);
        if (!chunks[chunkIndex]) {
            chunks[chunkIndex] = [];
        }
        chunks[chunkIndex].push(element);
        return chunks;
    }, []);
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/logger.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Logger",
    ()=>Logger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)");
;
var PREFIX = 'Amplitude Logger ';
var Logger = function() {
    function Logger() {
        this.logLevel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].None;
    }
    Logger.prototype.disable = function() {
        this.logLevel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].None;
    };
    Logger.prototype.enable = function(logLevel) {
        if (logLevel === void 0) {
            logLevel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Warn;
        }
        this.logLevel = logLevel;
    };
    Logger.prototype.log = function() {
        var args = [];
        for(var _i = 0; _i < arguments.length; _i++){
            args[_i] = arguments[_i];
        }
        if (this.logLevel < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Verbose) {
            return;
        }
        console.log("".concat(PREFIX, "[Log]: ").concat(args.join(' ')));
    };
    Logger.prototype.warn = function() {
        var args = [];
        for(var _i = 0; _i < arguments.length; _i++){
            args[_i] = arguments[_i];
        }
        if (this.logLevel < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Warn) {
            return;
        }
        console.warn("".concat(PREFIX, "[Warn]: ").concat(args.join(' ')));
    };
    Logger.prototype.error = function() {
        var args = [];
        for(var _i = 0; _i < arguments.length; _i++){
            args[_i] = arguments[_i];
        }
        if (this.logLevel < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Error) {
            return;
        }
        console.error("".concat(PREFIX, "[Error]: ").concat(args.join(' ')));
    };
    Logger.prototype.debug = function() {
        var args = [];
        for(var _i = 0; _i < arguments.length; _i++){
            args[_i] = arguments[_i];
        }
        if (this.logLevel < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Debug) {
            return;
        }
        // console.debug output is hidden by default in chrome
        console.log("".concat(PREFIX, "[Debug]: ").concat(args.join(' ')));
    };
    return Logger;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Config",
    ()=>Config,
    "RequestMetadata",
    ()=>RequestMetadata,
    "createServerConfig",
    ()=>createServerConfig,
    "getDefaultConfig",
    ()=>getDefaultConfig,
    "getServerUrl",
    ()=>getServerUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$logger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/logger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)");
;
;
;
var getDefaultConfig = function() {
    return {
        flushMaxRetries: 12,
        flushQueueSize: 200,
        flushIntervalMillis: 10000,
        instanceName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_INSTANCE_NAME"],
        logLevel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Warn,
        loggerProvider: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$logger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logger"](),
        offline: false,
        optOut: false,
        serverUrl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_SERVER_URL"],
        serverZone: 'US',
        useBatch: false
    };
};
var Config = function() {
    function Config(options) {
        var _a, _b, _c, _d;
        this._optOut = false;
        var defaultConfig = getDefaultConfig();
        this.apiKey = options.apiKey;
        this.flushIntervalMillis = (_a = options.flushIntervalMillis) !== null && _a !== void 0 ? _a : defaultConfig.flushIntervalMillis;
        this.flushMaxRetries = options.flushMaxRetries || defaultConfig.flushMaxRetries;
        this.flushQueueSize = options.flushQueueSize || defaultConfig.flushQueueSize;
        this.instanceName = options.instanceName || defaultConfig.instanceName;
        this.loggerProvider = options.loggerProvider || defaultConfig.loggerProvider;
        this.logLevel = (_b = options.logLevel) !== null && _b !== void 0 ? _b : defaultConfig.logLevel;
        this.minIdLength = options.minIdLength;
        this.plan = options.plan;
        this.ingestionMetadata = options.ingestionMetadata;
        this.offline = options.offline !== undefined ? options.offline : defaultConfig.offline;
        this.optOut = (_c = options.optOut) !== null && _c !== void 0 ? _c : defaultConfig.optOut;
        this.serverUrl = options.serverUrl;
        this.serverZone = options.serverZone || defaultConfig.serverZone;
        this.storageProvider = options.storageProvider;
        this.transportProvider = options.transportProvider;
        this.useBatch = (_d = options.useBatch) !== null && _d !== void 0 ? _d : defaultConfig.useBatch;
        this.loggerProvider.enable(this.logLevel);
        var serverConfig = createServerConfig(options.serverUrl, options.serverZone, options.useBatch);
        this.serverZone = serverConfig.serverZone;
        this.serverUrl = serverConfig.serverUrl;
    }
    Object.defineProperty(Config.prototype, "optOut", {
        get: function() {
            return this._optOut;
        },
        set: function(optOut) {
            this._optOut = optOut;
        },
        enumerable: false,
        configurable: true
    });
    return Config;
}();
;
var getServerUrl = function(serverZone, useBatch) {
    if (serverZone === 'EU') {
        return useBatch ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EU_AMPLITUDE_BATCH_SERVER_URL"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EU_AMPLITUDE_SERVER_URL"];
    }
    return useBatch ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_BATCH_SERVER_URL"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_SERVER_URL"];
};
var createServerConfig = function(serverUrl, serverZone, useBatch) {
    if (serverUrl === void 0) {
        serverUrl = '';
    }
    if (serverZone === void 0) {
        serverZone = getDefaultConfig().serverZone;
    }
    if (useBatch === void 0) {
        useBatch = getDefaultConfig().useBatch;
    }
    if (serverUrl) {
        return {
            serverUrl: serverUrl,
            serverZone: undefined
        };
    }
    var _serverZone = [
        'US',
        'EU'
    ].includes(serverZone) ? serverZone : getDefaultConfig().serverZone;
    return {
        serverZone: _serverZone,
        serverUrl: getServerUrl(_serverZone, useBatch)
    };
};
var RequestMetadata = function() {
    function RequestMetadata() {
        this.sdk = {
            metrics: {
                histogram: {}
            }
        };
    }
    RequestMetadata.prototype.recordHistogram = function(key, value) {
        this.sdk.metrics.histogram[key] = value;
    };
    return RequestMetadata;
}();
;
var HistogramOptions = function() {
    function HistogramOptions() {}
    return HistogramOptions;
}();
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/status-code.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Checks if an HTTP status code indicates success (2xx range)
 * @param code - The HTTP status code to check
 * @returns true if the status code is in the 2xx range, false otherwise
 */ __turbopack_context__.s([
    "isSuccessStatusCode",
    ()=>isSuccessStatusCode
]);
function isSuccessStatusCode(code) {
    return code >= 200 && code < 300;
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/destination.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Destination",
    ()=>Destination,
    "getResponseBodyString",
    ()=>getResponseBodyString
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/status.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/messages.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$chunk$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/chunk.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/result-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$status$2d$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/status-code.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/debug.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
var DEFAULT_AMPLITUDE_SERVER_URLS = new Set([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_SERVER_URL"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EU_AMPLITUDE_SERVER_URL"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_BATCH_SERVER_URL"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EU_AMPLITUDE_BATCH_SERVER_URL"]
]);
var shouldCompressUploadBodyForRequest = function(serverUrl, enableRequestBodyCompression) {
    if (enableRequestBodyCompression === void 0) {
        enableRequestBodyCompression = false;
    }
    if (DEFAULT_AMPLITUDE_SERVER_URLS.has(serverUrl)) {
        return true;
    }
    return enableRequestBodyCompression;
};
function getErrorMessage(error) {
    if (error instanceof Error) return error.message;
    return String(error);
}
function getResponseBodyString(res) {
    var responseBodyString = '';
    try {
        if ('body' in res) {
            responseBodyString = JSON.stringify(res.body, null, 2);
        }
    } catch (_a) {
    // to avoid crash, but don't care about the error, add comment to avoid empty block lint error
    }
    return responseBodyString;
}
var Destination = function() {
    function Destination(context) {
        this.name = 'amplitude';
        this.type = 'destination';
        this.retryTimeout = 1000;
        this.throttleTimeout = 30000;
        this.storageKey = '';
        // Indicator of whether events that are scheduled (but not flushed yet).
        // When flush:
        //   1. assign `scheduleId` to `flushId`
        //   2. set `scheduleId` to null
        this.scheduleId = null;
        // Timeout in milliseconds of current schedule
        this.scheduledTimeout = 0;
        // Indicator of whether current flush resolves.
        // When flush resolves, set `flushId` to null
        this.flushId = null;
        this.queue = [];
        this.diagnosticsClient = context === null || context === void 0 ? void 0 : context.diagnosticsClient;
    }
    Destination.prototype.setup = function(config) {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var unsent;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        this.config = config;
                        this.storageKey = "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORAGE_PREFIX"], "_").concat(this.config.apiKey.substring(0, 10));
                        return [
                            4 /*yield*/ ,
                            (_a = this.config.storageProvider) === null || _a === void 0 ? void 0 : _a.get(this.storageKey)
                        ];
                    case 1:
                        unsent = _b.sent();
                        if (unsent && unsent.length > 0) {
                            void Promise.all(unsent.map(function(event) {
                                return _this.execute(event);
                            })).catch();
                        }
                        return [
                            2 /*return*/ ,
                            Promise.resolve(undefined)
                        ];
                }
            });
        });
    };
    Destination.prototype.execute = function(event) {
        var _this = this;
        // Assign insert_id for dropping invalid event later
        if (!event.insert_id) {
            event.insert_id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
        }
        return new Promise(function(resolve) {
            var context = {
                event: event,
                attempts: 0,
                callback: function(result) {
                    return resolve(result);
                },
                timeout: 0
            };
            _this.queue.push(context);
            _this.schedule(_this.config.flushIntervalMillis);
            _this.saveEvents();
        });
    };
    Destination.prototype.removeEventsExceedFlushMaxRetries = function(list) {
        var _this = this;
        return list.filter(function(context) {
            context.attempts += 1;
            if (context.attempts < _this.config.flushMaxRetries) {
                return true;
            }
            void _this.fulfillRequest([
                context
            ], 500, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_RETRIES_EXCEEDED_MESSAGE"]);
            return false;
        });
    };
    Destination.prototype.scheduleEvents = function(list) {
        var _this = this;
        list.forEach(function(context) {
            _this.schedule(context.timeout === 0 ? _this.config.flushIntervalMillis : context.timeout);
        });
    };
    // Schedule a flush in timeout when
    // 1. No schedule
    // 2. Timeout greater than existing timeout.
    // This makes sure that when throttled, no flush when throttle timeout expires.
    Destination.prototype.schedule = function(timeout) {
        var _this = this;
        if (this.config.offline) {
            return;
        }
        if (this.scheduleId === null || this.scheduleId && timeout > this.scheduledTimeout) {
            if (this.scheduleId) {
                clearTimeout(this.scheduleId);
            }
            this.scheduledTimeout = timeout;
            this.scheduleId = setTimeout(function() {
                _this.queue = _this.queue.map(function(context) {
                    context.timeout = 0;
                    return context;
                });
                void _this.flush(true);
            }, timeout);
            return;
        }
    };
    // Mark current schedule is flushed.
    Destination.prototype.resetSchedule = function() {
        this.scheduleId = null;
        this.scheduledTimeout = 0;
    };
    // Flush all events regardless of their timeout
    Destination.prototype.flush = function(useRetry) {
        if (useRetry === void 0) {
            useRetry = false;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var list, later, batches;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        // Skip flush if offline
                        if (this.config.offline) {
                            this.resetSchedule();
                            this.config.loggerProvider.debug('Skipping flush while offline.');
                            return [
                                2 /*return*/ 
                            ];
                        }
                        if (this.flushId) {
                            this.resetSchedule();
                            this.config.loggerProvider.debug('Skipping flush because previous flush has not resolved.');
                            return [
                                2 /*return*/ 
                            ];
                        }
                        this.flushId = this.scheduleId;
                        this.resetSchedule();
                        list = [];
                        later = [];
                        this.queue.forEach(function(context) {
                            return context.timeout === 0 ? list.push(context) : later.push(context);
                        });
                        batches = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$chunk$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chunk"])(list, this.config.flushQueueSize);
                        // Promise.all() doesn't guarantee resolve order.
                        // Sequentially resolve to make sure backend receives events in order
                        return [
                            4 /*yield*/ ,
                            batches.reduce(function(promise, batch) {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
                                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                                        switch(_a.label){
                                            case 0:
                                                return [
                                                    4 /*yield*/ ,
                                                    promise
                                                ];
                                            case 1:
                                                _a.sent();
                                                return [
                                                    4 /*yield*/ ,
                                                    this.send(batch, useRetry)
                                                ];
                                            case 2:
                                                return [
                                                    2 /*return*/ ,
                                                    _a.sent()
                                                ];
                                        }
                                    });
                                });
                            }, Promise.resolve())
                        ];
                    case 1:
                        // Promise.all() doesn't guarantee resolve order.
                        // Sequentially resolve to make sure backend receives events in order
                        _a.sent();
                        // Mark current flush is done
                        this.flushId = null;
                        this.scheduleEvents(this.queue);
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Destination.prototype.send = function(list, useRetry) {
        var _a;
        if (useRetry === void 0) {
            useRetry = true;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var payload, serverUrl, shouldCompressUploadBody, res, e_1, errorMessage;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        if (!this.config.apiKey) {
                            return [
                                2 /*return*/ ,
                                this.fulfillRequest(list, 400, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MISSING_API_KEY_MESSAGE"])
                            ];
                        }
                        payload = {
                            api_key: this.config.apiKey,
                            events: list.map(function(context) {
                                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                                var _a = context.event, extra = _a.extra, eventWithoutExtra = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__rest"])(_a, [
                                    "extra"
                                ]);
                                return eventWithoutExtra;
                            }),
                            options: {
                                min_id_length: this.config.minIdLength
                            },
                            client_upload_time: new Date().toISOString(),
                            request_metadata: this.config.requestMetadata
                        };
                        this.config.requestMetadata = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestMetadata"]();
                        _b.label = 1;
                    case 1:
                        _b.trys.push([
                            1,
                            3,
                            ,
                            4
                        ]);
                        serverUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerConfig"])(this.config.serverUrl, this.config.serverZone, this.config.useBatch).serverUrl;
                        shouldCompressUploadBody = shouldCompressUploadBodyForRequest(serverUrl, this.config.enableRequestBodyCompression);
                        return [
                            4 /*yield*/ ,
                            this.config.transportProvider.send(serverUrl, payload, shouldCompressUploadBody)
                        ];
                    case 2:
                        res = _b.sent();
                        if (res === null) {
                            this.fulfillRequest(list, 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UNEXPECTED_ERROR_MESSAGE"]);
                            return [
                                2 /*return*/ 
                            ];
                        }
                        if (!useRetry) {
                            if ('body' in res) {
                                this.fulfillRequest(list, res.statusCode, "".concat(res.status, ": ").concat(getResponseBodyString(res)));
                            } else {
                                this.fulfillRequest(list, res.statusCode, res.status);
                            }
                            return [
                                2 /*return*/ 
                            ];
                        }
                        this.handleResponse(res, list);
                        return [
                            3 /*break*/ ,
                            4
                        ];
                    case 3:
                        e_1 = _b.sent();
                        errorMessage = getErrorMessage(e_1);
                        this.config.loggerProvider.error(errorMessage);
                        (_a = this.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.recordEvent('analytics.events.unsuccessful.from.catch.error', {
                            events: list.map(function(context) {
                                return context.event.event_type;
                            }),
                            message: errorMessage,
                            stack_trace: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStacktrace"])()
                        });
                        this.handleResponse({
                            status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Failed,
                            statusCode: 0
                        }, list);
                        return [
                            3 /*break*/ ,
                            4
                        ];
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    Destination.prototype.handleResponse = function(res, list) {
        var _a;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$status$2d$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSuccessStatusCode"])(res.statusCode)) {
            (_a = this.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.recordEvent('analytics.events.unsuccessful', {
                events: list.map(function(context) {
                    return context.event.event_type;
                }),
                code: res.statusCode,
                status: res.status,
                body: getResponseBodyString(res),
                stack_trace: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStacktrace"])()
            });
        }
        var status = res.status;
        switch(status){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Success:
                {
                    this.handleSuccessResponse(res, list);
                    break;
                }
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Invalid:
                {
                    this.handleInvalidResponse(res, list);
                    break;
                }
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].PayloadTooLarge:
                {
                    this.handlePayloadTooLargeResponse(res, list);
                    break;
                }
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].RateLimit:
                {
                    this.handleRateLimitResponse(res, list);
                    break;
                }
            default:
                {
                    // log intermediate event status before retry
                    this.config.loggerProvider.warn("{code: 0, error: \"Status '".concat(status, "' provided for ").concat(list.length, " events\"}"));
                    this.handleOtherResponse(list);
                    break;
                }
        }
    };
    Destination.prototype.handleSuccessResponse = function(res, list) {
        this.fulfillRequest(list, res.statusCode, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SUCCESS_MESSAGE"]);
    };
    Destination.prototype.handleInvalidResponse = function(res, list) {
        var _this = this;
        if (res.body.missingField || res.body.error.startsWith(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$messages$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INVALID_API_KEY"])) {
            this.fulfillRequest(list, res.statusCode, res.body.error);
            return;
        }
        var dropIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(Object.values(res.body.eventsWithInvalidFields)), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(Object.values(res.body.eventsWithMissingFields)), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(Object.values(res.body.eventsWithInvalidIdLengths)), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(res.body.silencedEvents), false).flat();
        var dropIndexSet = new Set(dropIndex);
        var retry = list.filter(function(context, index) {
            if (dropIndexSet.has(index)) {
                _this.fulfillRequest([
                    context
                ], res.statusCode, res.body.error);
                return;
            }
            return true;
        });
        if (retry.length > 0) {
            // log intermediate event status before retry
            this.config.loggerProvider.warn(getResponseBodyString(res));
        }
        var tryable = this.removeEventsExceedFlushMaxRetries(retry);
        this.scheduleEvents(tryable);
    };
    Destination.prototype.handlePayloadTooLargeResponse = function(res, list) {
        if (list.length === 1) {
            this.fulfillRequest(list, res.statusCode, res.body.error);
            return;
        }
        // log intermediate event status before retry
        this.config.loggerProvider.warn(getResponseBodyString(res));
        this.config.flushQueueSize /= 2;
        var tryable = this.removeEventsExceedFlushMaxRetries(list);
        this.scheduleEvents(tryable);
    };
    Destination.prototype.handleRateLimitResponse = function(res, list) {
        var _this = this;
        var dropUserIds = Object.keys(res.body.exceededDailyQuotaUsers);
        var dropDeviceIds = Object.keys(res.body.exceededDailyQuotaDevices);
        var throttledIndex = res.body.throttledEvents;
        var dropUserIdsSet = new Set(dropUserIds);
        var dropDeviceIdsSet = new Set(dropDeviceIds);
        var throttledIndexSet = new Set(throttledIndex);
        var retry = list.filter(function(context, index) {
            if (context.event.user_id && dropUserIdsSet.has(context.event.user_id) || context.event.device_id && dropDeviceIdsSet.has(context.event.device_id)) {
                _this.fulfillRequest([
                    context
                ], res.statusCode, res.body.error);
                return;
            }
            if (throttledIndexSet.has(index)) {
                context.timeout = _this.throttleTimeout;
            }
            return true;
        });
        if (retry.length > 0) {
            // log intermediate event status before retry
            this.config.loggerProvider.warn(getResponseBodyString(res));
        }
        var tryable = this.removeEventsExceedFlushMaxRetries(retry);
        this.scheduleEvents(tryable);
    };
    Destination.prototype.handleOtherResponse = function(list) {
        var _this = this;
        var later = list.map(function(context) {
            context.timeout = context.attempts * _this.retryTimeout;
            return context;
        });
        var tryable = this.removeEventsExceedFlushMaxRetries(later);
        this.scheduleEvents(tryable);
    };
    Destination.prototype.fulfillRequest = function(list, code, message) {
        var _a, _b, _c;
        // Record diagnostics for dropped events (non-success status codes)
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$status$2d$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSuccessStatusCode"])(code)) {
            (_a = this.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.increment('analytics.events.dropped', list.length);
            (_b = this.diagnosticsClient) === null || _b === void 0 ? void 0 : _b.recordEvent('analytics.events.dropped', {
                events: list.map(function(context) {
                    return context.event.event_type;
                }),
                code: code,
                message: message,
                stack_trace: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStacktrace"])()
            });
        } else {
            (_c = this.diagnosticsClient) === null || _c === void 0 ? void 0 : _c.increment('analytics.events.sent', list.length);
        }
        this.removeEvents(list);
        list.forEach(function(context) {
            return context.callback((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$result$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildResult"])(context.event, code, message));
        });
    };
    /**
     * This is called on
     * 1) new events are added to queue; or
     * 2) response comes back for a request
     *
     * Update the event storage based on the queue
     */ Destination.prototype.saveEvents = function() {
        if (!this.config.storageProvider) {
            return;
        }
        var updatedEvents = this.queue.map(function(context) {
            return context.event;
        });
        void this.config.storageProvider.set(this.storageKey, updatedEvents);
    };
    /**
     * This is called on response comes back for a request
     */ Destination.prototype.removeEvents = function(eventsToRemove) {
        this.queue = this.queue.filter(function(queuedContext) {
            return !eventsToRemove.some(function(context) {
                return context.event.insert_id === queuedContext.event.insert_id;
            });
        });
        this.saveEvents();
    };
    return Destination;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/revenue.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Revenue",
    ()=>Revenue,
    "RevenueProperty",
    ()=>RevenueProperty
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$valid$2d$properties$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/valid-properties.js [app-client] (ecmascript)");
;
;
var Revenue = function() {
    function Revenue() {
        this.productId = '';
        this.quantity = 1;
        this.price = 0.0;
    }
    Revenue.prototype.setProductId = function(productId) {
        this.productId = productId;
        return this;
    };
    Revenue.prototype.setQuantity = function(quantity) {
        if (quantity > 0) {
            this.quantity = quantity;
        }
        return this;
    };
    Revenue.prototype.setPrice = function(price) {
        this.price = price;
        return this;
    };
    Revenue.prototype.setRevenueType = function(revenueType) {
        this.revenueType = revenueType;
        return this;
    };
    Revenue.prototype.setCurrency = function(currency) {
        this.currency = currency;
        return this;
    };
    Revenue.prototype.setRevenue = function(revenue) {
        this.revenue = revenue;
        return this;
    };
    Revenue.prototype.setReceipt = function(receipt) {
        this.receipt = receipt;
        return this;
    };
    Revenue.prototype.setReceiptSig = function(receiptSig) {
        this.receiptSig = receiptSig;
        return this;
    };
    Revenue.prototype.setEventProperties = function(properties) {
        try {
            // JSON.stringify drops undefined/function/symbol values before validation,
            // so a single undefined property no longer causes the whole object to be rejected.
            var filtered = JSON.parse(JSON.stringify(properties));
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$valid$2d$properties$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidObject"])(filtered)) {
                this.properties = filtered;
            }
        } catch (_a) {
        // no-op: invalid properties are ignored
        }
        return this;
    };
    Revenue.prototype.getEventProperties = function() {
        var eventProperties = this.properties ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this.properties) : {};
        eventProperties[RevenueProperty.REVENUE_PRODUCT_ID] = this.productId;
        eventProperties[RevenueProperty.REVENUE_QUANTITY] = this.quantity;
        eventProperties[RevenueProperty.REVENUE_PRICE] = this.price;
        eventProperties[RevenueProperty.REVENUE_TYPE] = this.revenueType;
        eventProperties[RevenueProperty.REVENUE_CURRENCY] = this.currency;
        eventProperties[RevenueProperty.REVENUE] = this.revenue;
        eventProperties[RevenueProperty.RECEIPT] = this.receipt;
        eventProperties[RevenueProperty.RECEIPT_SIG] = this.receiptSig;
        return eventProperties;
    };
    return Revenue;
}();
;
var RevenueProperty;
(function(RevenueProperty) {
    RevenueProperty["REVENUE_PRODUCT_ID"] = "$productId";
    RevenueProperty["REVENUE_QUANTITY"] = "$quantity";
    RevenueProperty["REVENUE_PRICE"] = "$price";
    RevenueProperty["REVENUE_TYPE"] = "$revenueType";
    RevenueProperty["REVENUE_CURRENCY"] = "$currency";
    RevenueProperty["REVENUE"] = "$revenue";
    RevenueProperty["RECEIPT"] = "$receipt";
    RevenueProperty["RECEIPT_SIG"] = "$receiptSig";
})(RevenueProperty || (RevenueProperty = {}));
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/analytics-connector.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAnalyticsConnector",
    ()=>getAnalyticsConnector,
    "setConnectorDeviceId",
    ()=>setConnectorDeviceId,
    "setConnectorUserId",
    ()=>setConnectorUserId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$connector$40$1$2e$6$2e$4$2f$node_modules$2f40$amplitude$2f$analytics$2d$connector$2f$dist$2f$analytics$2d$connector$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-connector@1.6.4/node_modules/@amplitude/analytics-connector/dist/analytics-connector.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
;
;
var getAnalyticsConnector = function(instanceName) {
    if (instanceName === void 0) {
        instanceName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_INSTANCE_NAME"];
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$connector$40$1$2e$6$2e$4$2f$node_modules$2f40$amplitude$2f$analytics$2d$connector$2f$dist$2f$analytics$2d$connector$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnalyticsConnector"].getInstance(instanceName);
};
var setConnectorUserId = function(userId, instanceName) {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    getAnalyticsConnector(instanceName).identityStore.editIdentity().setUserId(userId).commit();
};
var setConnectorDeviceId = function(deviceId, instanceName) {
    getAnalyticsConnector(instanceName).identityStore.editIdentity().setDeviceId(deviceId).commit();
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/session.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isNewSession",
    ()=>isNewSession
]);
var isNewSession = function(sessionTimeout, lastEventTime) {
    if (lastEventTime === void 0) {
        lastEventTime = Date.now();
    }
    var currentTime = Date.now();
    var timeSinceLastEvent = currentTime - lastEventTime;
    return timeSinceLastEvent > sessionTimeout;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/identity.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IdentityEventSender",
    ()=>IdentityEventSender
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/analytics-connector.js [app-client] (ecmascript)");
;
;
var IdentityEventSender = function() {
    function IdentityEventSender() {
        this.name = 'identity';
        this.type = 'before';
        this.identityStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAnalyticsConnector"])().identityStore;
    }
    IdentityEventSender.prototype.execute = function(context) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var userProperties;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                userProperties = context.user_properties;
                if (userProperties) {
                    this.identityStore.editIdentity().updateUserProperties(userProperties).commit();
                }
                return [
                    2 /*return*/ ,
                    context
                ];
            });
        });
    };
    IdentityEventSender.prototype.setup = function(config) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (config.instanceName) {
                    this.identityStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAnalyticsConnector"])(config.instanceName).identityStore;
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return IdentityEventSender;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/query-params.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getQueryParams",
    ()=>getQueryParams,
    "tryDecodeURIComponent",
    ()=>tryDecodeURIComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
var getQueryParams = function() {
    var _a;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore if */ if (!((_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.location) === null || _a === void 0 ? void 0 : _a.search)) {
        return {};
    }
    var pairs = globalScope.location.search.substring(1).split('&').filter(Boolean);
    var params = pairs.reduce(function(acc, curr) {
        var query = curr.split('=', 2);
        var key = tryDecodeURIComponent(query[0]);
        var value = tryDecodeURIComponent(query[1]);
        if (!value) {
            return acc;
        }
        acc[key] = value;
        return acc;
    }, {});
    return params;
};
var tryDecodeURIComponent = function(value) {
    if (value === void 0) {
        value = '';
    }
    try {
        return decodeURIComponent(value);
    } catch (_a) {
        return '';
    }
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/offline.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OfflineDisabled",
    ()=>OfflineDisabled
]);
var OfflineDisabled = null;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/remote-config/remote-config-localstorage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RemoteConfigLocalStorage",
    ()=>RemoteConfigLocalStorage
]);
var RemoteConfigLocalStorage = function() {
    function RemoteConfigLocalStorage(apiKey, logger) {
        this.key = "AMP_remote_config_".concat(apiKey.substring(0, 10));
        this.logger = logger;
    }
    RemoteConfigLocalStorage.prototype.fetchConfig = function() {
        var result = null;
        var failedRemoteConfigInfo = {
            remoteConfig: null,
            lastFetch: new Date()
        };
        try {
            result = localStorage.getItem(this.key);
        } catch (error) {
            this.logger.debug('Remote config localstorage failed to access: ', error);
            return Promise.resolve(failedRemoteConfigInfo);
        }
        if (result === null) {
            this.logger.debug('Remote config localstorage gets null because the key does not exist');
            return Promise.resolve(failedRemoteConfigInfo);
        }
        try {
            var remoteConfigInfo = JSON.parse(result);
            this.logger.debug("Remote config localstorage parsed successfully: ".concat(JSON.stringify(remoteConfigInfo)));
            return Promise.resolve({
                remoteConfig: remoteConfigInfo.remoteConfig,
                lastFetch: new Date(remoteConfigInfo.lastFetch)
            });
        } catch (error) {
            this.logger.debug('Remote config localstorage failed to parse: ', error);
            localStorage.removeItem(this.key);
            return Promise.resolve(failedRemoteConfigInfo);
        }
    };
    RemoteConfigLocalStorage.prototype.setConfig = function(config) {
        try {
            localStorage.setItem(this.key, JSON.stringify(config));
            this.logger.debug('Remote config localstorage set successfully.');
            return Promise.resolve(true);
        } catch (error) {
            this.logger.debug('Remote config localstorage failed to set: ', error);
        }
        return Promise.resolve(false);
    };
    return RemoteConfigLocalStorage;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/remote-config/remote-config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_MAX_RETRIES",
    ()=>DEFAULT_MAX_RETRIES,
    "EU_SERVER_URL",
    ()=>EU_SERVER_URL,
    "RemoteConfigClient",
    ()=>RemoteConfigClient,
    "US_SERVER_URL",
    ()=>US_SERVER_URL
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$remote$2d$config$2f$remote$2d$config$2d$localstorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/remote-config/remote-config-localstorage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
;
;
;
var US_SERVER_URL = 'https://sr-client-cfg.amplitude.com/config';
var EU_SERVER_URL = 'https://sr-client-cfg.eu.amplitude.com/config';
var DEFAULT_MAX_RETRIES = 3;
var CODE_STATUS = {
    INVALID_API_KEY: 401,
    FORBIDDEN: 403,
    RATE_LIMIT: 429
};
/**
 * The default timeout for fetch in milliseconds.
 * Linear backoff policy: timeout / retry times is the interval between fetch retry.
 */ var DEFAULT_TIMEOUT = 1000;
/**
 * The minimum time between fetches in milliseconds.
 * This prevents too many requests from being sent in a short period of time.
 */ var DEFAULT_MIN_TIME_BETWEEN_FETCHES = 5 * 60 * 1000; // 5 minutes
var RemoteConfigClient = function() {
    function RemoteConfigClient(apiKey, logger, serverZone, serverUrl) {
        if (serverZone === void 0) {
            serverZone = 'US';
        }
        // Registered callbackInfos by subscribe().
        this.callbackInfos = [];
        // Track the last successful fetch time for throttling (timestamp in milliseconds).
        this.lastSuccessfulFetch = null;
        // Store the in-flight fetch promise for deduplication.
        this.fetchPromise = null;
        // Used to skip periodic updateConfigs calls when API key is invalid.
        this.isLastFetchInvalidApiKey = false;
        this.apiKey = apiKey;
        this.serverUrl = serverUrl || (serverZone === 'US' ? US_SERVER_URL : EU_SERVER_URL);
        this.logger = logger;
        this.storage = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$remote$2d$config$2f$remote$2d$config$2d$localstorage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteConfigLocalStorage"](apiKey, logger);
    }
    RemoteConfigClient.prototype.subscribe = function(key, deliveryMode, callback) {
        var id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
        var callbackInfo = {
            id: id,
            key: key,
            deliveryMode: deliveryMode,
            callback: callback
        };
        this.callbackInfos.push(callbackInfo);
        if (deliveryMode === 'all') {
            void this.subscribeAll(callbackInfo);
        } else {
            void this.subscribeWaitForRemote(callbackInfo, deliveryMode.timeout);
        }
        return id;
    };
    RemoteConfigClient.prototype.unsubscribe = function(id) {
        var index = this.callbackInfos.findIndex(function(callbackInfo) {
            return callbackInfo.id === id;
        });
        if (index === -1) {
            this.logger.debug("Remote config client unsubscribe failed because callback with id ".concat(id, " doesn't exist."));
            return false;
        }
        this.callbackInfos.splice(index, 1);
        this.logger.debug("Remote config client unsubscribe succeeded removing callback with id ".concat(id, "."));
        return true;
    };
    RemoteConfigClient.prototype.updateConfigs = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var timeSinceLastFetch, result;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        // Check if we need to throttle based on last successful fetch time
                        if (this.lastSuccessfulFetch) {
                            timeSinceLastFetch = Date.now() - this.lastSuccessfulFetch;
                            if (timeSinceLastFetch < DEFAULT_MIN_TIME_BETWEEN_FETCHES) {
                                this.logger.debug('Remote config client skipping updateConfigs: Too recent');
                                return [
                                    2 /*return*/ 
                                ];
                            }
                        }
                        return [
                            4 /*yield*/ ,
                            this.getOrCreateFetchPromise()
                        ];
                    case 1:
                        result = _a.sent();
                        void this.storage.setConfig(result);
                        this.callbackInfos.forEach(function(callbackInfo) {
                            _this.sendCallback(callbackInfo, result, 'remote');
                        });
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Get the in-flight fetch promise or create a new one.
     * This ensures multiple subscribe calls share the same network request.
     */ RemoteConfigClient.prototype.getOrCreateFetchPromise = function() {
        var _this = this;
        if (this.fetchPromise) {
            return this.fetchPromise;
        }
        if (this.isLastFetchInvalidApiKey) {
            this.logger.debug('Remote config client skipping fetch: Invalid API key');
            this.fetchPromise = Promise.resolve({
                remoteConfig: null,
                lastFetch: new Date()
            }).finally(function() {
                _this.fetchPromise = null;
            });
            return this.fetchPromise;
        }
        this.fetchPromise = this.fetch().then(function(result) {
            // Update last successful fetch time if we got a valid config
            if (result.remoteConfig !== null) {
                _this.lastSuccessfulFetch = Date.now();
            }
            return result;
        }).finally(function() {
            // Clear the promise after it settles (success or failure)
            _this.fetchPromise = null;
        });
        return this.fetchPromise;
    };
    /**
     * Send remote first. If it's already complete, we can skip the cached response.
     * - if remote is fetched first, no cache fetch.
     * - if cache is fetched first, still fetching remote.
     */ RemoteConfigClient.prototype.subscribeAll = function(callbackInfo) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var remotePromise, cachePromise, result;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        remotePromise = this.getOrCreateFetchPromise().then(function(result) {
                            _this.logger.debug("Remote config client subscription all mode fetched from remote: ".concat(JSON.stringify(result)));
                            _this.sendCallback(callbackInfo, result, 'remote');
                            void _this.storage.setConfig(result);
                        });
                        cachePromise = this.storage.fetchConfig().then(function(result) {
                            return result;
                        });
                        return [
                            4 /*yield*/ ,
                            Promise.race([
                                remotePromise,
                                cachePromise
                            ])
                        ];
                    case 1:
                        result = _a.sent();
                        // If cache is fetched first, wait for remote.
                        if (result !== undefined) {
                            this.logger.debug("Remote config client subscription all mode fetched from cache: ".concat(JSON.stringify(result)));
                            // Skip sending callback if cache is empty (first time user).
                            if (result.remoteConfig !== null) {
                                this.sendCallback(callbackInfo, result, 'cache');
                            } else {
                                this.logger.debug('Remote config client skips sending callback because cache is empty (first time user).');
                            }
                        }
                        return [
                            4 /*yield*/ ,
                            remotePromise
                        ];
                    case 2:
                        _a.sent();
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Waits for a remote response until the given timeout, then return a cached copy, if available.
     */ RemoteConfigClient.prototype.subscribeWaitForRemote = function(callbackInfo, timeout) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var timeoutPromise, result, error_1, result;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        timeoutPromise = new Promise(function(_, reject) {
                            setTimeout(function() {
                                reject('Timeout exceeded');
                            }, timeout);
                        });
                        _a.label = 1;
                    case 1:
                        _a.trys.push([
                            1,
                            3,
                            ,
                            5
                        ]);
                        return [
                            4 /*yield*/ ,
                            Promise.race([
                                this.getOrCreateFetchPromise(),
                                timeoutPromise
                            ])
                        ];
                    case 2:
                        result = _a.sent();
                        this.logger.debug('Remote config client subscription wait for remote mode returns from remote.');
                        this.sendCallback(callbackInfo, result, 'remote');
                        void this.storage.setConfig(result);
                        return [
                            3 /*break*/ ,
                            5
                        ];
                    case 3:
                        error_1 = _a.sent();
                        this.logger.debug('Remote config client subscription wait for remote mode exceeded timeout. Try to fetch from cache.');
                        return [
                            4 /*yield*/ ,
                            this.storage.fetchConfig()
                        ];
                    case 4:
                        result = _a.sent();
                        if (result.remoteConfig !== null) {
                            this.logger.debug('Remote config client subscription wait for remote mode returns a cached copy.');
                            this.sendCallback(callbackInfo, result, 'cache');
                        } else {
                            this.logger.debug('Remote config client subscription wait for remote mode failed to fetch cache.');
                            this.sendCallback(callbackInfo, result, 'remote');
                        }
                        return [
                            3 /*break*/ ,
                            5
                        ];
                    case 5:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Call the callback with filtered remote config based on key.
     * @param remoteConfigInfo - the whole remote config object without filtering by key.
     */ RemoteConfigClient.prototype.sendCallback = function(callbackInfo, remoteConfigInfo, source) {
        callbackInfo.lastCallback = new Date();
        var filteredConfig;
        if (callbackInfo.key) {
            // Filter remote config by key.
            // For example, if remote config is {a: {b: {c: 1}}},
            // if key = 'a', filter result is {b: {c: 1}};
            // if key = 'a.b', filter result is {c: 1}
            filteredConfig = callbackInfo.key.split('.').reduce(function(config, key) {
                if (config === null) {
                    return config;
                }
                return key in config ? config[key] : null;
            }, remoteConfigInfo.remoteConfig);
        } else {
            filteredConfig = remoteConfigInfo.remoteConfig;
        }
        callbackInfo.callback(filteredConfig, source, remoteConfigInfo.lastFetch);
    };
    /**
     * Fetch remote config from remote.
     * @param retries - the number of retries. default is 3.
     * @param timeout - the timeout in milliseconds. Default is 1000.
     * This timeout serves two purposes:
     * 1. It determines how long to wait for each remote config fetch request before aborting it.
     *    If the fetch does not complete within the specified timeout, the request is cancelled using AbortController,
     *    and the attempt is considered failed (and may be retried if retries remain).
     * 2. It is also used to calculate the interval between retries. The total timeout is divided by the number of retries,
     *    so each retry waits for (timeout / retries) milliseconds before the next attempt (linear backoff).
     * Retry behavior by status code:
     * - 401: invalid API key (stop retries and disable future updateConfigs calls).
     * - 429: retry up to max retries.
     * - other 4xx: no retry.
     * - 5xx and network failures: retry up to max retries.
     * @returns the remote config info. null if failed to fetch or the response is not valid JSON.
     */ RemoteConfigClient.prototype.fetch = function(retries, timeout) {
        if (retries === void 0) {
            retries = DEFAULT_MAX_RETRIES;
        }
        if (timeout === void 0) {
            timeout = DEFAULT_TIMEOUT;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var interval, failedRemoteConfigInfo, _loop_1, this_1, attempt, state_1;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        interval = timeout / retries;
                        failedRemoteConfigInfo = {
                            remoteConfig: null,
                            lastFetch: new Date()
                        };
                        _loop_1 = function(attempt) {
                            var shouldRetry, abortController, timeoutId, res, body, remoteConfig, error_2;
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                                switch(_b.label){
                                    case 0:
                                        shouldRetry = true;
                                        abortController = new AbortController();
                                        timeoutId = setTimeout(function() {
                                            return abortController.abort();
                                        }, timeout);
                                        _b.label = 1;
                                    case 1:
                                        _b.trys.push([
                                            1,
                                            7,
                                            8,
                                            9
                                        ]);
                                        return [
                                            4 /*yield*/ ,
                                            fetch(this_1.getUrlParams(), {
                                                method: 'GET',
                                                headers: {
                                                    Accept: '*/*'
                                                },
                                                signal: abortController.signal
                                            })
                                        ];
                                    case 2:
                                        res = _b.sent();
                                        if (!!res.ok) return [
                                            3 /*break*/ ,
                                            4
                                        ];
                                        return [
                                            4 /*yield*/ ,
                                            res.text()
                                        ];
                                    case 3:
                                        body = _b.sent();
                                        this_1.logger.debug("Remote config client fetch with retry time ".concat(retries, " failed with ").concat(res.status, ": ").concat(body));
                                        if (res.status === CODE_STATUS.INVALID_API_KEY || res.status === CODE_STATUS.FORBIDDEN) {
                                            this_1.logger.error("Remote config client fetch failed with ".concat(res.status, ". Invalid API key; future fetches will be skipped."));
                                            this_1.isLastFetchInvalidApiKey = true;
                                            shouldRetry = false;
                                        } else if (res.status >= 400 && res.status < 500 && res.status !== CODE_STATUS.RATE_LIMIT) {
                                            shouldRetry = false;
                                        }
                                        return [
                                            3 /*break*/ ,
                                            6
                                        ];
                                    case 4:
                                        return [
                                            4 /*yield*/ ,
                                            res.json()
                                        ];
                                    case 5:
                                        remoteConfig = _b.sent();
                                        return [
                                            2 /*return*/ ,
                                            {
                                                value: {
                                                    remoteConfig: remoteConfig,
                                                    lastFetch: new Date()
                                                }
                                            }
                                        ];
                                    case 6:
                                        return [
                                            3 /*break*/ ,
                                            9
                                        ];
                                    case 7:
                                        error_2 = _b.sent();
                                        // Handle rejects when the request fails, for example, a network error or timeout
                                        if (error_2 instanceof Error && error_2.name === 'AbortError') {
                                            this_1.logger.debug("Remote config client fetch with retry time ".concat(retries, " timed out after ").concat(timeout, "ms"));
                                        } else {
                                            this_1.logger.debug("Remote config client fetch with retry time ".concat(retries, " is rejected because: "), error_2);
                                        }
                                        return [
                                            3 /*break*/ ,
                                            9
                                        ];
                                    case 8:
                                        // Clear the timeout since request completed or failed
                                        clearTimeout(timeoutId);
                                        return [
                                            7 /*endfinally*/ 
                                        ];
                                    case 9:
                                        if (!shouldRetry) {
                                            return [
                                                2 /*return*/ ,
                                                "break"
                                            ];
                                        }
                                        if (!(attempt < retries - 1)) return [
                                            3 /*break*/ ,
                                            11
                                        ];
                                        return [
                                            4 /*yield*/ ,
                                            new Promise(function(resolve) {
                                                return setTimeout(resolve, _this.getJitterDelay(interval));
                                            })
                                        ];
                                    case 10:
                                        _b.sent();
                                        _b.label = 11;
                                    case 11:
                                        return [
                                            2 /*return*/ 
                                        ];
                                }
                            });
                        };
                        this_1 = this;
                        attempt = 0;
                        _a.label = 1;
                    case 1:
                        if (!(attempt < retries)) return [
                            3 /*break*/ ,
                            4
                        ];
                        return [
                            5 /*yield**/ ,
                            _loop_1(attempt)
                        ];
                    case 2:
                        state_1 = _a.sent();
                        if (typeof state_1 === "object") return [
                            2 /*return*/ ,
                            state_1.value
                        ];
                        if (state_1 === "break") return [
                            3 /*break*/ ,
                            4
                        ];
                        _a.label = 3;
                    case 3:
                        attempt++;
                        return [
                            3 /*break*/ ,
                            1
                        ];
                    case 4:
                        return [
                            2 /*return*/ ,
                            failedRemoteConfigInfo
                        ];
                }
            });
        });
    };
    /**
     * Return jitter in the bound of [0,baseDelay) and then floor round.
     */ RemoteConfigClient.prototype.getJitterDelay = function(baseDelay) {
        return Math.floor(Math.random() * baseDelay);
    };
    RemoteConfigClient.prototype.getUrlParams = function() {
        // URL encode the API key to handle special characters
        var encodedApiKey = encodeURIComponent(this.apiKey);
        var urlParams = new URLSearchParams();
        urlParams.append('config_group', RemoteConfigClient.CONFIG_GROUP);
        return "".concat(this.serverUrl, "/").concat(encodedApiKey, "?").concat(urlParams.toString());
    };
    RemoteConfigClient.CONFIG_GROUP = 'browser';
    return RemoteConfigClient;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/diagnostics/diagnostics-storage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DiagnosticsStorage",
    ()=>DiagnosticsStorage,
    "INTERNAL_KEYS",
    ()=>INTERNAL_KEYS,
    "TABLE_NAMES",
    ()=>TABLE_NAMES
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
var MAX_PERSISTENT_STORAGE_EVENTS_COUNT = 10;
// Database configuration
var DB_VERSION = 1;
var TABLE_NAMES = {
    TAGS: 'tags',
    COUNTERS: 'counters',
    HISTOGRAMS: 'histograms',
    EVENTS: 'events',
    INTERNAL: 'internal'
};
var INTERNAL_KEYS = {
    LAST_FLUSH_TIMESTAMP: 'last_flush_timestamp'
};
/**
 * Purpose-specific IndexedDB storage for diagnostics data
 * Provides optimized methods for each type of diagnostics data
 */ var DiagnosticsStorage = function() {
    function DiagnosticsStorage(apiKey, logger) {
        this.dbPromise = null;
        this.logger = logger;
        this.dbName = "AMP_diagnostics_".concat(apiKey.substring(0, 10));
    }
    /**
     * Check if IndexedDB is supported in the current environment
     * @returns true if IndexedDB is available, false otherwise
     */ DiagnosticsStorage.isSupported = function() {
        var _a;
        return ((_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.indexedDB) !== undefined;
    };
    DiagnosticsStorage.prototype.getDB = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (!this.dbPromise) {
                    this.dbPromise = this.openDB();
                }
                return [
                    2 /*return*/ ,
                    this.dbPromise
                ];
            });
        });
    };
    DiagnosticsStorage.prototype.openDB = function() {
        var _this = this;
        return new Promise(function(resolve, reject) {
            var request = indexedDB.open(_this.dbName, DB_VERSION);
            request.onerror = function() {
                // Clear dbPromise when it rejects for the first time
                _this.dbPromise = null;
                reject(new Error('Failed to open IndexedDB'));
            };
            request.onsuccess = function() {
                var db = request.result;
                // Clear dbPromise when connection was on but went off later
                db.onclose = function() {
                    _this.dbPromise = null;
                    _this.logger.debug('DiagnosticsStorage: DB connection closed.');
                };
                db.onerror = function(event) {
                    _this.logger.debug('DiagnosticsStorage: A global database error occurred.', event);
                    db.close();
                };
                resolve(db);
            };
            request.onupgradeneeded = function(event) {
                var db = event.target.result;
                _this.createTables(db);
            };
        });
    };
    DiagnosticsStorage.prototype.createTables = function(db) {
        // Create tags table
        if (!db.objectStoreNames.contains(TABLE_NAMES.TAGS)) {
            db.createObjectStore(TABLE_NAMES.TAGS, {
                keyPath: 'key'
            });
        }
        // Create counters table
        if (!db.objectStoreNames.contains(TABLE_NAMES.COUNTERS)) {
            db.createObjectStore(TABLE_NAMES.COUNTERS, {
                keyPath: 'key'
            });
        }
        // Create histograms table for storing histogram stats (count, min, max, sum)
        if (!db.objectStoreNames.contains(TABLE_NAMES.HISTOGRAMS)) {
            db.createObjectStore(TABLE_NAMES.HISTOGRAMS, {
                keyPath: 'key'
            });
        }
        // Create events table
        if (!db.objectStoreNames.contains(TABLE_NAMES.EVENTS)) {
            var eventsStore = db.createObjectStore(TABLE_NAMES.EVENTS, {
                keyPath: 'id',
                autoIncrement: true
            });
            // Create index on time for chronological queries
            eventsStore.createIndex('time_idx', 'time', {
                unique: false
            });
        }
        // Create internal table for storing internal data like flush timestamps
        if (!db.objectStoreNames.contains(TABLE_NAMES.INTERNAL)) {
            db.createObjectStore(TABLE_NAMES.INTERNAL, {
                keyPath: 'key'
            });
        }
    };
    DiagnosticsStorage.prototype.setTags = function(tags) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction_1, store_1, error_1;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        if (Object.entries(tags).length === 0) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _a.sent();
                        transaction_1 = db.transaction([
                            TABLE_NAMES.TAGS
                        ], 'readwrite');
                        store_1 = transaction_1.objectStore(TABLE_NAMES.TAGS);
                        return [
                            2 /*return*/ ,
                            new Promise(function(resolve) {
                                var entries = Object.entries(tags);
                                transaction_1.oncomplete = function() {
                                    resolve();
                                };
                                transaction_1.onabort = function(event) {
                                    _this.logger.debug('DiagnosticsStorage: Failed to set tags', event);
                                    resolve();
                                };
                                entries.forEach(function(_a) {
                                    var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), key = _b[0], value = _b[1];
                                    var putRequest = store_1.put({
                                        key: key,
                                        value: value
                                    });
                                    putRequest.onerror = function(event) {
                                        _this.logger.debug('DiagnosticsStorage: Failed to set tag', key, value, event);
                                    };
                                });
                            })
                        ];
                    case 2:
                        error_1 = _a.sent();
                        this.logger.debug('DiagnosticsStorage: Failed to set tags', error_1);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.incrementCounters = function(counters) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction_2, store_2, error_2;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        if (Object.entries(counters).length === 0) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _a.sent();
                        transaction_2 = db.transaction([
                            TABLE_NAMES.COUNTERS
                        ], 'readwrite');
                        store_2 = transaction_2.objectStore(TABLE_NAMES.COUNTERS);
                        return [
                            2 /*return*/ ,
                            new Promise(function(resolve) {
                                var entries = Object.entries(counters);
                                transaction_2.oncomplete = function() {
                                    resolve();
                                };
                                transaction_2.onabort = function(event) {
                                    _this.logger.debug('DiagnosticsStorage: Failed to increment counters', event);
                                    resolve();
                                };
                                // Read existing values and update them
                                entries.forEach(function(_a) {
                                    var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), key = _b[0], incrementValue = _b[1];
                                    var getRequest = store_2.get(key);
                                    getRequest.onsuccess = function() {
                                        var existingRecord = getRequest.result;
                                        /* istanbul ignore next */ var existingValue = existingRecord ? existingRecord.value : 0;
                                        var putRequest = store_2.put({
                                            key: key,
                                            value: existingValue + incrementValue
                                        });
                                        putRequest.onerror = function(event) {
                                            _this.logger.debug('DiagnosticsStorage: Failed to update counter', key, event);
                                        };
                                    };
                                    getRequest.onerror = function(event) {
                                        _this.logger.debug('DiagnosticsStorage: Failed to read existing counter', key, event);
                                    };
                                });
                            })
                        ];
                    case 2:
                        error_2 = _a.sent();
                        this.logger.debug('DiagnosticsStorage: Failed to increment counters', error_2);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.setHistogramStats = function(histogramStats) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction_3, store_3, error_3;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        if (Object.entries(histogramStats).length === 0) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _a.sent();
                        transaction_3 = db.transaction([
                            TABLE_NAMES.HISTOGRAMS
                        ], 'readwrite');
                        store_3 = transaction_3.objectStore(TABLE_NAMES.HISTOGRAMS);
                        return [
                            2 /*return*/ ,
                            new Promise(function(resolve) {
                                var entries = Object.entries(histogramStats);
                                transaction_3.oncomplete = function() {
                                    resolve();
                                };
                                transaction_3.onabort = function(event) {
                                    _this.logger.debug('DiagnosticsStorage: Failed to set histogram stats', event);
                                    resolve();
                                };
                                // Read existing values and update them
                                entries.forEach(function(_a) {
                                    var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), key = _b[0], newStats = _b[1];
                                    var getRequest = store_3.get(key);
                                    getRequest.onsuccess = function() {
                                        var existingRecord = getRequest.result;
                                        var updatedStats;
                                        /* istanbul ignore next */ if (existingRecord) {
                                            // Accumulate with existing stats
                                            updatedStats = {
                                                key: key,
                                                count: existingRecord.count + newStats.count,
                                                min: Math.min(existingRecord.min, newStats.min),
                                                max: Math.max(existingRecord.max, newStats.max),
                                                sum: existingRecord.sum + newStats.sum
                                            };
                                        } else {
                                            // Create new stats
                                            updatedStats = {
                                                key: key,
                                                count: newStats.count,
                                                min: newStats.min,
                                                max: newStats.max,
                                                sum: newStats.sum
                                            };
                                        }
                                        var putRequest = store_3.put(updatedStats);
                                        putRequest.onerror = function(event) {
                                            _this.logger.debug('DiagnosticsStorage: Failed to set histogram stats', key, event);
                                        };
                                    };
                                    getRequest.onerror = function(event) {
                                        _this.logger.debug('DiagnosticsStorage: Failed to read existing histogram stats', key, event);
                                    };
                                });
                            })
                        ];
                    case 2:
                        error_3 = _a.sent();
                        this.logger.debug('DiagnosticsStorage: Failed to set histogram stats', error_3);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.addEventRecords = function(events) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction_4, store_4, error_4;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        if (events.length === 0) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _a.sent();
                        transaction_4 = db.transaction([
                            TABLE_NAMES.EVENTS
                        ], 'readwrite');
                        store_4 = transaction_4.objectStore(TABLE_NAMES.EVENTS);
                        return [
                            2 /*return*/ ,
                            new Promise(function(resolve) {
                                transaction_4.oncomplete = function() {
                                    resolve();
                                };
                                /* istanbul ignore next */ transaction_4.onabort = function(event) {
                                    _this.logger.debug('DiagnosticsStorage: Failed to add event records', event);
                                    resolve();
                                };
                                // First, check how many events are currently stored
                                var countRequest = store_4.count();
                                countRequest.onsuccess = function() {
                                    var currentCount = countRequest.result;
                                    // Calculate how many events we can add
                                    var availableSlots = Math.max(0, MAX_PERSISTENT_STORAGE_EVENTS_COUNT - currentCount);
                                    if (availableSlots < events.length) {
                                        _this.logger.debug("DiagnosticsStorage: Only added ".concat(availableSlots, " of ").concat(events.length, " events due to storage limit"));
                                    }
                                    // Only add events up to the available slots (take the least recent ones)
                                    events.slice(0, availableSlots).forEach(function(event) {
                                        var request = store_4.add(event);
                                        request.onerror = function(event) {
                                            _this.logger.debug('DiagnosticsStorage: Failed to add event record', event);
                                        };
                                    });
                                };
                                countRequest.onerror = function(event) {
                                    _this.logger.debug('DiagnosticsStorage: Failed to count existing events', event);
                                };
                            })
                        ];
                    case 2:
                        error_4 = _a.sent();
                        this.logger.debug('DiagnosticsStorage: Failed to add event records', error_4);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.setInternal = function(key, value) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction_5, store_5, error_5;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _a.sent();
                        transaction_5 = db.transaction([
                            TABLE_NAMES.INTERNAL
                        ], 'readwrite');
                        store_5 = transaction_5.objectStore(TABLE_NAMES.INTERNAL);
                        return [
                            2 /*return*/ ,
                            new Promise(function(resolve, reject) {
                                /* istanbul ignore next */ transaction_5.onabort = function() {
                                    return reject(new Error('Failed to set internal value'));
                                };
                                var request = store_5.put({
                                    key: key,
                                    value: value
                                });
                                request.onsuccess = function() {
                                    return resolve();
                                };
                                /* istanbul ignore next */ request.onerror = function() {
                                    return reject(new Error('Failed to set internal value'));
                                };
                            })
                        ];
                    case 2:
                        error_5 = _a.sent();
                        /* istanbul ignore next */ this.logger.debug('DiagnosticsStorage: Failed to set internal value', error_5);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.getInternal = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction_6, store_6, error_6;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _a.sent();
                        transaction_6 = db.transaction([
                            TABLE_NAMES.INTERNAL
                        ], 'readonly');
                        store_6 = transaction_6.objectStore(TABLE_NAMES.INTERNAL);
                        return [
                            2 /*return*/ ,
                            new Promise(function(resolve, reject) {
                                /* istanbul ignore next */ transaction_6.onabort = function() {
                                    return reject(new Error('Failed to get internal value'));
                                };
                                var request = store_6.get(key);
                                request.onsuccess = function() {
                                    return resolve(request.result);
                                };
                                /* istanbul ignore next */ request.onerror = function() {
                                    return reject(new Error('Failed to get internal value'));
                                };
                            })
                        ];
                    case 2:
                        error_6 = _a.sent();
                        this.logger.debug('DiagnosticsStorage: Failed to get internal value', error_6);
                        return [
                            2 /*return*/ ,
                            undefined
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.getLastFlushTimestamp = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var record, error_7;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        return [
                            4 /*yield*/ ,
                            this.getInternal(INTERNAL_KEYS.LAST_FLUSH_TIMESTAMP)
                        ];
                    case 1:
                        record = _a.sent();
                        return [
                            2 /*return*/ ,
                            record ? parseInt(record.value, 10) : undefined
                        ];
                    case 2:
                        error_7 = _a.sent();
                        /* istanbul ignore next */ this.logger.debug('DiagnosticsStorage: Failed to get last flush timestamp', error_7);
                        /* istanbul ignore next */ return [
                            2 /*return*/ ,
                            undefined
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsStorage.prototype.setLastFlushTimestamp = function(timestamp) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var error_8;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        return [
                            4 /*yield*/ ,
                            this.setInternal(INTERNAL_KEYS.LAST_FLUSH_TIMESTAMP, timestamp.toString())
                        ];
                    case 1:
                        _a.sent();
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 2:
                        error_8 = _a.sent();
                        /* istanbul ignore next */ this.logger.debug('DiagnosticsStorage: Failed to set last flush timestamp', error_8);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /* istanbul ignore next */ DiagnosticsStorage.prototype.clearTable = function(transaction, tableName) {
        return new Promise(function(resolve, reject) {
            var store = transaction.objectStore(tableName);
            var request = store.clear();
            request.onsuccess = function() {
                return resolve();
            };
            request.onerror = function() {
                return reject(new Error("Failed to clear table ".concat(tableName)));
            };
        });
    };
    /* istanbul ignore next */ DiagnosticsStorage.prototype.getAllAndClear = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var db, transaction, _a, tags, counters, histogramStats, events, error_9;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        _b.trys.push([
                            0,
                            4,
                            ,
                            5
                        ]);
                        return [
                            4 /*yield*/ ,
                            this.getDB()
                        ];
                    case 1:
                        db = _b.sent();
                        transaction = db.transaction([
                            TABLE_NAMES.TAGS,
                            TABLE_NAMES.COUNTERS,
                            TABLE_NAMES.HISTOGRAMS,
                            TABLE_NAMES.EVENTS
                        ], 'readwrite');
                        return [
                            4 /*yield*/ ,
                            Promise.all([
                                this.getAllFromStore(transaction, TABLE_NAMES.TAGS),
                                this.getAllFromStore(transaction, TABLE_NAMES.COUNTERS),
                                this.getAllFromStore(transaction, TABLE_NAMES.HISTOGRAMS),
                                this.getAllFromStore(transaction, TABLE_NAMES.EVENTS)
                            ])
                        ];
                    case 2:
                        _a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"].apply(void 0, [
                            _b.sent(),
                            4
                        ]), tags = _a[0], counters = _a[1], histogramStats = _a[2], events = _a[3];
                        // Clear all data in the same transaction
                        return [
                            4 /*yield*/ ,
                            Promise.all([
                                this.clearTable(transaction, TABLE_NAMES.COUNTERS),
                                this.clearTable(transaction, TABLE_NAMES.HISTOGRAMS),
                                this.clearTable(transaction, TABLE_NAMES.EVENTS)
                            ])
                        ];
                    case 3:
                        // Clear all data in the same transaction
                        _b.sent();
                        return [
                            2 /*return*/ ,
                            {
                                tags: tags,
                                counters: counters,
                                histogramStats: histogramStats,
                                events: events
                            }
                        ];
                    case 4:
                        error_9 = _b.sent();
                        this.logger.debug('DiagnosticsStorage: Failed to get all and clear data', error_9);
                        return [
                            2 /*return*/ ,
                            {
                                tags: [],
                                counters: [],
                                histogramStats: [],
                                events: []
                            }
                        ];
                    case 5:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Helper method to get all records from a store within a transaction
     */ /* istanbul ignore next */ DiagnosticsStorage.prototype.getAllFromStore = function(transaction, tableName) {
        return new Promise(function(resolve, reject) {
            var store = transaction.objectStore(tableName);
            var request = store.getAll();
            request.onsuccess = function() {
                return resolve(request.result);
            };
            request.onerror = function() {
                return reject(new Error("Failed to get all from ".concat(tableName)));
            };
        });
    };
    return DiagnosticsStorage;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/sampling.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateHashCode",
    ()=>generateHashCode,
    "isTimestampInSample",
    ()=>isTimestampInSample,
    "isTimestampInSampleTemp",
    ()=>isTimestampInSampleTemp
]);
var generateHashCode = function(str) {
    var hash = 0;
    if (str.length === 0) return hash;
    for(var i = 0; i < str.length; i++){
        var chr = str.charCodeAt(i);
        hash = (hash << 5) - hash + chr;
        hash |= 0;
    }
    return hash;
};
var isTimestampInSample = function(timestamp, sampleRate) {
    var hashNumber = generateHashCode(timestamp.toString());
    var absHash = Math.abs(hashNumber);
    var absHashMultiply = absHash * 31;
    var mod = absHashMultiply % 1000000;
    return mod / 1000000 < sampleRate;
};
var isTimestampInSampleTemp = function(timestamp, sampleRate) {
    var hashNumber = generateHashCode(timestamp.toString());
    var absHash = Math.abs(hashNumber);
    var absHashMultiply = absHash * 31;
    var mod = absHashMultiply % 100000;
    return mod / 100000 < sampleRate;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/diagnostics/uncaught-sdk-errors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EVENT_NAME_ERROR_UNCAUGHT",
    ()=>EVENT_NAME_ERROR_UNCAUGHT,
    "GLOBAL_KEY",
    ()=>GLOBAL_KEY,
    "enableSdkErrorListeners",
    ()=>enableSdkErrorListeners,
    "registerSdkLoaderMetadata",
    ()=>registerSdkLoaderMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
var GLOBAL_KEY = '__AMPLITUDE_SCRIPT_URL__';
var EVENT_NAME_ERROR_UNCAUGHT = 'sdk.error.uncaught';
var getNormalizedScriptUrls = function() {
    var scope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore next */ if (!scope) {
        return [];
    }
    var value = scope[GLOBAL_KEY];
    if (Array.isArray(value)) {
        return value;
    }
    /* istanbul ignore next - legacy single URL stored as string */ if (typeof value === 'string') {
        return [
            value
        ];
    }
    return [];
};
var addNormalizedScriptUrl = function(url) {
    var scope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore next */ if (!scope) {
        return;
    }
    var urls = getNormalizedScriptUrls();
    if (!urls.includes(url)) {
        urls.push(url);
        scope[GLOBAL_KEY] = urls;
    }
};
var registerSdkLoaderMetadata = function(metadata) {
    if (metadata.scriptUrl) {
        var normalized = normalizeUrl(metadata.scriptUrl);
        if (normalized) {
            addNormalizedScriptUrl(normalized);
        }
    }
};
var enableSdkErrorListeners = function(client) {
    var scope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    if (!scope || typeof scope.addEventListener !== 'function') {
        return;
    }
    var handleError = function(event) {
        var error = event.error instanceof Error ? event.error : undefined;
        var stack = error === null || error === void 0 ? void 0 : error.stack;
        var match = detectSdkOrigin({
            filename: event.filename,
            stack: stack
        });
        if (!match) {
            return;
        }
        capture({
            type: 'error',
            message: event.message,
            stack: stack,
            filename: event.filename,
            errorName: error === null || error === void 0 ? void 0 : error.name,
            metadata: {
                colno: event.colno,
                lineno: event.lineno,
                isTrusted: event.isTrusted,
                matchReason: match
            }
        });
    };
    var handleRejection = function(event) {
        var _a;
        var error = event.reason instanceof Error ? event.reason : undefined;
        var stack = error === null || error === void 0 ? void 0 : error.stack;
        var filename = extractFilenameFromStack(stack);
        var match = detectSdkOrigin({
            filename: filename,
            stack: stack
        });
        if (!match) {
            return;
        }
        /* istanbul ignore next */ capture({
            type: 'unhandledrejection',
            message: (_a = error === null || error === void 0 ? void 0 : error.message) !== null && _a !== void 0 ? _a : stringifyReason(event.reason),
            stack: stack,
            filename: filename,
            errorName: error === null || error === void 0 ? void 0 : error.name,
            metadata: {
                isTrusted: event.isTrusted,
                matchReason: match
            }
        });
    };
    var capture = function(context) {
        client.recordEvent(EVENT_NAME_ERROR_UNCAUGHT, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
            type: context.type,
            message: context.message,
            filename: context.filename,
            error_name: context.errorName,
            stack: context.stack
        }, context.metadata));
    };
    scope.addEventListener('error', handleError, true);
    scope.addEventListener('unhandledrejection', handleRejection, true);
};
var detectSdkOrigin = function(payload) {
    var e_1, _a;
    var normalizedScriptUrls = getNormalizedScriptUrls();
    if (normalizedScriptUrls.length === 0) {
        return undefined;
    }
    try {
        for(var normalizedScriptUrls_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(normalizedScriptUrls), normalizedScriptUrls_1_1 = normalizedScriptUrls_1.next(); !normalizedScriptUrls_1_1.done; normalizedScriptUrls_1_1 = normalizedScriptUrls_1.next()){
            var normalizedScriptUrl = normalizedScriptUrls_1_1.value;
            if (payload.filename && payload.filename.includes(normalizedScriptUrl)) {
                return 'filename';
            }
            if (payload.stack && payload.stack.includes(normalizedScriptUrl)) {
                return 'stack';
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (normalizedScriptUrls_1_1 && !normalizedScriptUrls_1_1.done && (_a = normalizedScriptUrls_1.return)) _a.call(normalizedScriptUrls_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    return undefined;
};
var normalizeUrl = function(value) {
    var _a, _b;
    try {
        /* istanbul ignore next */ var url = new URL(value, (_b = (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.location) === null || _b === void 0 ? void 0 : _b.origin);
        return url.origin + url.pathname;
    } catch (_c) {
        return undefined;
    }
};
var extractFilenameFromStack = function(stack) {
    if (!stack) {
        return undefined;
    }
    var match = stack.match(/(https?:\/\/\S+?)(?=[)\s]|$)/);
    /* istanbul ignore next */ return match ? match[1] : undefined;
};
/* istanbul ignore next */ var stringifyReason = function(reason) {
    if (typeof reason === 'string') {
        return reason;
    }
    try {
        return JSON.stringify(reason);
    } catch (_a) {
        return '[object Object]';
    }
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/diagnostics/diagnostics-client.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DIAGNOSTICS_EU_SERVER_URL",
    ()=>DIAGNOSTICS_EU_SERVER_URL,
    "DIAGNOSTICS_US_SERVER_URL",
    ()=>DIAGNOSTICS_US_SERVER_URL,
    "DiagnosticsClient",
    ()=>DiagnosticsClient,
    "FLUSH_INTERVAL_MS",
    ()=>FLUSH_INTERVAL_MS,
    "MAX_MEMORY_STORAGE_COUNT",
    ()=>MAX_MEMORY_STORAGE_COUNT,
    "MAX_MEMORY_STORAGE_EVENTS_COUNT",
    ()=>MAX_MEMORY_STORAGE_EVENTS_COUNT,
    "SAVE_INTERVAL_MS",
    ()=>SAVE_INTERVAL_MS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$diagnostics$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/diagnostics/diagnostics-storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$sampling$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/sampling.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$uncaught$2d$sdk$2d$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/diagnostics/uncaught-sdk-errors.js [app-client] (ecmascript)");
;
;
;
;
;
var SAVE_INTERVAL_MS = 1000; // 1 second
var FLUSH_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
var DIAGNOSTICS_US_SERVER_URL = 'https://diagnostics.prod.us-west-2.amplitude.com/v1/capture';
var DIAGNOSTICS_EU_SERVER_URL = 'https://diagnostics.prod.eu-central-1.amplitude.com/v1/capture';
var MAX_MEMORY_STORAGE_COUNT = 10000; // for tags, counters, histograms separately
var MAX_MEMORY_STORAGE_EVENTS_COUNT = 10;
var DiagnosticsClient = function() {
    function DiagnosticsClient(apiKey, logger, serverZone, options) {
        if (serverZone === void 0) {
            serverZone = 'US';
        }
        // In-memory storages
        this.inMemoryTags = {};
        this.inMemoryCounters = {};
        this.inMemoryHistograms = {};
        this.inMemoryEvents = [];
        // Timer for 1-second persistence
        this.saveTimer = null;
        // Timer for flush interval
        this.flushTimer = null;
        this.apiKey = apiKey;
        this.logger = logger;
        this.serverUrl = serverZone === 'US' ? DIAGNOSTICS_US_SERVER_URL : DIAGNOSTICS_EU_SERVER_URL;
        this.logger.debug('DiagnosticsClient: Initializing with options', JSON.stringify(options, null, 2));
        // Diagnostics is enabled by default with sample rate of 0 (no sampling)
        this.config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
            enabled: true,
            sampleRate: 0
        }, options);
        this.startTimestamp = Date.now();
        this.shouldTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$sampling$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTimestampInSampleTemp"])(this.startTimestamp, this.config.sampleRate) && this.config.enabled;
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$diagnostics$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiagnosticsStorage"].isSupported()) {
            this.storage = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$diagnostics$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiagnosticsStorage"](apiKey, logger);
        } else {
            this.logger.debug('DiagnosticsClient: IndexedDB is not supported');
        }
        void this.initializeFlushInterval();
        // Track internal diagnostics metrics for sampling
        if (this.shouldTrack) {
            this.increment('sdk.diagnostics.sampled.in.and.enabled');
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$uncaught$2d$sdk$2d$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["enableSdkErrorListeners"])(this);
        }
    }
    /**
     * Check if storage is available and tracking is enabled
     */ DiagnosticsClient.prototype.isStorageAndTrackEnabled = function() {
        return Boolean(this.storage) && Boolean(this.shouldTrack);
    };
    DiagnosticsClient.prototype.setTag = function(name, value) {
        if (!this.isStorageAndTrackEnabled()) {
            return;
        }
        if (Object.keys(this.inMemoryTags).length >= MAX_MEMORY_STORAGE_COUNT) {
            this.logger.debug('DiagnosticsClient: Early return setTags as reaching memory limit');
            return;
        }
        this.inMemoryTags[name] = value;
        this.startTimersIfNeeded();
    };
    DiagnosticsClient.prototype.increment = function(name, size) {
        if (size === void 0) {
            size = 1;
        }
        if (!this.isStorageAndTrackEnabled()) {
            return;
        }
        if (Object.keys(this.inMemoryCounters).length >= MAX_MEMORY_STORAGE_COUNT) {
            this.logger.debug('DiagnosticsClient: Early return increment as reaching memory limit');
            return;
        }
        this.inMemoryCounters[name] = (this.inMemoryCounters[name] || 0) + size;
        this.startTimersIfNeeded();
    };
    DiagnosticsClient.prototype.recordHistogram = function(name, value) {
        if (!this.isStorageAndTrackEnabled()) {
            return;
        }
        if (Object.keys(this.inMemoryHistograms).length >= MAX_MEMORY_STORAGE_COUNT) {
            this.logger.debug('DiagnosticsClient: Early return recordHistogram as reaching memory limit');
            return;
        }
        var existing = this.inMemoryHistograms[name];
        if (existing) {
            // Update existing stats incrementally
            existing.count += 1;
            existing.min = Math.min(existing.min, value);
            existing.max = Math.max(existing.max, value);
            existing.sum += value;
        } else {
            // Create new stats
            this.inMemoryHistograms[name] = {
                count: 1,
                min: value,
                max: value,
                sum: value
            };
        }
        this.startTimersIfNeeded();
    };
    DiagnosticsClient.prototype.recordEvent = function(name, properties) {
        if (!this.isStorageAndTrackEnabled()) {
            return;
        }
        if (this.inMemoryEvents.length >= MAX_MEMORY_STORAGE_EVENTS_COUNT) {
            this.logger.debug('DiagnosticsClient: Early return recordEvent as reaching memory limit');
            return;
        }
        this.inMemoryEvents.push({
            event_name: name,
            time: Date.now(),
            event_properties: properties
        });
        this.startTimersIfNeeded();
    };
    DiagnosticsClient.prototype.startTimersIfNeeded = function() {
        var _this = this;
        if (!this.saveTimer) {
            this.saveTimer = setTimeout(function() {
                _this.saveAllDataToStorage().catch(function(error) {
                    _this.logger.debug('DiagnosticsClient: Failed to save all data to storage', error);
                }).finally(function() {
                    _this.saveTimer = null;
                });
            }, SAVE_INTERVAL_MS);
        }
        if (!this.flushTimer) {
            this.flushTimer = setTimeout(function() {
                _this._flush().catch(function(error) {
                    _this.logger.debug('DiagnosticsClient: Failed to flush', error);
                }).finally(function() {
                    _this.flushTimer = null;
                });
            }, FLUSH_INTERVAL_MS);
        }
    };
    DiagnosticsClient.prototype.saveAllDataToStorage = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var tagsToSave, countersToSave, histogramsToSave, eventsToSave;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        if (!this.storage) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        tagsToSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this.inMemoryTags);
                        countersToSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this.inMemoryCounters);
                        histogramsToSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this.inMemoryHistograms);
                        eventsToSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(this.inMemoryEvents), false);
                        this.inMemoryEvents = [];
                        this.inMemoryTags = {};
                        this.inMemoryCounters = {};
                        this.inMemoryHistograms = {};
                        return [
                            4 /*yield*/ ,
                            Promise.all([
                                this.storage.setTags(tagsToSave),
                                this.storage.incrementCounters(countersToSave),
                                this.storage.setHistogramStats(histogramsToSave),
                                this.storage.addEventRecords(eventsToSave)
                            ])
                        ];
                    case 1:
                        _a.sent();
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    DiagnosticsClient.prototype._flush = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var _a, tagRecords, counterRecords, histogramStatsRecords, eventRecords, tags, counters, histogram, events, payload;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        if (!this.storage) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.saveAllDataToStorage()
                        ];
                    case 1:
                        _b.sent();
                        this.saveTimer = null;
                        this.flushTimer = null;
                        return [
                            4 /*yield*/ ,
                            this.storage.getAllAndClear()
                        ];
                    case 2:
                        _a = _b.sent(), tagRecords = _a.tags, counterRecords = _a.counters, histogramStatsRecords = _a.histogramStats, eventRecords = _a.events;
                        // Update the last flush timestamp
                        void this.storage.setLastFlushTimestamp(Date.now());
                        tags = {};
                        tagRecords.forEach(function(record) {
                            tags[record.key] = record.value;
                        });
                        counters = {};
                        counterRecords.forEach(function(record) {
                            counters[record.key] = record.value;
                        });
                        histogram = {};
                        histogramStatsRecords.forEach(function(stats) {
                            histogram[stats.key] = {
                                count: stats.count,
                                min: stats.min,
                                max: stats.max,
                                avg: Math.round(stats.sum / stats.count * 100) / 100
                            };
                        });
                        events = eventRecords.map(function(record) {
                            return {
                                event_name: record.event_name,
                                time: record.time,
                                event_properties: record.event_properties
                            };
                        });
                        // Early return if all data collections are empty
                        if (Object.keys(counters).length === 0 && Object.keys(histogram).length === 0 && events.length === 0) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        payload = {
                            tags: tags,
                            histogram: histogram,
                            counters: counters,
                            events: events
                        };
                        // Send payload to diagnostics server
                        void this.fetch(payload);
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Send diagnostics data to the server
     */ DiagnosticsClient.prototype.fetch = function(payload) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var response, error_1;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        _a.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) {
                            throw new Error('DiagnosticsClient: Fetch is not supported');
                        }
                        return [
                            4 /*yield*/ ,
                            fetch(this.serverUrl, {
                                method: 'POST',
                                headers: {
                                    'X-ApiKey': this.apiKey,
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(payload)
                            })
                        ];
                    case 1:
                        response = _a.sent();
                        if (!response.ok) {
                            this.logger.debug('DiagnosticsClient: Failed to send diagnostics data.');
                            return [
                                2 /*return*/ 
                            ];
                        }
                        this.logger.debug('DiagnosticsClient: Successfully sent diagnostics data');
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 2:
                        error_1 = _a.sent();
                        this.logger.debug('DiagnosticsClient: Failed to send diagnostics data. ', error_1);
                        return [
                            3 /*break*/ ,
                            3
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Initialize flush interval logic.
     * Check if 5 minutes has passed since last flush, if so flush immediately.
     * Otherwise set a timer to flush when the interval is reached.
     */ DiagnosticsClient.prototype.initializeFlushInterval = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var now, lastFlushTimestamp, timeSinceLastFlush;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        if (!this.storage) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        now = Date.now();
                        return [
                            4 /*yield*/ ,
                            this.storage.getLastFlushTimestamp()
                        ];
                    case 1:
                        lastFlushTimestamp = _a.sent() || -1;
                        // If last flush timestamp is -1, it means this is a new client
                        // Save current timestamp as the initial "last flush timestamp"
                        // and schedule the flush timer
                        if (lastFlushTimestamp === -1) {
                            void this.storage.setLastFlushTimestamp(now);
                            this._setFlushTimer(FLUSH_INTERVAL_MS);
                            return [
                                2 /*return*/ 
                            ];
                        }
                        timeSinceLastFlush = now - lastFlushTimestamp;
                        if (timeSinceLastFlush >= FLUSH_INTERVAL_MS) {
                            // More than 5 minutes has passed, flush immediately
                            void this._flush();
                            return [
                                2 /*return*/ 
                            ];
                        } else {
                            // Set timer for remaining time
                            this._setFlushTimer(FLUSH_INTERVAL_MS - timeSinceLastFlush);
                        }
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Helper method to set flush timer with consistent error handling
     */ DiagnosticsClient.prototype._setFlushTimer = function(delay) {
        var _this = this;
        this.flushTimer = setTimeout(function() {
            _this._flush().catch(function(error) {
                _this.logger.debug('DiagnosticsClient: Failed to flush', error);
            }).finally(function() {
                _this.flushTimer = null;
            });
        }, delay);
    };
    DiagnosticsClient.prototype._setSampleRate = function(sampleRate) {
        this.logger.debug('DiagnosticsClient: Setting sample rate to', sampleRate);
        this.config.sampleRate = sampleRate;
        this.shouldTrack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$sampling$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTimestampInSampleTemp"])(this.startTimestamp, this.config.sampleRate) && this.config.enabled;
        this.logger.debug('DiagnosticsClient: Should track is', this.shouldTrack);
    };
    return DiagnosticsClient;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/safe-stringify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "safeJsonStringify",
    ()=>safeJsonStringify
]);
/* eslint-disable @typescript-eslint/no-unsafe-assignment */ /* eslint-disable @typescript-eslint/no-unsafe-member-access */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$safe$2d$json$2d$stringify$40$1$2e$2$2e$0$2f$node_modules$2f$safe$2d$json$2d$stringify$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/safe-json-stringify@1.2.0/node_modules/safe-json-stringify/index.js [app-client] (ecmascript)");
;
/* istanbul ignore next */ var safeJsonStringify = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$safe$2d$json$2d$stringify$40$1$2e$2$2e$0$2f$node_modules$2f$safe$2d$json$2d$stringify$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.default || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$safe$2d$json$2d$stringify$40$1$2e$2$2e$0$2f$node_modules$2f$safe$2d$json$2d$stringify$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__;
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/environment.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isChromeExtension",
    ()=>isChromeExtension
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
function isChromeExtension() {
    var _a, _b;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    return typeof ((_b = (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.chrome) === null || _a === void 0 ? void 0 : _a.runtime) === null || _b === void 0 ? void 0 : _b.id) === 'string';
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/language.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLanguage",
    ()=>getLanguage
]);
var getLanguage = function() {
    var _a, _b, _c, _d;
    if (typeof navigator === 'undefined') return '';
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    var userLanguage = navigator.userLanguage;
    return (_d = (_c = (_b = (_a = navigator.languages) === null || _a === void 0 ? void 0 : _a[0]) !== null && _b !== void 0 ? _b : navigator.language) !== null && _c !== void 0 ? _c : userLanguage) !== null && _d !== void 0 ? _d : '';
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/memory.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MemoryStorage",
    ()=>MemoryStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var MemoryStorage = function() {
    function MemoryStorage() {
        this.memoryStorage = new Map();
    }
    MemoryStorage.prototype.isEnabled = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    true
                ];
            });
        });
    };
    MemoryStorage.prototype.get = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    this.memoryStorage.get(key)
                ];
            });
        });
    };
    MemoryStorage.prototype.getRaw = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var value;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        return [
                            4 /*yield*/ ,
                            this.get(key)
                        ];
                    case 1:
                        value = _a.sent();
                        return [
                            2 /*return*/ ,
                            value ? JSON.stringify(value) : undefined
                        ];
                }
            });
        });
    };
    MemoryStorage.prototype.set = function(key, value) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                this.memoryStorage.set(key, value);
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    MemoryStorage.prototype.remove = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                this.memoryStorage.delete(key);
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    MemoryStorage.prototype.reset = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                this.memoryStorage.clear();
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return MemoryStorage;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/cookie.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CookieStorage",
    ()=>CookieStorage,
    "decodeCookieValue",
    ()=>decodeCookieValue,
    "isDomainEqual",
    ()=>isDomainEqual
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
/* istanbul ignore next */ var getLocks = function() {
    var _a;
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    return (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.navigator) === null || _a === void 0 ? void 0 : _a.locks;
};
var CookieStorage = function() {
    function CookieStorage(options, config) {
        if (config === void 0) {
            config = {};
        }
        this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, options);
        this.config = config;
    }
    CookieStorage.prototype.isEnabled = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var testKey, testCookieOptions, testStorage, testValue;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        testKey = 'AMP_TEST';
                        testCookieOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this.options);
                        testStorage = new CookieStorage(testCookieOptions);
                        testValue = String(Date.now());
                        return [
                            4 /*yield*/ ,
                            testStorage.transaction(testKey, function(storage) {
                                var _a, _b;
                                try {
                                    storage.set(testValue);
                                    var value = storage.get();
                                    var result = value === testValue;
                                    /* istanbul ignore next */ if (!result && _this.config.diagnosticsClient) {
                                        (_a = _this.config.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.recordEvent('cookies.isEnabled.failure', {
                                            reason: 'Test Value mismatch',
                                            testKey: testKey,
                                            testValue: testValue,
                                            sync: true
                                        });
                                    }
                                    return result;
                                } catch (e) {
                                    /* istanbul ignore next */ if (_this.config.diagnosticsClient) {
                                        var errMessage = e instanceof Error ? e.message : String(e);
                                        (_b = _this.config.diagnosticsClient) === null || _b === void 0 ? void 0 : _b.recordEvent('cookies.isEnabled.failure', {
                                            reason: 'Cookie getter/setter failed',
                                            testKey: testKey,
                                            testValue: testValue,
                                            error: errMessage,
                                            sync: true
                                        });
                                    }
                                    return false;
                                } finally{
                                    // clean-up the AMP_TEST cookie behind us
                                    storage.set(null);
                                }
                            })
                        ];
                    case 1:
                        return [
                            2 /*return*/ ,
                            _a.sent()
                        ];
                }
            });
        });
    };
    CookieStorage.prototype.get = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var value;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        return [
                            4 /*yield*/ ,
                            this.getRaw(key)
                        ];
                    case 1:
                        value = _a.sent();
                        return [
                            2 /*return*/ ,
                            this.decodeCookieValue(key, value)
                        ];
                }
            });
        });
    };
    CookieStorage.prototype.decodeCookieValue = function(key, value) {
        if (!value) {
            return undefined;
        }
        try {
            var decodedValue = decodeCookieValue(value);
            if (decodedValue === undefined) {
                console.error("Amplitude Logger [Error]: Failed to decode cookie value for key: ".concat(key, ", value: ").concat(value));
                return undefined;
            }
            // eslint-disable-next-line @typescript-eslint/no-unsafe-return
            return JSON.parse(decodedValue);
        } catch (_a) {
            console.error("Amplitude Logger [Error]: Failed to parse cookie value for key: ".concat(key, ", value: ").concat(value));
            return undefined;
        }
    };
    CookieStorage.prototype.getSync = function(key) {
        var value = this.getRawSync(key);
        return this.decodeCookieValue(key, value);
    };
    CookieStorage.prototype.getRaw = function(key) {
        var _a, _b;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var globalScope, globalScopeWithCookiesStore, cookieStore, cookies, cookies_1, cookies_1_1, cookie, ignoreError_1;
            var e_1, _c;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_d) {
                switch(_d.label){
                    case 0:
                        globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
                        globalScopeWithCookiesStore = globalScope;
                        _d.label = 1;
                    case 1:
                        _d.trys.push([
                            1,
                            4,
                            ,
                            5
                        ]);
                        cookieStore = globalScopeWithCookiesStore === null || globalScopeWithCookiesStore === void 0 ? void 0 : globalScopeWithCookiesStore.cookieStore;
                        if (!cookieStore) return [
                            3 /*break*/ ,
                            3
                        ];
                        return [
                            4 /*yield*/ ,
                            cookieStore.getAll(key)
                        ];
                    case 2:
                        cookies = _d.sent();
                        if (cookies) {
                            /* istanbul ignore if */ if (cookies.length > 1) {
                                (_a = this.config.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.recordEvent('cookies.duplicate', {
                                    cookies: cookies.map(function(cookie) {
                                        return cookie.domain;
                                    })
                                });
                                (_b = this.config.diagnosticsClient) === null || _b === void 0 ? void 0 : _b.increment('cookies.duplicate.occurrence.cookieStore');
                            }
                            try {
                                for(cookies_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(cookies), cookies_1_1 = cookies_1.next(); !cookies_1_1.done; cookies_1_1 = cookies_1.next()){
                                    cookie = cookies_1_1.value;
                                    if (isDomainEqual(cookie.domain, this.options.domain)) {
                                        return [
                                            2 /*return*/ ,
                                            cookie.value
                                        ];
                                    }
                                }
                            } catch (e_1_1) {
                                e_1 = {
                                    error: e_1_1
                                };
                            } finally{
                                try {
                                    if (cookies_1_1 && !cookies_1_1.done && (_c = cookies_1.return)) _c.call(cookies_1);
                                } finally{
                                    if (e_1) throw e_1.error;
                                }
                            }
                        }
                        _d.label = 3;
                    case 3:
                        return [
                            3 /*break*/ ,
                            5
                        ];
                    case 4:
                        ignoreError_1 = _d.sent();
                        return [
                            3 /*break*/ ,
                            5
                        ];
                    case 5:
                        return [
                            2 /*return*/ ,
                            this.getRawSync(key)
                        ];
                }
            });
        });
    };
    CookieStorage.prototype.getRawSync = function(key) {
        var _this = this;
        var _a, _b;
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        var cookies = ((_b = (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.document) === null || _a === void 0 ? void 0 : _a.cookie.split('; ')) !== null && _b !== void 0 ? _b : []).filter(function(c) {
            return c.indexOf(key + '=') === 0;
        });
        var match = undefined;
        // if matcher function is provided, use it to de-duplicate when there's more than one cookie
        /* istanbul ignore if */ var duplicateResolverFn = this.config.duplicateResolverFn;
        if (typeof duplicateResolverFn === 'function' && cookies.length > 1) {
            match = cookies.find(function(c) {
                var _a;
                try {
                    var res = duplicateResolverFn(c.substring(key.length + 1));
                    if (!res) {
                        (_a = _this.config.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.increment('cookies.duplicate.occurrence.document.cookie');
                    }
                    return res;
                } catch (ignoreError) {
                    /* istanbul ignore next */ return false;
                }
            });
        }
        // if match was not found, just get the first one that matches the key
        if (!match) {
            match = cookies[0];
        }
        if (!match) {
            return undefined;
        }
        return match.substring(key.length + 1);
    };
    CookieStorage.prototype.set = function(key, value) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                this.setSync(key, value);
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    CookieStorage.prototype.setSync = function(key, value) {
        var _a;
        try {
            var expirationDays = (_a = this.options.expirationDays) !== null && _a !== void 0 ? _a : 0;
            var expires = value !== null ? expirationDays : -1;
            var expireDate = undefined;
            if (expires) {
                var date = new Date();
                date.setTime(date.getTime() + expires * 24 * 60 * 60 * 1000);
                expireDate = date;
            }
            var str = "".concat(key, "=").concat(btoa(encodeURIComponent(JSON.stringify(value))));
            if (expireDate) {
                str += "; expires=".concat(expireDate.toUTCString());
            }
            str += '; path=/';
            if (this.options.domain) {
                str += "; domain=".concat(this.options.domain);
            }
            if (this.options.secure) {
                str += '; Secure';
            }
            if (this.options.sameSite) {
                str += "; SameSite=".concat(this.options.sameSite);
            }
            var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
            if (globalScope === null || globalScope === void 0 ? void 0 : globalScope.document) {
                globalScope.document.cookie = str;
            }
        } catch (error) {
            var errorMessage = error instanceof Error ? error.message : String(error);
            console.error("Amplitude Logger [Error]: Failed to set cookie for key: ".concat(key, ". Error: ").concat(errorMessage));
        }
    };
    CookieStorage.prototype.remove = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        return [
                            4 /*yield*/ ,
                            this.set(key, null)
                        ];
                    case 1:
                        _a.sent();
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    CookieStorage.prototype.reset = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    CookieStorage.isDomainWritable = function(domain) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var options, storageKey, storage, res, error_1;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        if (CookieStorage.cachedTlds[domain]) {
                            return [
                                2 /*return*/ ,
                                true
                            ];
                        }
                        options = {
                            domain: '.' + domain
                        };
                        storageKey = 'AMP_TLDTEST';
                        storage = new CookieStorage(options);
                        _a.label = 1;
                    case 1:
                        _a.trys.push([
                            1,
                            3,
                            ,
                            4
                        ]);
                        return [
                            4 /*yield*/ ,
                            storage.transaction(storageKey, function(storageSync) {
                                if (CookieStorage.cachedTlds[domain]) {
                                    return true;
                                }
                                try {
                                    storageSync.set(1);
                                    var result = !!storageSync.get();
                                    if (result) {
                                        CookieStorage.cachedTlds[domain] = true;
                                    }
                                    return result;
                                } finally{
                                    storageSync.set(null);
                                }
                            })
                        ];
                    case 2:
                        res = _a.sent();
                        return [
                            2 /*return*/ ,
                            !!res
                        ];
                    case 3:
                        error_1 = _a.sent();
                        return [
                            2 /*return*/ ,
                            false
                        ];
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    CookieStorage.prototype.transaction = function(key, callback) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var locks, callbackWrapper, error_2;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        locks = getLocks();
                        callbackWrapper = function() {
                            // construct a sync storage object that is scoped to
                            // Cookie with name <key>
                            var storageSync = {
                                get: function() {
                                    return _this.getSync(key);
                                },
                                set: function(value) {
                                    return _this.setSync(key, value);
                                }
                            };
                            return callback(storageSync);
                        };
                        // if 'locks' is missing, it is a legacy browser, just call the callback directly
                        // and settle for a transaction that isn't isolated across tabs
                        if (!locks) {
                            return [
                                2 /*return*/ ,
                                callbackWrapper()
                            ];
                        }
                        _a.label = 1;
                    case 1:
                        _a.trys.push([
                            1,
                            3,
                            ,
                            4
                        ]);
                        return [
                            4 /*yield*/ ,
                            locks.request("com.amplitude:cookie-lock:".concat(key), callbackWrapper)
                        ];
                    case 2:
                        return [
                            2 /*return*/ ,
                            _a.sent()
                        ];
                    case 3:
                        error_2 = _a.sent();
                        return [
                            2 /*return*/ ,
                            callbackWrapper()
                        ];
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    CookieStorage.cachedTlds = {};
    return CookieStorage;
}();
;
var decodeCookiesAsDefault = function(value) {
    try {
        return decodeURIComponent(atob(value));
    } catch (_a) {
        return undefined;
    }
};
var decodeCookiesWithDoubleUrlEncoding = function(value) {
    // Modern Ruby (v7+) automatically encodes cookies with URL encoding by
    // https://api.rubyonrails.org/classes/ActionDispatch/Cookies.html
    try {
        return decodeURIComponent(atob(decodeURIComponent(value)));
    } catch (_a) {
        return undefined;
    }
};
var decodeCookieValue = function(value) {
    var _a;
    return (_a = decodeCookiesAsDefault(value)) !== null && _a !== void 0 ? _a : decodeCookiesWithDoubleUrlEncoding(value);
};
var isDomainEqual = function(domain1, domain2) {
    if (domain1 === '' && domain2 === '') {
        return true;
    }
    if (!domain1 || !domain2) {
        return false;
    }
    var normalized1 = domain1.startsWith('.') ? domain1.substring(1) : domain1;
    var normalized2 = domain2.startsWith('.') ? domain2.substring(1) : domain2;
    return normalized1.toLowerCase() === normalized2.toLowerCase();
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/cookie-name.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getCookieName",
    ()=>getCookieName,
    "getOldCookieName",
    ()=>getOldCookieName
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
;
var getCookieName = function(apiKey, postKey, limit) {
    if (postKey === void 0) {
        postKey = '';
    }
    if (limit === void 0) {
        limit = 10;
    }
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_PREFIX"],
        postKey,
        apiKey.substring(0, limit)
    ].filter(Boolean).join('_');
};
var getOldCookieName = function(apiKey) {
    return "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_PREFIX"].toLowerCase(), "_").concat(apiKey.substring(0, 6));
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/browser-storage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BrowserStorage",
    ()=>BrowserStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var BrowserStorage = function() {
    function BrowserStorage(storage) {
        this.storage = storage;
    }
    BrowserStorage.prototype.isEnabled = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var random, testStorage, testKey, value, _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        /* istanbul ignore if */ if (!this.storage) {
                            return [
                                2 /*return*/ ,
                                false
                            ];
                        }
                        random = String(Date.now());
                        testStorage = new BrowserStorage(this.storage);
                        testKey = 'AMP_TEST';
                        _b.label = 1;
                    case 1:
                        _b.trys.push([
                            1,
                            4,
                            5,
                            7
                        ]);
                        return [
                            4 /*yield*/ ,
                            testStorage.set(testKey, random)
                        ];
                    case 2:
                        _b.sent();
                        return [
                            4 /*yield*/ ,
                            testStorage.get(testKey)
                        ];
                    case 3:
                        value = _b.sent();
                        return [
                            2 /*return*/ ,
                            value === random
                        ];
                    case 4:
                        _a = _b.sent();
                        /* istanbul ignore next */ return [
                            2 /*return*/ ,
                            false
                        ];
                    case 5:
                        return [
                            4 /*yield*/ ,
                            testStorage.remove(testKey)
                        ];
                    case 6:
                        _b.sent();
                        return [
                            7 /*endfinally*/ 
                        ];
                    case 7:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    BrowserStorage.prototype.get = function(key) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var value, _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        _b.trys.push([
                            0,
                            2,
                            ,
                            3
                        ]);
                        return [
                            4 /*yield*/ ,
                            this.getRaw(key)
                        ];
                    case 1:
                        value = _b.sent();
                        if (!value) {
                            return [
                                2 /*return*/ ,
                                undefined
                            ];
                        }
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-return
                        return [
                            2 /*return*/ ,
                            JSON.parse(value)
                        ];
                    case 2:
                        _a = _b.sent();
                        console.error("[Amplitude] Error: Could not get value from storage");
                        return [
                            2 /*return*/ ,
                            undefined
                        ];
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    BrowserStorage.prototype.getRaw = function(key) {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                return [
                    2 /*return*/ ,
                    ((_a = this.storage) === null || _a === void 0 ? void 0 : _a.getItem(key)) || undefined
                ];
            });
        });
    };
    BrowserStorage.prototype.set = function(key, value) {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                try {
                    (_a = this.storage) === null || _a === void 0 ? void 0 : _a.setItem(key, JSON.stringify(value));
                } catch (_c) {
                //
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    BrowserStorage.prototype.remove = function(key) {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                try {
                    (_a = this.storage) === null || _a === void 0 ? void 0 : _a.removeItem(key);
                } catch (_c) {
                //
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    BrowserStorage.prototype.reset = function() {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                try {
                    (_a = this.storage) === null || _a === void 0 ? void 0 : _a.clear();
                } catch (_c) {
                //
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return BrowserStorage;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/base.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseTransport",
    ()=>BaseTransport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/status.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$status$2d$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/status-code.js [app-client] (ecmascript)");
;
;
var BaseTransport = function() {
    function BaseTransport() {}
    BaseTransport.prototype.send = function(_serverUrl, _payload, _enableRequestBodyCompression) {
        return Promise.resolve(null);
    };
    BaseTransport.prototype.buildResponse = function(responseJSON) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
        if (typeof responseJSON !== 'object') {
            return null;
        }
        var statusCode = responseJSON.code || 0;
        var status = this.buildStatus(statusCode);
        switch(status){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Success:
                return {
                    status: status,
                    statusCode: statusCode,
                    body: {
                        eventsIngested: (_a = responseJSON.events_ingested) !== null && _a !== void 0 ? _a : 0,
                        payloadSizeBytes: (_b = responseJSON.payload_size_bytes) !== null && _b !== void 0 ? _b : 0,
                        serverUploadTime: (_c = responseJSON.server_upload_time) !== null && _c !== void 0 ? _c : 0
                    }
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Invalid:
                return {
                    status: status,
                    statusCode: statusCode,
                    body: {
                        error: (_d = responseJSON.error) !== null && _d !== void 0 ? _d : '',
                        missingField: (_e = responseJSON.missing_field) !== null && _e !== void 0 ? _e : '',
                        eventsWithInvalidFields: (_f = responseJSON.events_with_invalid_fields) !== null && _f !== void 0 ? _f : {},
                        eventsWithMissingFields: (_g = responseJSON.events_with_missing_fields) !== null && _g !== void 0 ? _g : {},
                        eventsWithInvalidIdLengths: (_h = responseJSON.events_with_invalid_id_lengths) !== null && _h !== void 0 ? _h : {},
                        epsThreshold: (_j = responseJSON.eps_threshold) !== null && _j !== void 0 ? _j : 0,
                        exceededDailyQuotaDevices: (_k = responseJSON.exceeded_daily_quota_devices) !== null && _k !== void 0 ? _k : {},
                        silencedDevices: (_l = responseJSON.silenced_devices) !== null && _l !== void 0 ? _l : [],
                        silencedEvents: (_m = responseJSON.silenced_events) !== null && _m !== void 0 ? _m : [],
                        throttledDevices: (_o = responseJSON.throttled_devices) !== null && _o !== void 0 ? _o : {},
                        throttledEvents: (_p = responseJSON.throttled_events) !== null && _p !== void 0 ? _p : []
                    }
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].PayloadTooLarge:
                return {
                    status: status,
                    statusCode: statusCode,
                    body: {
                        error: (_q = responseJSON.error) !== null && _q !== void 0 ? _q : ''
                    }
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].RateLimit:
                return {
                    status: status,
                    statusCode: statusCode,
                    body: {
                        error: (_r = responseJSON.error) !== null && _r !== void 0 ? _r : '',
                        epsThreshold: (_s = responseJSON.eps_threshold) !== null && _s !== void 0 ? _s : 0,
                        throttledDevices: (_t = responseJSON.throttled_devices) !== null && _t !== void 0 ? _t : {},
                        throttledUsers: (_u = responseJSON.throttled_users) !== null && _u !== void 0 ? _u : {},
                        exceededDailyQuotaDevices: (_v = responseJSON.exceeded_daily_quota_devices) !== null && _v !== void 0 ? _v : {},
                        exceededDailyQuotaUsers: (_w = responseJSON.exceeded_daily_quota_users) !== null && _w !== void 0 ? _w : {},
                        throttledEvents: (_x = responseJSON.throttled_events) !== null && _x !== void 0 ? _x : []
                    }
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Timeout:
            default:
                return {
                    status: status,
                    statusCode: statusCode
                };
        }
    };
    BaseTransport.prototype.buildStatus = function(code) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$status$2d$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSuccessStatusCode"])(code)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Success;
        }
        if (code === 429) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].RateLimit;
        }
        if (code === 413) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].PayloadTooLarge;
        }
        if (code === 408) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Timeout;
        }
        if (code >= 400 && code < 500) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Invalid;
        }
        if (code >= 500) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Failed;
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$status$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Status"].Unknown;
    };
    return BaseTransport;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/gzip.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MIN_GZIP_UPLOAD_BODY_SIZE_BYTES",
    ()=>MIN_GZIP_UPLOAD_BODY_SIZE_BYTES,
    "compressToGzipArrayBuffer",
    ()=>compressToGzipArrayBuffer,
    "isCompressionStreamAvailable",
    ()=>isCompressionStreamAvailable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var MIN_GZIP_UPLOAD_BODY_SIZE_BYTES = 2 * 1024;
function isCompressionStreamAvailable() {
    return typeof CompressionStream !== 'undefined';
}
function compressToGzipArrayBuffer(data) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
        var CompressionStreamImpl, stream, _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
            switch(_b.label){
                case 0:
                    CompressionStreamImpl = CompressionStream;
                    if (typeof CompressionStreamImpl === 'undefined') {
                        return [
                            2 /*return*/ ,
                            undefined
                        ];
                    }
                    _b.label = 1;
                case 1:
                    _b.trys.push([
                        1,
                        3,
                        ,
                        4
                    ]);
                    stream = new Blob([
                        data
                    ]).stream().pipeThrough(new CompressionStreamImpl('gzip'));
                    return [
                        4 /*yield*/ ,
                        new Response(stream).arrayBuffer()
                    ];
                case 2:
                    return [
                        2 /*return*/ ,
                        _b.sent()
                    ];
                case 3:
                    _a = _b.sent();
                    return [
                        2 /*return*/ ,
                        undefined
                    ];
                case 4:
                    return [
                        2 /*return*/ 
                    ];
            }
        });
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/config/browser-config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EXCLUDE_INTERNAL_REFERRERS_CONDITIONS",
    ()=>EXCLUDE_INTERNAL_REFERRERS_CONDITIONS
]);
var EXCLUDE_INTERNAL_REFERRERS_CONDITIONS = {
    always: 'always',
    ifEmptyCampaign: 'ifEmptyCampaign'
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/helpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CC_REGEX",
    ()=>CC_REGEX,
    "EMAIL_REGEX",
    ()=>EMAIL_REGEX,
    "MASKED_TEXT_VALUE",
    ()=>MASKED_TEXT_VALUE,
    "SSN_REGEX",
    ()=>SSN_REGEX,
    "TEXT_MASK_ATTRIBUTE",
    ()=>TEXT_MASK_ATTRIBUTE,
    "getPageTitle",
    ()=>getPageTitle,
    "replaceSensitiveString",
    ()=>replaceSensitiveString
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var TEXT_MASK_ATTRIBUTE = 'data-amp-mask';
var MASKED_TEXT_VALUE = '*****';
var CC_REGEX = /\b(?:\d[ -]*?){13,16}\b/;
var SSN_REGEX = /(\d{3}-?\d{2}-?\d{4})/g;
var EMAIL_REGEX = /[^\s@]+@[^\s@.]+\.[^\s@]+/g;
var replaceSensitiveString = function(text, additionalMaskTextPatterns) {
    var e_1, _a;
    if (additionalMaskTextPatterns === void 0) {
        additionalMaskTextPatterns = [];
    }
    if (typeof text !== 'string') {
        return '';
    }
    var result = text;
    // Check for credit card number (with or without spaces/dashes)
    result = result.replace(CC_REGEX, MASKED_TEXT_VALUE);
    // Check for social security number
    result = result.replace(SSN_REGEX, MASKED_TEXT_VALUE);
    // Check for email
    result = result.replace(EMAIL_REGEX, MASKED_TEXT_VALUE);
    try {
        // Check for additional mask text patterns
        for(var additionalMaskTextPatterns_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(additionalMaskTextPatterns), additionalMaskTextPatterns_1_1 = additionalMaskTextPatterns_1.next(); !additionalMaskTextPatterns_1_1.done; additionalMaskTextPatterns_1_1 = additionalMaskTextPatterns_1.next()){
            var pattern = additionalMaskTextPatterns_1_1.value;
            try {
                result = result.replace(pattern, MASKED_TEXT_VALUE);
            } catch (_b) {
            // ignore invalid pattern
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (additionalMaskTextPatterns_1_1 && !additionalMaskTextPatterns_1_1.done && (_a = additionalMaskTextPatterns_1.return)) _a.call(additionalMaskTextPatterns_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    return result;
};
var getPageTitle = function(parseTitleFunction) {
    if (typeof document === 'undefined' || !document.title) {
        return '';
    }
    var titleElement = document.querySelector('title');
    if (titleElement && titleElement.hasAttribute(TEXT_MASK_ATTRIBUTE)) {
        return MASKED_TEXT_VALUE;
    }
    return parseTitleFunction ? parseTitleFunction(document.title) : document.title; // document.title is always synced to the first title element
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/campaign/campaign-parser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CampaignParser",
    ()=>CampaignParser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/query-params.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
;
;
;
var CampaignParser = function() {
    function CampaignParser() {}
    CampaignParser.prototype.parse = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_CAMPAIGN"]), this.getUtmParam()), this.getReferrer()), this.getClickIds())
                ];
            });
        });
    };
    CampaignParser.prototype.getUtmParam = function() {
        var params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getQueryParams"])();
        var utmCampaign = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UTM_CAMPAIGN"]];
        var utmContent = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UTM_CONTENT"]];
        var utmId = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UTM_ID"]];
        var utmMedium = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UTM_MEDIUM"]];
        var utmSource = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UTM_SOURCE"]];
        var utmTerm = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UTM_TERM"]];
        return {
            utm_campaign: utmCampaign,
            utm_content: utmContent,
            utm_id: utmId,
            utm_medium: utmMedium,
            utm_source: utmSource,
            utm_term: utmTerm
        };
    };
    CampaignParser.prototype.getReferrer = function() {
        var _a, _b;
        var data = {
            referrer: undefined,
            referring_domain: undefined
        };
        try {
            data.referrer = document.referrer || undefined;
            data.referring_domain = (_b = (_a = data.referrer) === null || _a === void 0 ? void 0 : _a.split('/')[2]) !== null && _b !== void 0 ? _b : undefined;
        } catch (_c) {
        // nothing to track
        }
        return data;
    };
    CampaignParser.prototype.getClickIds = function() {
        var _a;
        var params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getQueryParams"])();
        return _a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DCLID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DCLID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FBCLID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FBCLID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GBRAID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GBRAID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GCLID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GCLID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KO_CLICK_ID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KO_CLICK_ID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LI_FAT_ID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LI_FAT_ID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSCLKID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSCLKID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RDT_CID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RDT_CID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TTCLID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TTCLID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TWCLID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TWCLID"]], _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WBRAID"]] = params[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WBRAID"]], _a;
    };
    return CampaignParser;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/omit-undefined.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "omitUndefined",
    ()=>omitUndefined
]);
var omitUndefined = function(input) {
    var obj = {};
    for(var key in input){
        var val = input[key];
        if (val) {
            obj[key] = val;
        }
    }
    return obj;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/element-interactions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Default CSS selectors to define which elements on the page to track.
 * Extend this list to include additional elements to track. For example:
 * ```
 * autocapturePlugin({
 *    cssSelectorAllowlist: [...DEFAULT_CSS_SELECTOR_ALLOWLIST, ".my-class"],
 * })
 * ```
 */ __turbopack_context__.s([
    "DEFAULT_ACTION_CLICK_ALLOWLIST",
    ()=>DEFAULT_ACTION_CLICK_ALLOWLIST,
    "DEFAULT_CSS_SELECTOR_ALLOWLIST",
    ()=>DEFAULT_CSS_SELECTOR_ALLOWLIST,
    "DEFAULT_DATA_ATTRIBUTE_PREFIX",
    ()=>DEFAULT_DATA_ATTRIBUTE_PREFIX,
    "DEFAULT_EXPOSURE_DURATION",
    ()=>DEFAULT_EXPOSURE_DURATION
]);
var DEFAULT_CSS_SELECTOR_ALLOWLIST = [
    'a',
    'button',
    'input',
    'select',
    'textarea',
    'label',
    'video',
    'audio',
    '[contenteditable="true" i]',
    '[data-amp-default-track]',
    '.amp-default-track'
];
var DEFAULT_DATA_ATTRIBUTE_PREFIX = 'data-amp-track-';
var DEFAULT_ACTION_CLICK_ALLOWLIST = [
    'div',
    'span',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6'
];
var DEFAULT_EXPOSURE_DURATION = 150;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Shared origin constants for Amplitude cross-window communication
__turbopack_context__.s([
    "AMPLITUDE_BACKGROUND_CAPTURE_SCRIPT_URL",
    ()=>AMPLITUDE_BACKGROUND_CAPTURE_SCRIPT_URL,
    "AMPLITUDE_ORIGIN",
    ()=>AMPLITUDE_ORIGIN,
    "AMPLITUDE_ORIGINS_MAP",
    ()=>AMPLITUDE_ORIGINS_MAP,
    "AMPLITUDE_ORIGIN_EU",
    ()=>AMPLITUDE_ORIGIN_EU,
    "AMPLITUDE_ORIGIN_STAGING",
    ()=>AMPLITUDE_ORIGIN_STAGING
]);
var AMPLITUDE_ORIGIN = 'https://app.amplitude.com';
var AMPLITUDE_ORIGIN_EU = 'https://app.eu.amplitude.com';
var AMPLITUDE_ORIGIN_STAGING = 'https://apps.stag2.amplitude.com';
var AMPLITUDE_ORIGINS_MAP = {
    US: AMPLITUDE_ORIGIN,
    EU: AMPLITUDE_ORIGIN_EU,
    STAGING: AMPLITUDE_ORIGIN_STAGING
};
var AMPLITUDE_BACKGROUND_CAPTURE_SCRIPT_URL = 'https://cdn.amplitude.com/libs/background-capture-1.0.1.js.gz';
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable no-restricted-globals */ /**
 * Dynamically loads an external script by appending a <script> tag to the document head.
 * Deduplicates by checking if a script with the same src already exists.
 */ __turbopack_context__.s([
    "asyncLoadScript",
    ()=>asyncLoadScript,
    "generateUniqueId",
    ()=>generateUniqueId
]);
var asyncLoadScript = function(url) {
    // Dedup: if a script with this src already exists, resolve immediately
    var existing = document.querySelector("script[src=\"".concat(CSS.escape(url), "\"]"));
    if (existing) {
        return Promise.resolve({
            status: true
        });
    }
    return new Promise(function(resolve, reject) {
        var _a;
        try {
            var scriptElement = document.createElement('script');
            scriptElement.type = 'text/javascript';
            scriptElement.async = true;
            scriptElement.src = url;
            scriptElement.addEventListener('load', function() {
                resolve({
                    status: true
                });
            }, {
                once: true
            });
            scriptElement.addEventListener('error', function() {
                reject({
                    status: false,
                    message: "Failed to load the script ".concat(url)
                });
            });
            /* istanbul ignore next */ (_a = document.head) === null || _a === void 0 ? void 0 : _a.appendChild(scriptElement);
        } catch (error) {
            /* istanbul ignore next */ reject(error);
        }
    });
};
function generateUniqueId() {
    return "".concat(Date.now(), "-").concat(Math.random().toString(36).substr(2, 9));
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/base-window-messenger.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getOrCreateWindowMessenger",
    ()=>getOrCreateWindowMessenger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/utils.js [app-client] (ecmascript)");
var _a;
;
;
;
;
/**
 * Brand key used to identify BaseWindowMessenger instances across bundle boundaries.
 */ var MESSENGER_BRAND = '__AMPLITUDE_MESSENGER_INSTANCE__';
/** Global scope key where the singleton messenger is stored. */ var MESSENGER_GLOBAL_KEY = '__AMPLITUDE_MESSENGER__';
/**
 * BaseWindowMessenger provides generic cross-window communication via postMessage.
 * Singleton access via getOrCreateWindowMessenger() to prevent duplicate instances
 */ var BaseWindowMessenger = function() {
    function BaseWindowMessenger(_b) {
        var _c = _b === void 0 ? {} : _b, _d = _c.origin, origin = _d === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_ORIGIN"] : _d;
        /** Brand property for cross-bundle instanceof checks. */ this[_a] = true;
        this.isSetup = false;
        this.messageHandler = null;
        this.requestCallbacks = {};
        this.actionHandlers = new Map();
        /**
         * Messages received for actions that had no registered handler yet.
         * Drained automatically when the corresponding handler is registered via
         * registerActionHandler(), solving startup race conditions between
         * independently-initialized plugins.
         */ this.pendingMessages = new Map();
        /**
         * Tracks in-flight and completed script loads by URL.
         * Using a map, this prevents duplicate loads before the first resolves.
         */ this.scriptLoadPromises = new Map();
        this.endpoint = origin;
    }
    /**
     * Send a message to the parent window (window.opener).
     */ BaseWindowMessenger.prototype.notify = function(message) {
        var _b, _c, _d, _e;
        (_c = (_b = this.logger) === null || _b === void 0 ? void 0 : _b.debug) === null || _c === void 0 ? void 0 : _c.call(_b, 'Message sent: ', JSON.stringify(message));
        (_e = (_d = window.opener) === null || _d === void 0 ? void 0 : _d.postMessage) === null || _e === void 0 ? void 0 : _e.call(_d, message, this.endpoint);
    };
    /**
     * Send an async request to the parent window with a unique ID.
     * Returns a Promise that resolves when the parent responds.
     */ BaseWindowMessenger.prototype.sendRequest = function(action, args, options) {
        var _this = this;
        if (options === void 0) {
            options = {
                timeout: 15000
            };
        }
        var id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateUniqueId"])();
        var request = {
            id: id,
            action: action,
            args: args
        };
        var promise = new Promise(function(resolve, reject) {
            _this.requestCallbacks[id] = {
                resolve: resolve,
                reject: reject
            };
            _this.notify(request);
            if (options.timeout > 0) {
                setTimeout(function() {
                    reject(new Error("".concat(action, " timed out (id: ").concat(id, ")")));
                    delete _this.requestCallbacks[id];
                }, options.timeout);
            }
        });
        return promise;
    };
    /**
     * Handle a response to a previous request by resolving its Promise.
     */ BaseWindowMessenger.prototype.handleResponse = function(response) {
        var _b;
        if (!this.requestCallbacks[response.id]) {
            (_b = this.logger) === null || _b === void 0 ? void 0 : _b.warn("No callback found for request id: ".concat(response.id));
            return;
        }
        this.requestCallbacks[response.id].resolve(response.responseData);
        delete this.requestCallbacks[response.id];
    };
    /**
     * Register a handler for a specific action type.
     * Logs a warning if overwriting an existing handler.
     */ BaseWindowMessenger.prototype.registerActionHandler = function(action, handler) {
        var e_1, _b;
        var _c, _d;
        if (this.actionHandlers.has(action)) {
            (_d = (_c = this.logger) === null || _c === void 0 ? void 0 : _c.warn) === null || _d === void 0 ? void 0 : _d.call(_c, "Overwriting existing action handler for: ".concat(action));
        }
        this.actionHandlers.set(action, handler);
        // Replay any messages that arrived before this handler was registered
        var queued = this.pendingMessages.get(action);
        if (queued) {
            this.pendingMessages.delete(action);
            try {
                for(var queued_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(queued), queued_1_1 = queued_1.next(); !queued_1_1.done; queued_1_1 = queued_1.next()){
                    var data = queued_1_1.value;
                    handler(data);
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (queued_1_1 && !queued_1_1.done && (_b = queued_1.return)) _b.call(queued_1);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
        }
    };
    /**
     * Load a script once, deduplicating by URL.
     * Safe against concurrent calls — the second call awaits the first's in-flight Promise
     * rather than triggering a duplicate load.
     */ BaseWindowMessenger.prototype.loadScriptOnce = function(url) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var existing, loadPromise, error_1;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        existing = this.scriptLoadPromises.get(url);
                        if (existing) {
                            return [
                                2 /*return*/ ,
                                existing
                            ];
                        }
                        loadPromise = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asyncLoadScript"])(url).then(function() {
                        // Resolve to void
                        });
                        this.scriptLoadPromises.set(url, loadPromise);
                        _b.label = 1;
                    case 1:
                        _b.trys.push([
                            1,
                            3,
                            ,
                            4
                        ]);
                        return [
                            4 /*yield*/ ,
                            loadPromise
                        ];
                    case 2:
                        _b.sent();
                        return [
                            3 /*break*/ ,
                            4
                        ];
                    case 3:
                        error_1 = _b.sent();
                        // Remove failed loads so they can be retried
                        this.scriptLoadPromises.delete(url);
                        throw error_1;
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    /**
     * Set up the message listener. Idempotent — safe to call multiple times.
     * Subclasses should call super.setup() and then register their own action handlers.
     */ BaseWindowMessenger.prototype.setup = function(_b) {
        var _this = this;
        var _c, _d;
        var _e = _b === void 0 ? {} : _b, logger = _e.logger, endpoint = _e.endpoint;
        if (logger) {
            this.logger = logger;
        }
        // If endpoint is customized, don't override a previously customized endpoint.
        if (endpoint && this.endpoint === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_ORIGIN"]) {
            this.endpoint = endpoint;
        }
        // Only attach the message listener once
        if (this.isSetup) {
            return;
        }
        this.isSetup = true;
        (_d = (_c = this.logger) === null || _c === void 0 ? void 0 : _c.debug) === null || _d === void 0 ? void 0 : _d.call(_c, 'Setting up messenger');
        // Attach Event Listener to listen for messages from the parent window
        this.messageHandler = function(event) {
            var _b, _c, _d, _e, _f;
            (_c = (_b = _this.logger) === null || _b === void 0 ? void 0 : _b.debug) === null || _c === void 0 ? void 0 : _c.call(_b, 'Message received: ', JSON.stringify(event));
            // Only accept messages from the specified origin
            if (_this.endpoint !== event.origin) {
                return;
            }
            var eventData = event.data;
            var action = eventData === null || eventData === void 0 ? void 0 : eventData.action;
            // Ignore messages without action
            if (!action) {
                return;
            }
            // If id exists, handle responses to previous requests
            if ('id' in eventData && eventData.id) {
                (_e = (_d = _this.logger) === null || _d === void 0 ? void 0 : _d.debug) === null || _e === void 0 ? void 0 : _e.call(_d, 'Received Response to previous request: ', JSON.stringify(event));
                _this.handleResponse(eventData);
            } else {
                if (action === 'ping') {
                    _this.notify({
                        action: 'pong'
                    });
                    return;
                }
                // Dispatch to registered action handlers, or buffer for late registration
                var handler = _this.actionHandlers.get(action);
                if (handler) {
                    handler(eventData.data);
                } else {
                    var queue = (_f = _this.pendingMessages.get(action)) !== null && _f !== void 0 ? _f : [];
                    queue.push(eventData.data);
                    _this.pendingMessages.set(action, queue);
                }
            }
        };
        window.addEventListener('message', this.messageHandler);
        this.notify({
            action: 'page-loaded'
        });
    };
    /**
     * Tear down the messenger: remove the message listener, clear all state.
     */ BaseWindowMessenger.prototype.destroy = function() {
        if (this.messageHandler) {
            window.removeEventListener('message', this.messageHandler);
            this.messageHandler = null;
        }
        this.isSetup = false;
        this.actionHandlers.clear();
        this.pendingMessages.clear();
        this.requestCallbacks = {};
        this.scriptLoadPromises.clear();
        // Remove from global scope if this is the singleton
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        if ((globalScope === null || globalScope === void 0 ? void 0 : globalScope[MESSENGER_GLOBAL_KEY]) === this) {
            delete globalScope[MESSENGER_GLOBAL_KEY];
        }
    };
    return BaseWindowMessenger;
}();
_a = MESSENGER_BRAND;
/**
 * Type guard: checks whether a value is a BaseWindowMessenger instance.
 */ function isWindowMessenger(value) {
    return typeof value === 'object' && value !== null && MESSENGER_BRAND in value && value[MESSENGER_BRAND] === true;
}
function getOrCreateWindowMessenger(options) {
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    var existing = globalScope === null || globalScope === void 0 ? void 0 : globalScope[MESSENGER_GLOBAL_KEY];
    if (isWindowMessenger(existing)) {
        return existing;
    }
    var messenger = new BaseWindowMessenger(options);
    if (globalScope) {
        globalScope[MESSENGER_GLOBAL_KEY] = messenger;
    }
    return messenger;
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/background-capture.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "enableBackgroundCapture",
    ()=>enableBackgroundCapture
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/constants.js [app-client] (ecmascript)");
;
/**
 * Brand key set on the messenger instance to track whether background capture
 * has been enabled.
 */ var BG_CAPTURE_BRAND = '__AMPLITUDE_BACKGROUND_CAPTURE__';
function enableBackgroundCapture(messenger, options) {
    var _a;
    // Check the brand on the messenger object itself — works across bundle boundaries
    var branded = messenger;
    if (branded[BG_CAPTURE_BRAND] === true) {
        return;
    }
    branded[BG_CAPTURE_BRAND] = true;
    var scriptUrl = (_a = options === null || options === void 0 ? void 0 : options.scriptUrl) !== null && _a !== void 0 ? _a : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_BACKGROUND_CAPTURE_SCRIPT_URL"];
    var backgroundCaptureInstance = null;
    var onBackgroundCapture = function(type, backgroundCaptureData) {
        var _a, _b;
        if (type === 'background-capture-complete') {
            (_b = (_a = messenger.logger) === null || _a === void 0 ? void 0 : _a.debug) === null || _b === void 0 ? void 0 : _b.call(_a, 'Background capture complete');
            messenger.notify({
                action: 'background-capture-complete',
                data: backgroundCaptureData
            });
        }
    };
    messenger.registerActionHandler('initialize-background-capture', function() {
        var _a, _b;
        (_b = (_a = messenger.logger) === null || _a === void 0 ? void 0 : _a.debug) === null || _b === void 0 ? void 0 : _b.call(_a, 'Initializing background capture (external script)');
        var resolvedUrl = new URL(scriptUrl, messenger.endpoint).toString();
        messenger.loadScriptOnce(resolvedUrl).then(function() {
            var _a, _b, _c;
            (_b = (_a = messenger.logger) === null || _a === void 0 ? void 0 : _a.debug) === null || _b === void 0 ? void 0 : _b.call(_a, 'Background capture script loaded (external)');
            // eslint-disable-next-line
            backgroundCaptureInstance = /* istanbul ignore next -- window is always defined in browser */ (_c = window === null || window === void 0 ? void 0 : window.amplitudeBackgroundCapture) === null || _c === void 0 ? void 0 : _c.call(window, {
                messenger: messenger,
                onBackgroundCapture: onBackgroundCapture
            });
            messenger.notify({
                action: 'background-capture-loaded'
            });
        }).catch(function() {
            var _a;
            (_a = messenger.logger) === null || _a === void 0 ? void 0 : _a.warn('Failed to initialize background capture');
        });
    });
    messenger.registerActionHandler('close-background-capture', function() {
        var _a;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-call
        (_a = backgroundCaptureInstance === null || backgroundCaptureInstance === void 0 ? void 0 : backgroundCaptureInstance.close) === null || _a === void 0 ? void 0 : _a.call(backgroundCaptureInstance);
        backgroundCaptureInstance = null;
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "asyncMap",
    ()=>asyncMap,
    "merge",
    ()=>merge,
    "multicast",
    ()=>multicast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript)");
;
;
;
/**
 * asyncMap operator for Zen Observable
 *
 * Maps each value emitted by the source Observable using an async function,
 * emitting the resolved values in the same order they arrive.
 */ function asyncMap(observable, fn) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](function(observer) {
        observable.subscribe({
            next: function(value) {
                fn(value).then(function(result) {
                    return observer.next(result);
                }).catch(function(error) {
                    return observer.error(error);
                });
            },
            error: function(error) {
                observer.error(error);
            },
            complete: function() {
                observer.complete();
            }
        });
    });
}
/**
 * merge operator for Zen Observable
 *
 * Merges two observables into a single observable, emitting values from both sources in the order they arrive.
 * @param sourceA Observable to merge
 * @param sourceB Observable to merge
 * @returns Unsubscribable cleanup function
 */ function merge(sourceA, sourceB) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](function(observer) {
        var closed = false;
        var subscriptions = new Set();
        var cleanup = function() {
            var e_1, _a;
            closed = true;
            try {
                for(var subscriptions_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(subscriptions), subscriptions_1_1 = subscriptions_1.next(); !subscriptions_1_1.done; subscriptions_1_1 = subscriptions_1.next()){
                    var sub = subscriptions_1_1.value;
                    try {
                        sub.unsubscribe();
                    } catch (_b) {
                    /* do nothing */ }
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (subscriptions_1_1 && !subscriptions_1_1.done && (_a = subscriptions_1.return)) _a.call(subscriptions_1);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            subscriptions.clear();
        };
        var subscribeTo = function(source) {
            var sub = source.subscribe({
                next: function(value) {
                    if (!closed) observer.next(value);
                },
                error: function(err) {
                    if (!closed) {
                        closed = true;
                        observer.error(err);
                        cleanup();
                    }
                },
                complete: function() {
                    subscriptions.delete(sub);
                    if (!closed && subscriptions.size === 0) {
                        observer.complete();
                        cleanup();
                        closed = true;
                    }
                }
            });
            subscriptions.add(sub);
        };
        subscribeTo(sourceA);
        subscribeTo(sourceB);
        return cleanup;
    });
}
// function share() {
function multicast(source) {
    var observers = new Set();
    var subscription = null;
    function cleanup() {
        /* istanbul ignore next */ subscription === null || subscription === void 0 ? void 0 : subscription.unsubscribe();
        subscription = null;
        observers.clear();
    }
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](function(observer) {
        observers.add(observer);
        if (subscription === null) {
            subscription = source.subscribe({
                next: function(value) {
                    var e_2, _a;
                    var _b;
                    try {
                        for(var observers_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(observers), observers_1_1 = observers_1.next(); !observers_1_1.done; observers_1_1 = observers_1.next()){
                            var obs = observers_1_1.value;
                            /* istanbul ignore next */ (_b = obs.next) === null || _b === void 0 ? void 0 : _b.call(obs, value);
                        }
                    } catch (e_2_1) {
                        e_2 = {
                            error: e_2_1
                        };
                    } finally{
                        try {
                            if (observers_1_1 && !observers_1_1.done && (_a = observers_1.return)) _a.call(observers_1);
                        } finally{
                            if (e_2) throw e_2.error;
                        }
                    }
                },
                error: function(err) {
                    var e_3, _a;
                    var _b;
                    try {
                        for(var observers_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(observers), observers_2_1 = observers_2.next(); !observers_2_1.done; observers_2_1 = observers_2.next()){
                            var obs = observers_2_1.value;
                            /* istanbul ignore next */ (_b = obs.error) === null || _b === void 0 ? void 0 : _b.call(obs, err);
                        }
                    } catch (e_3_1) {
                        e_3 = {
                            error: e_3_1
                        };
                    } finally{
                        try {
                            if (observers_2_1 && !observers_2_1.done && (_a = observers_2.return)) _a.call(observers_2);
                        } finally{
                            if (e_3) throw e_3.error;
                        }
                    }
                    cleanup();
                },
                complete: function() {
                    var e_4, _a;
                    var _b;
                    try {
                        for(var observers_3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(observers), observers_3_1 = observers_3.next(); !observers_3_1.done; observers_3_1 = observers_3.next()){
                            var obs = observers_3_1.value;
                            /* istanbul ignore next */ (_b = obs.complete) === null || _b === void 0 ? void 0 : _b.call(obs);
                        }
                    } catch (e_4_1) {
                        e_4 = {
                            error: e_4_1
                        };
                    } finally{
                        try {
                            if (observers_3_1 && !observers_3_1.done && (_a = observers_3.return)) _a.call(observers_3);
                        } finally{
                            if (e_4) throw e_4.error;
                        }
                    }
                    cleanup();
                }
            });
        }
        // Return unsubscribe function for this observer
        return function() {
            observers.delete(observer);
            // If no observers left, unsubscribe from the source
            if (observers.size === 0 && subscription) {
                subscription.unsubscribe();
                subscription = null;
            }
        };
    });
}
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Checks if a given URL matches any pattern in an allowlist of URLs or regex patterns.
 * @param url - The URL to check
 * @param allowlist - Array of allowed URLs (strings) or regex patterns
 * @returns true if the URL matches any pattern in the allowlist, false otherwise
 */ __turbopack_context__.s([
    "getDecodeURI",
    ()=>getDecodeURI,
    "isUrlMatchAllowlist",
    ()=>isUrlMatchAllowlist
]);
var isUrlMatchAllowlist = function(url, allowlist) {
    if (!allowlist || !allowlist.length) {
        return true;
    }
    return allowlist.some(function(allowedUrl) {
        if (typeof allowedUrl === 'string') {
            return url === allowedUrl;
        }
        return url.match(allowedUrl);
    });
};
var getDecodeURI = function(locationStr, loggerProvider) {
    var decodedLocationStr = locationStr;
    try {
        decodedLocationStr = decodeURI(locationStr);
    } catch (e) {
        /* istanbul ignore next */ loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error('Malformed URI sequence: ', e);
    }
    return decodedLocationStr;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/observers/console.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "consoleObserver",
    ()=>consoleObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
/* istanbul ignore next */ var originalConsole = globalScope === null || globalScope === void 0 ? void 0 : globalScope.console;
var handlers = {};
// keeps reference to original console methods
var originalFn = {};
var inConsoleOverride = false;
function overrideConsole(logLevel) {
    /* istanbul ignore if */ if (!originalConsole) {
        return false;
    }
    // should not override if original console property is not a function
    /* eslint-disable-next-line @typescript-eslint/no-unsafe-member-access */ if (typeof originalConsole[logLevel] !== 'function') {
        return false;
    }
    // if console is already overridden, return true
    if (originalFn[logLevel]) {
        return true;
    }
    // override console method
    var handler = function() {
        var args = [];
        for(var _i = 0; _i < arguments.length; _i++){
            args[_i] = arguments[_i];
        }
        try {
            if (handlers[logLevel] && !inConsoleOverride) {
                // add a re-entrancy guard to prevent infinite recursion
                inConsoleOverride = true;
                var callbacks = handlers[logLevel];
                if (callbacks) {
                    callbacks.forEach(function(callback) {
                        try {
                            callback(logLevel, args);
                        } catch (_a) {
                        // do nothing
                        }
                    });
                }
            }
        } catch (_a) {
        // do nothing
        }
        inConsoleOverride = false;
        return originalFn[logLevel].apply(originalConsole, args);
    };
    /* eslint-disable-next-line @typescript-eslint/no-unsafe-member-access */ originalFn[logLevel] = originalConsole[logLevel];
    /* eslint-disable-next-line @typescript-eslint/no-unsafe-member-access */ originalConsole[logLevel] = handler;
    return true;
}
/**
 * Observe a console log method (log, warn, error, etc.)
 * @param level - The console log level to observe
 * @param callback - The callback function to call when the console log level is observed
 */ function addListener(level, callback) {
    var res = overrideConsole(level);
    /* istanbul ignore if */ if (!res) {
        return new Error('Console override failed');
    }
    if (handlers[level]) {
        // using ! is safe because we know the key exists based on condition above
        handlers[level].push(callback);
    } else {
        handlers[level] = [
            callback
        ];
    }
}
/**
 * Disconnect a callback function from a console log method
 * @param callback - The callback function to disconnect
 */ function removeListener(callback) {
    var e_1, _a;
    try {
        for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(Object.values(handlers)), _c = _b.next(); !_c.done; _c = _b.next()){
            var callbacks = _c.value;
            // iterate backwards to avoid index shifting
            for(var i = callbacks.length - 1; i >= 0; i--){
                if (callbacks[i] === callback) {
                    callbacks.splice(i, 1);
                    break;
                }
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
}
// this should only be used for testing
// restoring console can break console overrides
function _restoreConsole() {
    var e_2, _a;
    try {
        for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(Object.entries(originalFn)), _c = _b.next(); !_c.done; _c = _b.next()){
            var _d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_c.value, 2), key = _d[0], originalHandler = _d[1];
            if (originalHandler) {
                /* eslint-disable-next-line @typescript-eslint/no-unsafe-member-access */ originalConsole[key] = originalHandler;
            }
        }
    } catch (e_2_1) {
        e_2 = {
            error: e_2_1
        };
    } finally{
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        } finally{
            if (e_2) throw e_2.error;
        }
    }
    originalFn = {};
    handlers = {};
}
var consoleObserver = {
    addListener: addListener,
    removeListener: removeListener,
    _restoreConsole: _restoreConsole
};
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/frustration-interactions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_DEAD_CLICK_ALLOWLIST",
    ()=>DEFAULT_DEAD_CLICK_ALLOWLIST,
    "DEFAULT_DEAD_CLICK_WINDOW_MS",
    ()=>DEFAULT_DEAD_CLICK_WINDOW_MS,
    "DEFAULT_ERROR_CLICK_ALLOWLIST",
    ()=>DEFAULT_ERROR_CLICK_ALLOWLIST,
    "DEFAULT_RAGE_CLICK_ALLOWLIST",
    ()=>DEFAULT_RAGE_CLICK_ALLOWLIST,
    "DEFAULT_RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD",
    ()=>DEFAULT_RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD,
    "DEFAULT_RAGE_CLICK_THRESHOLD",
    ()=>DEFAULT_RAGE_CLICK_THRESHOLD,
    "DEFAULT_RAGE_CLICK_WINDOW_MS",
    ()=>DEFAULT_RAGE_CLICK_WINDOW_MS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var CLICKABLE_ELEMENT_SELECTORS = [
    'a',
    'button',
    '[role="button"]',
    '[role="link"]',
    '[role="menuitem"]',
    '[role="menuitemcheckbox"]',
    '[role="menuitemradio"]',
    '[role="option"]',
    '[role="tab"]',
    '[role="treeitem"]',
    '[contenteditable="true" i]'
];
var DEFAULT_ERROR_AND_DEAD_CLICK_ALLOWLIST = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([
    'input[type="button"]',
    'input[type="submit"]',
    'input[type="reset"]',
    'input[type="image"]',
    'input[type="file"]'
], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(CLICKABLE_ELEMENT_SELECTORS), false);
var DEFAULT_DEAD_CLICK_ALLOWLIST = DEFAULT_ERROR_AND_DEAD_CLICK_ALLOWLIST;
var DEFAULT_ERROR_CLICK_ALLOWLIST = DEFAULT_ERROR_AND_DEAD_CLICK_ALLOWLIST;
var DEFAULT_RAGE_CLICK_ALLOWLIST = [
    '*'
];
var DEFAULT_DEAD_CLICK_WINDOW_MS = 3000;
var DEFAULT_RAGE_CLICK_WINDOW_MS = 1000;
var DEFAULT_RAGE_CLICK_THRESHOLD = 4;
var DEFAULT_RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD = 50; // pixels
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/json-query.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_pruneJson",
    ()=>_pruneJson,
    "isPathMatch",
    ()=>isPathMatch,
    "pruneJson",
    ()=>pruneJson,
    "tokenizeJsonPath",
    ()=>tokenizeJsonPath
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
function isJsonPrimitive(json) {
    return typeof json === 'string' || typeof json === 'number' || typeof json === 'boolean' || json === null || json === undefined;
}
function pruneJson(json, allowlist, excludelist) {
    if (!json) return;
    // tokenize the allowlist and excludelist
    var allowlistTokens = allowlist.map(tokenizeJsonPath);
    var excludelistTokens = excludelist.map(tokenizeJsonPath);
    _pruneJson({
        json: json,
        allowlist: allowlistTokens,
        excludelist: excludelistTokens,
        ancestors: []
    });
}
function _pruneJson(_a) {
    var e_1, _b;
    var json = _a.json, targetObject = _a.targetObject, allowlist = _a.allowlist, excludelist = _a.excludelist, ancestors = _a.ancestors, parentObject = _a.parentObject, targetKey = _a.targetKey;
    if (!targetObject) {
        targetObject = json;
    }
    var keys = Object.keys(targetObject);
    try {
        for(var keys_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(keys), keys_1_1 = keys_1.next(); !keys_1_1.done; keys_1_1 = keys_1.next()){
            var key = keys_1_1.value;
            var path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(ancestors), false), [
                key
            ], false);
            if (isJsonPrimitive(targetObject[key])) {
                // if the value does not match allowlist or matches exclude list, delete it
                if (!hasPathMatchInList(path, allowlist) || hasPathMatchInList(path, excludelist)) {
                    delete targetObject[key];
                }
            } else {
                _pruneJson({
                    json: json,
                    targetObject: targetObject[key],
                    allowlist: allowlist,
                    excludelist: excludelist,
                    ancestors: path,
                    parentObject: targetObject,
                    targetKey: key
                });
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (keys_1_1 && !keys_1_1.done && (_b = keys_1.return)) _b.call(keys_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    // if this object is empty now, delete the whole object
    if (Object.keys(targetObject).length === 0 && parentObject && targetKey) {
        delete parentObject[targetKey];
    }
}
function tokenizeJsonPath(path) {
    if (path.startsWith('/')) {
        path = path.slice(1);
    }
    return path.split('/').map(function(token) {
        return token.replace(/~0/g, '~').replace(/~1/g, '/');
    });
}
function isPathMatch(path, pathMatcher, i, j) {
    if (i === void 0) {
        i = 0;
    }
    if (j === void 0) {
        j = 0;
    }
    if (j === pathMatcher.length) {
        return i === path.length;
    }
    if (i === path.length) {
        while(j < pathMatcher.length && pathMatcher[j] === '**'){
            j++;
        }
        return j === pathMatcher.length;
    }
    var currentMatcher = pathMatcher[j];
    if (currentMatcher === '**') {
        if (j + 1 === pathMatcher.length) {
            return true;
        }
        for(var k = i; k <= path.length; k++){
            if (isPathMatch(path, pathMatcher, k, j + 1)) {
                return true;
            }
        }
        return false;
    } else if (currentMatcher === '*' || currentMatcher === path[i]) {
        return isPathMatch(path, pathMatcher, i + 1, j + 1);
    } else {
        return false;
    }
}
/**
 * Check if a JSON path matches any of the path matchers in the allow or exclude list.
 *
 * @param path - The JSON path to check.
 * @param allowOrExcludeList - The allow or exclude list to check against.
 * @returns True if the path matches any of the path matchers in the allow or exclude list, false otherwise.
 */ function hasPathMatchInList(path, allowOrExcludeList) {
    return allowOrExcludeList.some(function(l) {
        return isPathMatch(path, l);
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/network-request-event.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAXIMUM_ENTRIES",
    ()=>MAXIMUM_ENTRIES,
    "NetworkRequestEvent",
    ()=>NetworkRequestEvent,
    "PRUNE_STRATEGY",
    ()=>PRUNE_STRATEGY,
    "RequestWrapperFetch",
    ()=>RequestWrapperFetch,
    "RequestWrapperXhr",
    ()=>RequestWrapperXhr,
    "ResponseWrapperFetch",
    ()=>ResponseWrapperFetch,
    "ResponseWrapperXhr",
    ()=>ResponseWrapperXhr,
    "pruneHeaders",
    ()=>pruneHeaders
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$json$2d$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/json-query.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
;
;
;
;
var TEXT_READ_TIMEOUT = 500;
var MAXIMUM_ENTRIES = 100;
/**
 * This class encapsulates the RequestInit (https://developer.mozilla.org/en-US/docs/Web/API/RequestInit)
 * object so that the consumer can only get access to the headers, method and body size.
 *
 * This is to prevent consumers from directly accessing the Request object
 * and mutating it or running costly operations on it.
 *
 * IMPORTANT:
 *    * Do not make changes to this class without careful consideration
 *      of performance implications, memory usage and potential to mutate the customer's
 *      request.
 *   * NEVER .clone() the RequestInit object. This will 2x's the memory overhead of the request
 *   * NEVER: call .arrayBuffer(), text(), json() or any other method on the body that
 *     consumes the body's stream. This will cause the response to be consumed
 *     meaning the body will be empty when the customer tries to access it.
 *     (ie: if the body is an instanceof https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream
 *      never call any of the methods on it)
 */ var RequestWrapperFetch = function() {
    function RequestWrapperFetch(request) {
        this.request = request;
    }
    RequestWrapperFetch.prototype.headers = function(allow) {
        var e_1, _a;
        if (allow === void 0) {
            allow = [];
        }
        var headersUnsafe = this.request.headers;
        // copy the headers into a new object
        var headersSafeCopy = {};
        if (Array.isArray(headersUnsafe)) {
            headersUnsafe.forEach(function(_a) {
                var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), headerName = _b[0], headerValue = _b[1];
                headersSafeCopy[headerName] = headerValue;
            });
        } else if (headersUnsafe instanceof Headers) {
            headersUnsafe.forEach(function(value, key) {
                headersSafeCopy[key] = value;
            });
        } else if (typeof headersUnsafe === 'object' && headersUnsafe !== null) {
            try {
                for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(Object.entries(headersUnsafe)), _c = _b.next(); !_c.done; _c = _b.next()){
                    var _d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_c.value, 2), key = _d[0], value = _d[1];
                    headersSafeCopy[key] = value;
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
        }
        return pruneHeaders(headersSafeCopy, {
            allow: allow
        });
    };
    Object.defineProperty(RequestWrapperFetch.prototype, "bodySize", {
        get: function() {
            if (typeof this._bodySize === 'number') return this._bodySize;
            var global = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
            /* istanbul ignore if */ if (!(global === null || global === void 0 ? void 0 : global.TextEncoder)) {
                return;
            }
            var body = this.request.body;
            this._bodySize = getBodySize(body, MAXIMUM_ENTRIES);
            return this._bodySize;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RequestWrapperFetch.prototype, "method", {
        get: function() {
            return this.request.method;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RequestWrapperFetch.prototype, "body", {
        get: function() {
            if (typeof this.request.body === 'string') {
                return this.request.body;
            }
            return null;
        },
        enumerable: false,
        configurable: true
    });
    RequestWrapperFetch.prototype.json = function(allow, exclude) {
        if (allow === void 0) {
            allow = [];
        }
        if (exclude === void 0) {
            exclude = [];
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var text;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (allow.length === 0) {
                    return [
                        2 /*return*/ ,
                        null
                    ];
                }
                text = this.body;
                return [
                    2 /*return*/ ,
                    safeParseAndPruneBody(text, allow, exclude)
                ];
            });
        });
    };
    return RequestWrapperFetch;
}();
;
var RequestWrapperXhr = function() {
    function RequestWrapperXhr(bodyRaw, requestHeaders) {
        this.bodyRaw = bodyRaw;
        this.requestHeaders = requestHeaders;
    }
    RequestWrapperXhr.prototype.headers = function(allow) {
        if (allow === void 0) {
            allow = [];
        }
        return pruneHeaders(this.requestHeaders, {
            allow: allow
        });
    };
    Object.defineProperty(RequestWrapperXhr.prototype, "bodySize", {
        get: function() {
            return getBodySize(this.bodyRaw, MAXIMUM_ENTRIES);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RequestWrapperXhr.prototype, "body", {
        get: function() {
            if (typeof this.bodyRaw === 'string') {
                return this.bodyRaw;
            }
            return null;
        },
        enumerable: false,
        configurable: true
    });
    RequestWrapperXhr.prototype.json = function(allow, exclude) {
        if (allow === void 0) {
            allow = [];
        }
        if (exclude === void 0) {
            exclude = [];
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var text;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (allow.length === 0) {
                    return [
                        2 /*return*/ ,
                        null
                    ];
                }
                text = this.body;
                return [
                    2 /*return*/ ,
                    safeParseAndPruneBody(text, allow, exclude)
                ];
            });
        });
    };
    return RequestWrapperXhr;
}();
;
function getBodySize(bodyUnsafe, maxEntries) {
    var e_2, _a;
    var bodySize;
    var global = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore next */ var TextEncoder = global === null || global === void 0 ? void 0 : global.TextEncoder;
    /* istanbul ignore next */ if (!TextEncoder) {
        return;
    }
    var bodySafe;
    if (typeof bodyUnsafe === 'string') {
        bodySafe = bodyUnsafe;
        bodySize = new TextEncoder().encode(bodySafe).length;
    } else if (bodyUnsafe instanceof Blob) {
        bodySafe = bodyUnsafe;
        bodySize = bodySafe.size;
    } else if (bodyUnsafe instanceof URLSearchParams) {
        bodySafe = bodyUnsafe;
        bodySize = new TextEncoder().encode(bodySafe.toString()).length;
    } else if (ArrayBuffer.isView(bodyUnsafe)) {
        bodySafe = bodyUnsafe;
        bodySize = bodySafe.byteLength;
    } else if (bodyUnsafe instanceof ArrayBuffer) {
        bodySafe = bodyUnsafe;
        bodySize = bodySafe.byteLength;
    } else if (bodyUnsafe instanceof FormData) {
        // Estimating only for text parts; not accurate for files
        var formData = bodyUnsafe;
        var total = 0;
        var count = 0;
        try {
            for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(formData.entries()), _c = _b.next(); !_c.done; _c = _b.next()){
                var _d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_c.value, 2), key = _d[0], value = _d[1];
                total += key.length;
                if (typeof value === 'string') {
                    total += new TextEncoder().encode(value).length;
                } else if (value instanceof Blob) {
                    total += value.size;
                } else {
                    // encountered an unknown type
                    // we can't estimate the size of this entry
                    return;
                }
                // terminate if we reach the maximum number of entries
                // to avoid performance issues in case of very large FormData
                if (++count >= maxEntries) {
                    return;
                }
            }
        } catch (e_2_1) {
            e_2 = {
                error: e_2_1
            };
        } finally{
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally{
                if (e_2) throw e_2.error;
            }
        }
        bodySize = total;
    } else if (bodyUnsafe instanceof ReadableStream) {
        // If bodyUnsafe is an instanceof ReadableStream, we can't determine the size,
        // without consuming it, so we return undefined.
        // Never ever consume ReadableStream! DO NOT DO IT!!!
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        bodySafe = bodyUnsafe;
        return;
    }
    return bodySize;
}
/**
 * This class encapsulates the Fetch API Response object
 * (https://developer.mozilla.org/en-US/docs/Web/API/Response) so that the consumer can
 * only get access to the headers and body size.
 *
 * This is to prevent consumers from directly accessing the Response object
 * and mutating it or running costly operations on it.
 *
 * IMPORTANT:
 *   * Do not make changes to this class without careful consideration
 *     of performance implications, memory usage and potential to mutate the customer's
 *     response.
 *   * Do not .clone() the Response object unless you need to access the body.
 *     Cloning will 2x the memory overhead of the response.
 *   * NEVER consume the body's stream. This will cause the response to be consumed
 *     meaning the body will be empty when the customer tries to access it.
 *     (ie: if the body is an instanceof https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream
 *      never call any of the methods on it)
 */ var ResponseWrapperFetch = function() {
    function ResponseWrapperFetch(response) {
        this.response = response;
    }
    ResponseWrapperFetch.prototype.headers = function(allow) {
        var _a;
        if (allow === void 0) {
            allow = [];
        }
        if (this.response.headers instanceof Headers) {
            var headersSafe = this.response.headers;
            var headersOut_1 = {};
            /* istanbul ignore next */ (_a = headersSafe === null || headersSafe === void 0 ? void 0 : headersSafe.forEach) === null || _a === void 0 ? void 0 : _a.call(headersSafe, function(value, key) {
                headersOut_1[key] = value;
            });
            return pruneHeaders(headersOut_1, {
                allow: allow
            });
        }
        return;
    };
    Object.defineProperty(ResponseWrapperFetch.prototype, "bodySize", {
        get: function() {
            var _a, _b;
            if (this._bodySize !== undefined) return this._bodySize;
            /* istanbul ignore next */ var contentLength = (_b = (_a = this.response.headers) === null || _a === void 0 ? void 0 : _a.get) === null || _b === void 0 ? void 0 : _b.call(_a, 'content-length');
            var bodySize = contentLength ? parseInt(contentLength, 10) : undefined;
            this._bodySize = bodySize;
            return bodySize;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ResponseWrapperFetch.prototype, "status", {
        get: function() {
            return this.response.status;
        },
        enumerable: false,
        configurable: true
    });
    ResponseWrapperFetch.prototype.text = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var textPromise, timer, text, error_1;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        // !!!IMPORTANT: we clone the response to avoid mutating the original response
                        // never call .text(), .json(), etc.. on the original response always clone it first
                        if (!this.clonedResponse) {
                            this.clonedResponse = this.response.clone();
                        }
                        _a.label = 1;
                    case 1:
                        _a.trys.push([
                            1,
                            3,
                            ,
                            4
                        ]);
                        textPromise = this.clonedResponse.text();
                        timer = new Promise(function(resolve) {
                            return setTimeout(/* istanbul ignore next */ function() {
                                return resolve(null);
                            }, TEXT_READ_TIMEOUT);
                        });
                        return [
                            4 /*yield*/ ,
                            Promise.race([
                                textPromise,
                                timer
                            ])
                        ];
                    case 2:
                        text = _a.sent();
                        return [
                            2 /*return*/ ,
                            text
                        ];
                    case 3:
                        error_1 = _a.sent();
                        return [
                            2 /*return*/ ,
                            null
                        ];
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    ResponseWrapperFetch.prototype.json = function(allow, exclude) {
        if (allow === void 0) {
            allow = [];
        }
        if (exclude === void 0) {
            exclude = [];
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var text;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        if (allow.length === 0) {
                            return [
                                2 /*return*/ ,
                                null
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.text()
                        ];
                    case 1:
                        text = _a.sent();
                        return [
                            2 /*return*/ ,
                            safeParseAndPruneBody(text, allow, exclude)
                        ];
                }
            });
        });
    };
    return ResponseWrapperFetch;
}();
;
var ResponseWrapperXhr = function() {
    function ResponseWrapperXhr(statusCode, headersString, size, getJson) {
        this.statusCode = statusCode;
        this.headersString = headersString;
        this.size = size;
        this.getJson = getJson;
    }
    Object.defineProperty(ResponseWrapperXhr.prototype, "bodySize", {
        get: function() {
            return this.size;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ResponseWrapperXhr.prototype, "status", {
        get: function() {
            return this.statusCode;
        },
        enumerable: false,
        configurable: true
    });
    ResponseWrapperXhr.prototype.headers = function(allow) {
        var e_3, _a;
        if (allow === void 0) {
            allow = [];
        }
        if (!this.headersString) {
            return {};
        }
        var headers = {};
        var headerLines = this.headersString.split('\r\n');
        try {
            for(var headerLines_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(headerLines), headerLines_1_1 = headerLines_1.next(); !headerLines_1_1.done; headerLines_1_1 = headerLines_1.next()){
                var line = headerLines_1_1.value;
                var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(line.split(': '), 2), key = _b[0], value = _b[1];
                if (key && value) {
                    headers[key] = value;
                }
            }
        } catch (e_3_1) {
            e_3 = {
                error: e_3_1
            };
        } finally{
            try {
                if (headerLines_1_1 && !headerLines_1_1.done && (_a = headerLines_1.return)) _a.call(headerLines_1);
            } finally{
                if (e_3) throw e_3.error;
            }
        }
        return pruneHeaders(headers, {
            allow: allow
        });
    };
    ResponseWrapperXhr.prototype.json = function(allow, exclude) {
        if (allow === void 0) {
            allow = [];
        }
        if (exclude === void 0) {
            exclude = [];
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var jsonBody;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (allow.length === 0) {
                    return [
                        2 /*return*/ ,
                        null
                    ];
                }
                jsonBody = this.getJson();
                if (jsonBody) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$json$2d$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pruneJson"])(jsonBody, allow, exclude);
                    return [
                        2 /*return*/ ,
                        jsonBody
                    ];
                }
                return [
                    2 /*return*/ ,
                    null
                ];
            });
        });
    };
    return ResponseWrapperXhr;
}();
;
function safeParseAndPruneBody(text, allow, exclude) {
    if (!text) return null;
    try {
        var json = JSON.parse(text);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$json$2d$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pruneJson"])(json, allow, exclude);
        return json;
    } catch (error) {
        return null;
    }
}
var PRUNE_STRATEGY;
(function(PRUNE_STRATEGY) {
    PRUNE_STRATEGY["REDACT"] = "redact";
    PRUNE_STRATEGY["REMOVE"] = "remove";
})(PRUNE_STRATEGY || (PRUNE_STRATEGY = {}));
var REDACTED_VALUE = '[REDACTED]';
var pruneHeaders = function(headers, options) {
    var e_4, _a;
    var _b = options.allow, allow = _b === void 0 ? [] : _b, _c = options.strategy, strategy = _c === void 0 ? PRUNE_STRATEGY.REMOVE : _c;
    var exclude = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORBIDDEN_HEADERS"]), false);
    var headersPruned = {};
    var _loop_1 = function(key) {
        var lowerKey = key.toLowerCase();
        if (exclude.find(function(e) {
            return e.toLowerCase() === lowerKey;
        })) {
            if (strategy === PRUNE_STRATEGY.REDACT) {
                headersPruned[key] = REDACTED_VALUE;
            }
        } else if (!allow.find(function(i) {
            return i.toLowerCase() === lowerKey;
        })) {
            if (strategy === PRUNE_STRATEGY.REDACT) {
                headersPruned[key] = REDACTED_VALUE;
            }
        } else {
            headersPruned[key] = headers[key];
        }
    };
    try {
        for(var _d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(Object.keys(headers)), _e = _d.next(); !_e.done; _e = _d.next()){
            var key = _e.value;
            _loop_1(key);
        }
    } catch (e_4_1) {
        e_4 = {
            error: e_4_1
        };
    } finally{
        try {
            if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
        } finally{
            if (e_4) throw e_4.error;
        }
    }
    return headersPruned;
};
var NetworkRequestEvent = function() {
    function NetworkRequestEvent(type, method, timestamp, startTime, url, requestWrapper, status, duration, responseWrapper, error, endTime) {
        if (status === void 0) {
            status = 0;
        }
        this.type = type;
        this.method = method;
        this.timestamp = timestamp;
        this.startTime = startTime;
        this.url = url;
        this.requestWrapper = requestWrapper;
        this.status = status;
        this.duration = duration;
        this.responseWrapper = responseWrapper;
        this.error = error;
        this.endTime = endTime;
    }
    NetworkRequestEvent.prototype.toSerializable = function() {
        var _a, _b, _c, _d;
        var serialized = {
            type: this.type,
            method: this.method,
            url: this.url,
            timestamp: this.timestamp,
            status: this.status,
            duration: this.duration,
            error: this.error,
            startTime: this.startTime,
            endTime: this.endTime,
            requestHeaders: (_a = this.requestWrapper) === null || _a === void 0 ? void 0 : _a.headers((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAFE_HEADERS"]), false)),
            requestBodySize: (_b = this.requestWrapper) === null || _b === void 0 ? void 0 : _b.bodySize,
            responseHeaders: (_c = this.responseWrapper) === null || _c === void 0 ? void 0 : _c.headers((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAFE_HEADERS"]), false)),
            responseBodySize: (_d = this.responseWrapper) === null || _d === void 0 ? void 0 : _d.bodySize
        };
        return Object.fromEntries(Object.entries(serialized).filter(function(_a) {
            var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), _ = _b[0], v = _b[1];
            return v !== undefined;
        }));
    };
    return NetworkRequestEvent;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/observers/network.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NetworkEventCallback",
    ()=>NetworkEventCallback,
    "NetworkObserver",
    ()=>NetworkObserver,
    "networkObserver",
    ()=>networkObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$network$2d$request$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/network-request-event.js [app-client] (ecmascript)");
;
;
;
;
/**
 * Typeguard function checks if an input is a Request object.
 */ function isRequest(requestInfo) {
    return typeof requestInfo === 'object' && requestInfo !== null && 'url' in requestInfo && 'method' in requestInfo;
}
var NetworkEventCallback = function() {
    function NetworkEventCallback(callback, id) {
        if (id === void 0) {
            id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
        }
        this.callback = callback;
        this.id = id;
    }
    return NetworkEventCallback;
}();
;
function safeInvoke(fn) {
    try {
        fn();
    } catch (err) {
    // swallow the error
    }
}
var NetworkObserver = function() {
    function NetworkObserver(logger) {
        this.eventCallbacks = new Map();
        this.isObserving = false;
        this.logger = logger;
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        if (!NetworkObserver.isSupported()) {
            /* istanbul ignore next */ return;
        }
        this.globalScope = globalScope;
    }
    NetworkObserver.isSupported = function() {
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        return !!globalScope && !!globalScope.fetch;
    };
    NetworkObserver.prototype.subscribe = function(eventCallback, logger) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        if (!this.logger) {
            this.logger = logger;
        }
        this.eventCallbacks.set(eventCallback.id, eventCallback);
        if (!this.isObserving) {
            /* istanbul ignore next */ // eslint-disable-next-line @typescript-eslint/unbound-method
            var originalXhrOpen = (_c = (_b = (_a = this.globalScope) === null || _a === void 0 ? void 0 : _a.XMLHttpRequest) === null || _b === void 0 ? void 0 : _b.prototype) === null || _c === void 0 ? void 0 : _c.open;
            /* istanbul ignore next */ // eslint-disable-next-line @typescript-eslint/unbound-method
            var originalXhrSend = (_f = (_e = (_d = this.globalScope) === null || _d === void 0 ? void 0 : _d.XMLHttpRequest) === null || _e === void 0 ? void 0 : _e.prototype) === null || _f === void 0 ? void 0 : _f.send;
            /* istanbul ignore next */ // eslint-disable-next-line @typescript-eslint/unbound-method
            var originalXhrSetRequestHeader = (_j = (_h = (_g = this.globalScope) === null || _g === void 0 ? void 0 : _g.XMLHttpRequest) === null || _h === void 0 ? void 0 : _h.prototype) === null || _j === void 0 ? void 0 : _j.setRequestHeader;
            if (originalXhrOpen && originalXhrSend && originalXhrSetRequestHeader) {
                this.observeXhr(originalXhrOpen, originalXhrSend, originalXhrSetRequestHeader);
            }
            /* istanbul ignore next */ var originalFetch = (_k = this.globalScope) === null || _k === void 0 ? void 0 : _k.fetch;
            /* istanbul ignore next */ if (originalFetch) {
                this.observeFetch(originalFetch);
            }
            /* istanbul ignore next */ this.isObserving = true;
        }
    };
    NetworkObserver.prototype.unsubscribe = function(eventCallback) {
        this.eventCallbacks.delete(eventCallback.id);
    };
    NetworkObserver.prototype.triggerEventCallbacks = function(event) {
        var _this = this;
        this.eventCallbacks.forEach(function(callback) {
            try {
                callback.callback(event);
            } catch (err) {
                // if the callback throws an error, we should catch it
                // to avoid breaking the fetch promise chain
                safeInvoke(function() {
                    var _a;
                    /* istanbul ignore next */ (_a = _this.logger) === null || _a === void 0 ? void 0 : _a.debug('an unexpected error occurred while triggering event callbacks', err);
                });
            }
        });
    };
    NetworkObserver.prototype.handleNetworkRequestEvent = function(requestType, requestInfo, requestWrapper, responseWrapper, typedError, startTime, durationStart) {
        var _a;
        /* istanbul ignore next */ if (startTime === undefined || durationStart === undefined) {
            // if we reach this point, it means that the performance API is not supported
            // so we can't construct a NetworkRequestEvent
            return;
        }
        // parse the URL and Method
        var url;
        var method = 'GET';
        if (isRequest(requestInfo)) {
            url = requestInfo['url'];
            method = requestInfo['method'];
        } else {
            url = (_a = requestInfo === null || requestInfo === void 0 ? void 0 : requestInfo.toString) === null || _a === void 0 ? void 0 : _a.call(requestInfo);
        }
        // strip basic auth from the URL
        if (url) {
            try {
                var parsedUrl = new URL(url);
                // reconstruct the URL without the basic auth
                url = "".concat(parsedUrl.protocol, "//").concat(parsedUrl.host).concat(parsedUrl.pathname).concat(parsedUrl.search).concat(parsedUrl.hash);
            // eslint-disable-next-line no-empty
            } catch (err) {}
        }
        method = (requestWrapper === null || requestWrapper === void 0 ? void 0 : requestWrapper.method) || method;
        var status, error;
        if (responseWrapper) {
            status = responseWrapper.status;
        }
        if (typedError) {
            error = {
                name: typedError.name || 'UnknownError',
                message: typedError.message || 'An unknown error occurred'
            };
            status = 0;
        }
        var duration = Math.floor(performance.now() - durationStart);
        var endTime = Math.floor(startTime + duration);
        var requestEvent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$network$2d$request$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NetworkRequestEvent"](requestType, method, startTime, startTime, url, requestWrapper, status, duration, responseWrapper, error, endTime);
        this.triggerEventCallbacks(requestEvent);
    };
    NetworkObserver.prototype.getTimestamps = function() {
        var _a, _b;
        /* istanbul ignore next */ return {
            startTime: (_a = Date.now) === null || _a === void 0 ? void 0 : _a.call(Date),
            durationStart: (_b = performance === null || performance === void 0 ? void 0 : performance.now) === null || _b === void 0 ? void 0 : _b.call(performance)
        };
    };
    NetworkObserver.prototype.observeFetch = function(originalFetch) {
        var _this = this;
        /* istanbul ignore next */ if (!this.globalScope || !originalFetch) {
            return;
        }
        /**
         * IMPORTANT: This overrides window.fetch in browsers.
         * You probably never need to make changes to this function.
         * If you do, please be careful to preserve the original functionality of fetch
         * and make sure another developer who is an expert reviews this change throughly
         */ this.globalScope.fetch = function(requestInfo, requestInit) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
                var timestamps, originalResponse, originalError, err_1;
                var _this = this;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                    switch(_a.label){
                        case 0:
                            try {
                                timestamps = this.getTimestamps();
                            } catch (error) {
                                /* istanbul ignore next */ safeInvoke(function() {
                                    var _a;
                                    return (_a = _this.logger) === null || _a === void 0 ? void 0 : _a.debug('an unexpected error occurred while retrieving timestamps', error);
                                });
                            }
                            _a.label = 1;
                        case 1:
                            _a.trys.push([
                                1,
                                3,
                                ,
                                4
                            ]);
                            return [
                                4 /*yield*/ ,
                                originalFetch(requestInfo, requestInit)
                            ];
                        case 2:
                            originalResponse = _a.sent();
                            return [
                                3 /*break*/ ,
                                4
                            ];
                        case 3:
                            err_1 = _a.sent();
                            // Capture error information
                            originalError = err_1;
                            return [
                                3 /*break*/ ,
                                4
                            ];
                        case 4:
                            // 3. call the handler after the fetch call is done
                            try {
                                this.handleNetworkRequestEvent('fetch', requestInfo, requestInit ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$network$2d$request$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestWrapperFetch"](requestInit) : undefined, originalResponse ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$network$2d$request$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponseWrapperFetch"](originalResponse) : undefined, originalError, /* istanbul ignore next */ timestamps === null || timestamps === void 0 ? void 0 : timestamps.startTime, /* istanbul ignore next */ timestamps === null || timestamps === void 0 ? void 0 : timestamps.durationStart);
                            } catch (err) {
                                // this catch shouldn't be reachable, but keep it here for safety
                                // because we're overriding the fetch function and better to be safe than sorry
                                /* istanbul ignore next */ safeInvoke(function() {
                                    var _a;
                                    return (_a = _this.logger) === null || _a === void 0 ? void 0 : _a.debug('an unexpected error occurred while handling fetch', err);
                                });
                            }
                            // 4. return the original response or throw the original error
                            if (originalResponse) {
                                // if the response is not undefined, return it
                                return [
                                    2 /*return*/ ,
                                    originalResponse
                                ];
                            } else {
                                throw originalError;
                            }
                            return [
                                2 /*return*/ 
                            ];
                    }
                });
            });
        };
    };
    /**
     * Creates a function that parses the response of an XMLHttpRequest as JSON.
     *
     * Returns function instead of JSON object to avoid unnecessary parsing if the
     * body is not being captured.
     *
     * @param xhrSafe - The XMLHttpRequest object.
     * @param context - The NetworkObserver instance.
     * @returns A function that parses the response of an XMLHttpRequest as JSON.
     */ NetworkObserver.createXhrJsonParser = function(xhrUnsafe, context) {
        return function() {
            var _a;
            try {
                if (xhrUnsafe.responseType === 'json') {
                    // if response is a JS object, clone it so that subscribers can't mutate it
                    if ((_a = context.globalScope) === null || _a === void 0 ? void 0 : _a.structuredClone) {
                        /* eslint-disable-next-line @typescript-eslint/no-unsafe-return */ return context.globalScope.structuredClone(xhrUnsafe.response);
                    }
                } else if ([
                    'text',
                    ''
                ].includes(xhrUnsafe.responseType)) {
                    // if response is a string, parse it as JSON
                    /* eslint-disable-next-line @typescript-eslint/no-unsafe-return */ return JSON.parse(xhrUnsafe.responseText);
                }
            } catch (err) {
                /* istanbul ignore if */ if (err instanceof Error && err.name === 'InvalidStateError') {
                    // https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/responseText#exceptions
                    // if we reach here, it means we don't handle responseType correctly
                    safeInvoke(function() {
                        var _a;
                        return (_a = context.logger) === null || _a === void 0 ? void 0 : _a.debug("unexpected error when retrieving responseText. responseType='".concat(xhrUnsafe.responseType, "'"));
                    });
                }
                // the other possible error is Json Parse error which we fail silently
                return null;
            }
            return null;
        };
    };
    NetworkObserver.prototype.observeXhr = function(originalXhrOpen, originalXhrSend, originalXhrSetRequestHeader) {
        /* istanbul ignore next */ if (!this.globalScope || !originalXhrOpen || !originalXhrSend) {
            return;
        }
        var xhrProto = this.globalScope.XMLHttpRequest.prototype;
        var networkObserverContext = this;
        /**
         * IMPORTANT: This overrides window.XMLHttpRequest.prototype.open
         * You probably never need to make changes to this function.
         * If you do, please be careful to preserve the original functionality of xhr.open
         * and make sure another developer who is an expert reviews this change throughly
         */ xhrProto.open = function() {
            var _a;
            var args = [];
            for(var _i = 0; _i < arguments.length; _i++){
                args[_i] = arguments[_i];
            }
            var xhrSafe = this;
            var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(args, 2), method = _b[0], url = _b[1];
            try {
                /* istanbul ignore next */ xhrSafe.$$AmplitudeAnalyticsEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
                    method: method,
                    url: (_a = url === null || url === void 0 ? void 0 : url.toString) === null || _a === void 0 ? void 0 : _a.call(url),
                    headers: {}
                }, networkObserverContext.getTimestamps());
            } catch (err) {
                /* istanbul ignore next */ safeInvoke(function() {
                    var _a;
                    return (_a = networkObserverContext.logger) === null || _a === void 0 ? void 0 : _a.debug('an unexpected error occurred while calling xhr open', err);
                });
            }
            // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
            return originalXhrOpen.apply(xhrSafe, args);
        };
        /**
         * IMPORTANT: This overrides window.XMLHttpRequest.prototype.send
         * You probably never need to make changes to this function.
         * If you do, please be careful to preserve the original functionality of xhr.send
         * and make sure another developer who is an expert reviews this change throughly
         */ // allow "any" type for args to reflect how it's used in the browser
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-argument */ xhrProto.send = function() {
            var args = [];
            for(var _i = 0; _i < arguments.length; _i++){
                args[_i] = arguments[_i];
            }
            // eslint-disable-next-line @typescript-eslint/no-this-alias
            var xhrUnsafe = this;
            var xhrSafe = xhrUnsafe;
            var getJson = NetworkObserver.createXhrJsonParser(xhrUnsafe, networkObserverContext);
            var body = args[0];
            var requestEvent = xhrSafe.$$AmplitudeAnalyticsEvent;
            // if xhrSafe.$$AmplitudeAnalyticsEvent is not set, it means that
            // the xhr.open method was called before we monkey-patched XHR and
            // the event is missed
            if (xhrSafe.$$AmplitudeAnalyticsEvent) {
                xhrSafe.addEventListener('loadend', function() {
                    try {
                        var responseHeaders = xhrSafe.getAllResponseHeaders();
                        var responseBodySize = xhrSafe.getResponseHeader('content-length');
                        var responseWrapper = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$network$2d$request$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponseWrapperXhr"](xhrSafe.status, responseHeaders, /* istanbul ignore next */ responseBodySize ? parseInt(responseBodySize, 10) : undefined, getJson);
                        var requestHeaders = xhrSafe.$$AmplitudeAnalyticsEvent.headers;
                        var requestWrapper = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$network$2d$request$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RequestWrapperXhr"](body, requestHeaders);
                        requestEvent.status = xhrSafe.status;
                        networkObserverContext.handleNetworkRequestEvent('xhr', {
                            url: requestEvent.url,
                            method: requestEvent.method
                        }, requestWrapper, responseWrapper, undefined, requestEvent.startTime, requestEvent.durationStart);
                    } catch (err) {
                        /* istanbul ignore next */ safeInvoke(function() {
                            var _a;
                            return (_a = networkObserverContext.logger) === null || _a === void 0 ? void 0 : _a.debug('an unexpected error occurred while handling xhr send', err);
                        });
                    }
                });
            }
            /* eslint-disable-next-line @typescript-eslint/no-unsafe-argument */ return originalXhrSend.apply(xhrSafe, args);
        };
        /**
         * IMPORTANT: This overrides window.XMLHttpRequest.prototype.setRequestHeader
         * You probably never need to make changes to this function.
         * If you do, please be careful to preserve the original functionality of xhr.setRequestHeader
         * and make sure another developer who is an expert reviews this change throughly
         */ // allow "any" type for args to reflect how it's used in the browser
        /* eslint-disable-next-line @typescript-eslint/no-unsafe-argument */ xhrProto.setRequestHeader = function(headerName, headerValue) {
            var xhrSafe = this;
            try {
                var analyticsEvent = xhrSafe.$$AmplitudeAnalyticsEvent;
                if (analyticsEvent) {
                    /* eslint-disable-next-line @typescript-eslint/no-unsafe-assignment */ analyticsEvent.headers[headerName] = headerValue;
                }
            } catch (err) {
                /* istanbul ignore next */ safeInvoke(function() {
                    var _a;
                    return (_a = networkObserverContext.logger) === null || _a === void 0 ? void 0 : _a.debug('an unexpected error occurred while calling xhr setRequestHeader', err);
                });
            }
            /* eslint-disable-next-line @typescript-eslint/no-unsafe-argument */ originalXhrSetRequestHeader.apply(xhrSafe, [
                headerName,
                headerValue
            ]);
        };
    };
    return NetworkObserver;
}();
;
var networkObserver = new NetworkObserver();
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/helpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStorageKey",
    ()=>getStorageKey
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
;
var getStorageKey = function(apiKey, postKey, limit) {
    if (postKey === void 0) {
        postKey = '';
    }
    if (limit === void 0) {
        limit = 10;
    }
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_PREFIX"],
        postKey,
        apiKey.substring(0, limit)
    ].filter(Boolean).join('_');
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/server-zone.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @deprecated use ServerZoneType instead
 */ __turbopack_context__.s([
    "ServerZone",
    ()=>ServerZone
]);
var ServerZone;
(function(ServerZone) {
    ServerZone["US"] = "US";
    ServerZone["EU"] = "EU";
    /**
     * Add for session-replay-browser migration from analytics-type v1.x.
     */ ServerZone["STAGING"] = "STAGING";
})(ServerZone || (ServerZone = {}));
}),
]);

//# sourceMappingURL=0b3e_%40amplitude_analytics-core_lib_esm_150er9h._.js.map