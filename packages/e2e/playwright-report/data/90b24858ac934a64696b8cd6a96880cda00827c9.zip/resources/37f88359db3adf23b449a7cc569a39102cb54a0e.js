(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/version.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VERSION",
    ()=>VERSION
]);
var VERSION = '1.27.2';
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AMPLITUDE_ELEMENT_CHANGED_EVENT",
    ()=>AMPLITUDE_ELEMENT_CHANGED_EVENT,
    "AMPLITUDE_ELEMENT_CLICKED_EVENT",
    ()=>AMPLITUDE_ELEMENT_CLICKED_EVENT,
    "AMPLITUDE_ELEMENT_DEAD_CLICKED_EVENT",
    ()=>AMPLITUDE_ELEMENT_DEAD_CLICKED_EVENT,
    "AMPLITUDE_ELEMENT_ERROR_CLICKED_EVENT",
    ()=>AMPLITUDE_ELEMENT_ERROR_CLICKED_EVENT,
    "AMPLITUDE_ELEMENT_RAGE_CLICKED_EVENT",
    ()=>AMPLITUDE_ELEMENT_RAGE_CLICKED_EVENT,
    "AMPLITUDE_EVENT_PROP_ELEMENT_ARIA_LABEL",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_ARIA_LABEL,
    "AMPLITUDE_EVENT_PROP_ELEMENT_ATTRIBUTES",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_ATTRIBUTES,
    "AMPLITUDE_EVENT_PROP_ELEMENT_CLASS",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_CLASS,
    "AMPLITUDE_EVENT_PROP_ELEMENT_HIERARCHY",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_HIERARCHY,
    "AMPLITUDE_EVENT_PROP_ELEMENT_HREF",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_HREF,
    "AMPLITUDE_EVENT_PROP_ELEMENT_ID",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_ID,
    "AMPLITUDE_EVENT_PROP_ELEMENT_PARENT_LABEL",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_PARENT_LABEL,
    "AMPLITUDE_EVENT_PROP_ELEMENT_PATH",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_PATH,
    "AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_LEFT",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_LEFT,
    "AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_TOP",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_TOP,
    "AMPLITUDE_EVENT_PROP_ELEMENT_TAG",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_TAG,
    "AMPLITUDE_EVENT_PROP_ELEMENT_TEXT",
    ()=>AMPLITUDE_EVENT_PROP_ELEMENT_TEXT,
    "AMPLITUDE_EVENT_PROP_MAX_PAGE_X",
    ()=>AMPLITUDE_EVENT_PROP_MAX_PAGE_X,
    "AMPLITUDE_EVENT_PROP_MAX_PAGE_Y",
    ()=>AMPLITUDE_EVENT_PROP_MAX_PAGE_Y,
    "AMPLITUDE_EVENT_PROP_PAGE_TITLE",
    ()=>AMPLITUDE_EVENT_PROP_PAGE_TITLE,
    "AMPLITUDE_EVENT_PROP_PAGE_URL",
    ()=>AMPLITUDE_EVENT_PROP_PAGE_URL,
    "AMPLITUDE_EVENT_PROP_PAGE_VIEW_ID",
    ()=>AMPLITUDE_EVENT_PROP_PAGE_VIEW_ID,
    "AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT",
    ()=>AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT,
    "AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH",
    ()=>AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH,
    "AMPLITUDE_MAIN_THREAD_BLOCK_EVENT",
    ()=>AMPLITUDE_MAIN_THREAD_BLOCK_EVENT,
    "AMPLITUDE_PAGE_SCROLLED_EVENT",
    ()=>AMPLITUDE_PAGE_SCROLLED_EVENT,
    "AMPLITUDE_THRASHED_CURSOR_EVENT",
    ()=>AMPLITUDE_THRASHED_CURSOR_EVENT,
    "AMPLITUDE_VISUAL_TAGGING_HIGHLIGHT_CLASS",
    ()=>AMPLITUDE_VISUAL_TAGGING_HIGHLIGHT_CLASS,
    "AMPLITUDE_VISUAL_TAGGING_SELECTOR_SCRIPT_URL",
    ()=>AMPLITUDE_VISUAL_TAGGING_SELECTOR_SCRIPT_URL,
    "DATA_AMP_MASK_ATTRIBUTES",
    ()=>DATA_AMP_MASK_ATTRIBUTES,
    "FRUSTRATION_PLUGIN_NAME",
    ()=>FRUSTRATION_PLUGIN_NAME,
    "MAX_ATTRIBUTE_LENGTH",
    ()=>MAX_ATTRIBUTE_LENGTH,
    "MAX_ELEMENT_EXPOSED_STR_LENGTH",
    ()=>MAX_ELEMENT_EXPOSED_STR_LENGTH,
    "MAX_MASK_TEXT_PATTERNS",
    ()=>MAX_MASK_TEXT_PATTERNS,
    "PAGE_VIEW_SESSION_STORAGE_KEY",
    ()=>PAGE_VIEW_SESSION_STORAGE_KEY,
    "PERFORMANCE_PLUGIN_NAME",
    ()=>PERFORMANCE_PLUGIN_NAME,
    "PLUGIN_NAME",
    ()=>PLUGIN_NAME
]);
var PLUGIN_NAME = '@amplitude/plugin-autocapture-browser';
var FRUSTRATION_PLUGIN_NAME = '@amplitude/plugin-frustration-browser';
var PERFORMANCE_PLUGIN_NAME = '@amplitude/plugin-performance-browser';
var AMPLITUDE_ELEMENT_CLICKED_EVENT = '[Amplitude] Element Clicked';
var AMPLITUDE_ELEMENT_DEAD_CLICKED_EVENT = '[Amplitude] Dead Click';
var AMPLITUDE_ELEMENT_RAGE_CLICKED_EVENT = '[Amplitude] Rage Click';
var AMPLITUDE_ELEMENT_ERROR_CLICKED_EVENT = '[Amplitude] Error Click';
var AMPLITUDE_ELEMENT_CHANGED_EVENT = '[Amplitude] Element Changed';
var AMPLITUDE_PAGE_SCROLLED_EVENT = '[Amplitude] Page Scrolled';
var AMPLITUDE_THRASHED_CURSOR_EVENT = '[Amplitude] Thrashed Cursor';
var AMPLITUDE_MAIN_THREAD_BLOCK_EVENT = '[Amplitude] Main Thread Block';
var AMPLITUDE_EVENT_PROP_ELEMENT_ID = '[Amplitude] Element ID';
var AMPLITUDE_EVENT_PROP_ELEMENT_CLASS = '[Amplitude] Element Class';
var AMPLITUDE_EVENT_PROP_ELEMENT_TAG = '[Amplitude] Element Tag';
var AMPLITUDE_EVENT_PROP_ELEMENT_TEXT = '[Amplitude] Element Text';
var AMPLITUDE_EVENT_PROP_ELEMENT_HIERARCHY = '[Amplitude] Element Hierarchy';
var AMPLITUDE_EVENT_PROP_ELEMENT_HREF = '[Amplitude] Element Href';
var AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_LEFT = '[Amplitude] Element Position Left';
var AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_TOP = '[Amplitude] Element Position Top';
var AMPLITUDE_EVENT_PROP_ELEMENT_ARIA_LABEL = '[Amplitude] Element Aria Label';
var AMPLITUDE_EVENT_PROP_ELEMENT_ATTRIBUTES = '[Amplitude] Element Attributes';
var AMPLITUDE_EVENT_PROP_ELEMENT_PATH = '[Amplitude] Element Path';
var AMPLITUDE_EVENT_PROP_ELEMENT_PARENT_LABEL = '[Amplitude] Element Parent Label';
var AMPLITUDE_EVENT_PROP_PAGE_URL = '[Amplitude] Page URL';
var AMPLITUDE_EVENT_PROP_PAGE_TITLE = '[Amplitude] Page Title';
var AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT = '[Amplitude] Viewport Height';
var AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH = '[Amplitude] Viewport Width';
var AMPLITUDE_EVENT_PROP_MAX_PAGE_X = '[Amplitude] Max Page X';
var AMPLITUDE_EVENT_PROP_MAX_PAGE_Y = '[Amplitude] Max Page Y';
var AMPLITUDE_EVENT_PROP_PAGE_VIEW_ID = '[Amplitude] Page View ID';
;
var AMPLITUDE_VISUAL_TAGGING_SELECTOR_SCRIPT_URL = 'https://cdn.amplitude.com/libs/visual-tagging-selector-1.0.0-alpha.js.gz';
var AMPLITUDE_VISUAL_TAGGING_HIGHLIGHT_CLASS = 'amp-visual-tagging-selector-highlight';
var DATA_AMP_MASK_ATTRIBUTES = 'data-amp-mask-attributes';
var MAX_MASK_TEXT_PATTERNS = 25;
var MAX_ATTRIBUTE_LENGTH = 128;
var PAGE_VIEW_SESSION_STORAGE_KEY = 'AMP_PAGE_VIEW';
var MAX_ELEMENT_EXPOSED_STR_LENGTH = 18000;
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MouseButton",
    ()=>MouseButton,
    "asyncLoadScript",
    ()=>asyncLoadScript,
    "createShouldTrackEvent",
    ()=>createShouldTrackEvent,
    "extractPrefixedAttributes",
    ()=>extractPrefixedAttributes,
    "filterOutNonTrackableEvents",
    ()=>filterOutNonTrackableEvents,
    "generateUniqueId",
    ()=>generateUniqueId,
    "getClosestElement",
    ()=>getClosestElement,
    "getCurrentPageViewId",
    ()=>getCurrentPageViewId,
    "isElementBasedEvent",
    ()=>isElementBasedEvent,
    "isElementPointerCursor",
    ()=>isElementPointerCursor,
    "isEmpty",
    ()=>isEmpty,
    "isNonSensitiveElement",
    ()=>isNonSensitiveElement,
    "isTextNode",
    ()=>isTextNode,
    "isUrlAllowed",
    ()=>isUrlAllowed,
    "parseAttributesToMask",
    ()=>parseAttributesToMask,
    "querySelectUniqueElements",
    ()=>querySelectUniqueElements,
    "removeEmptyProperties",
    ()=>removeEmptyProperties
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
;
var SENSITIVE_TAGS = [
    'input',
    'select',
    'textarea'
];
var isElementPointerCursor = function(element, actionType) {
    var _a;
    /* istanbul ignore next */ var computedStyle = (_a = window === null || window === void 0 ? void 0 : window.getComputedStyle) === null || _a === void 0 ? void 0 : _a.call(window, element);
    /* istanbul ignore next */ return (computedStyle === null || computedStyle === void 0 ? void 0 : computedStyle.getPropertyValue('cursor')) === 'pointer' && actionType === 'click';
};
var isUrlAllowed = function(autocaptureOptions) {
    var pageUrlAllowlist = autocaptureOptions.pageUrlAllowlist, pageUrlExcludelist = autocaptureOptions.pageUrlExcludelist;
    // check if the URL is in the excludelist
    if (pageUrlExcludelist && pageUrlExcludelist.length > 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUrlMatchAllowlist"])(window.location.href, pageUrlExcludelist)) {
        return false;
    }
    // check if the URL is in the allow list
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUrlMatchAllowlist"])(window.location.href, pageUrlAllowlist)) {
        return false;
    }
    return true;
};
var createShouldTrackEvent = function(autocaptureOptions, allowlist, isAlwaysCaptureCursorPointer) {
    if (isAlwaysCaptureCursorPointer === void 0) {
        isAlwaysCaptureCursorPointer = false;
    }
    return function(actionType, element) {
        var _a, _b;
        var shouldTrackEventResolver = autocaptureOptions.shouldTrackEventResolver;
        /* istanbul ignore next */ var tag = (_b = (_a = element === null || element === void 0 ? void 0 : element.tagName) === null || _a === void 0 ? void 0 : _a.toLowerCase) === null || _b === void 0 ? void 0 : _b.call(_a);
        // window, document, and Text nodes have no tag
        if (!tag) {
            return false;
        }
        if (shouldTrackEventResolver) {
            return shouldTrackEventResolver(actionType, element);
        }
        if (!isUrlAllowed(autocaptureOptions)) {
            return false;
        }
        /* istanbul ignore next */ var elementType = String(element === null || element === void 0 ? void 0 : element.getAttribute('type')) || '';
        if (typeof elementType === 'string') {
            switch(elementType.toLowerCase()){
                case 'hidden':
                    return false;
                case 'password':
                    return false;
            }
        }
        var isCursorPointer = isElementPointerCursor(element, actionType);
        if (isAlwaysCaptureCursorPointer && isCursorPointer) {
            return true;
        }
        /* istanbul ignore if */ if (allowlist) {
            var hasMatchAnyAllowedSelector = allowlist.some(function(selector) {
                var _a;
                return !!((_a = element === null || element === void 0 ? void 0 : element.matches) === null || _a === void 0 ? void 0 : _a.call(element, selector));
            });
            if (!hasMatchAnyAllowedSelector) {
                return false;
            }
        }
        switch(tag){
            case 'input':
            case 'select':
            case 'textarea':
                return actionType === 'change' || actionType === 'click';
            default:
                {
                    /* istanbul ignore next */ /* istanbul ignore next */ if (isCursorPointer) {
                        return true;
                    }
                    return actionType === 'click';
                }
        }
    };
};
var isTextNode = function(node) {
    return !!node && node.nodeType === 3;
};
var isNonSensitiveElement = function(element) {
    var _a, _b, _c;
    /* istanbul ignore next */ var tag = (_b = (_a = element === null || element === void 0 ? void 0 : element.tagName) === null || _a === void 0 ? void 0 : _a.toLowerCase) === null || _b === void 0 ? void 0 : _b.call(_a);
    var isContentEditable = element instanceof HTMLElement ? ((_c = element.getAttribute('contenteditable')) === null || _c === void 0 ? void 0 : _c.toLowerCase()) === 'true' : false;
    return !SENSITIVE_TAGS.includes(tag) && !isContentEditable;
};
var parseAttributesToMask = function(attributeString) {
    return attributeString ? attributeString.split(',').map(function(attr) {
        return attr.trim();
    }).filter(function(attr) {
        return attr.length > 0 && attr !== 'id' && attr !== 'class';
    }) // Prevent 'id' and 'class' from being redacted as they're critical for element identification
     : [];
};
var extractPrefixedAttributes = function(attrs, prefix) {
    return Object.entries(attrs).reduce(function(attributes, _a) {
        var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), attributeName = _b[0], attributeValue = _b[1];
        if (attributeName.startsWith(prefix)) {
            var attributeKey = attributeName.replace(prefix, '');
            if (attributeKey) {
                attributes[attributeKey] = attributeValue || '';
            }
        }
        return attributes;
    }, {});
};
var isEmpty = function(value) {
    return value === undefined || value === null || typeof value === 'object' && Object.keys(value).length === 0 || typeof value === 'string' && value.trim().length === 0;
};
var removeEmptyProperties = function(properties) {
    return Object.keys(properties).reduce(function(filteredProperties, key) {
        var value = properties[key];
        if (!isEmpty(value)) {
            filteredProperties[key] = value;
        }
        return filteredProperties;
    }, {});
};
var getCurrentPageViewId = function() {
    var _a;
    try {
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        /* istanbul ignore next */ var raw = (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.sessionStorage) === null || _a === void 0 ? void 0 : _a.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PAGE_VIEW_SESSION_STORAGE_KEY"]);
        if (!raw) {
            return undefined;
        }
        var parsed = JSON.parse(raw);
        if (typeof parsed.pageViewId === 'string') {
            return parsed.pageViewId;
        }
    } catch (_b) {
    // ignore storage access or JSON errors
    }
    return undefined;
};
var querySelectUniqueElements = function(root, selectors) {
    if (root && 'querySelectorAll' in root && typeof root.querySelectorAll === 'function') {
        var elementSet = selectors.reduce(function(elements, selector) {
            if (selector) {
                var selectedElements = Array.from(root.querySelectorAll(selector));
                selectedElements.forEach(function(element) {
                    elements.add(element);
                });
            }
            return elements;
        }, new Set());
        return Array.from(elementSet);
    }
    return [];
};
var getClosestElement = function(element, selectors) {
    if (!element) {
        return null;
    }
    /* istanbul ignore next */ if (selectors.some(function(selector) {
        var _a;
        return (_a = element === null || element === void 0 ? void 0 : element.matches) === null || _a === void 0 ? void 0 : _a.call(element, selector);
    })) {
        return element;
    }
    /* istanbul ignore next */ return getClosestElement(element === null || element === void 0 ? void 0 : element.parentElement, selectors);
};
var asyncLoadScript = function(url) {
    return new Promise(function(resolve, reject) {
        var _a;
        try {
            var scriptElement = document.createElement('script');
            scriptElement.type = 'text/javascript';
            scriptElement.async = true;
            scriptElement.src = url;
            scriptElement.addEventListener('load', function() {
                resolve({
                    status: true
                });
            }, {
                once: true
            });
            scriptElement.addEventListener('error', function() {
                reject({
                    status: false,
                    message: "Failed to load the script ".concat(url)
                });
            });
            /* istanbul ignore next */ (_a = document.head) === null || _a === void 0 ? void 0 : _a.appendChild(scriptElement);
        } catch (error) {
            /* istanbul ignore next */ reject(error);
        }
    });
};
function generateUniqueId() {
    return "".concat(Date.now(), "-").concat(Math.random().toString(36).substr(2, 9));
}
var filterOutNonTrackableEvents = function(event) {
    // Filter out changeEvent events with no target
    // This could happen when change events are triggered programmatically
    if (event.event.target === null || !event.closestTrackedAncestor) {
        return false;
    }
    return true;
};
function isElementBasedEvent(event) {
    return event.type === 'click' || event.type === 'change';
}
var MouseButton;
(function(MouseButton) {
    MouseButton[MouseButton["LEFT_OR_TOUCH_CONTACT"] = 0] = "LEFT_OR_TOUCH_CONTACT";
    MouseButton[MouseButton["MIDDLE"] = 1] = "MIDDLE";
    MouseButton[MouseButton["RIGHT"] = 2] = "RIGHT";
})(MouseButton || (MouseButton = {}));
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/libs/messenger.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "enableVisualTagging",
    ()=>enableVisualTagging
]);
/* istanbul ignore file */ /* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/version.js [app-client] (ecmascript)");
;
;
/**
 * Brand key to track whether visual tagging has been enabled on a messenger.
 */ var VISUAL_TAGGING_BRAND = '__AMPLITUDE_VISUAL_TAGGING__';
function enableVisualTagging(messenger, options) {
    // Idempotency guard — works across bundle boundaries
    var branded = messenger;
    if (branded[VISUAL_TAGGING_BRAND] === true) {
        return;
    }
    branded[VISUAL_TAGGING_BRAND] = true;
    var dataExtractor = options.dataExtractor, isElementSelectable = options.isElementSelectable, cssSelectorAllowlist = options.cssSelectorAllowlist, actionClickAllowlist = options.actionClickAllowlist;
    var amplitudeVisualTaggingSelectorInstance = null;
    var onSelect = function(data) {
        messenger.notify({
            action: 'element-selected',
            data: data
        });
    };
    var onTrack = function(type, properties) {
        if (type === 'selector-mode-changed') {
            messenger.notify({
                action: 'track-selector-mode-changed',
                data: properties
            });
        } else if (type === 'selector-moved') {
            messenger.notify({
                action: 'track-selector-moved',
                data: properties
            });
        }
    };
    messenger.registerActionHandler('initialize-visual-tagging-selector', function(actionData) {
        messenger.loadScriptOnce(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_VISUAL_TAGGING_SELECTOR_SCRIPT_URL"]).then(function() {
            var _a;
            // eslint-disable-next-line
            amplitudeVisualTaggingSelectorInstance = (_a = window === null || window === void 0 ? void 0 : window.amplitudeVisualTaggingSelector) === null || _a === void 0 ? void 0 : _a.call(window, {
                getEventTagProps: dataExtractor.getEventTagProps,
                isElementSelectable: function(element) {
                    if (isElementSelectable) {
                        return isElementSelectable((actionData === null || actionData === void 0 ? void 0 : actionData.actionType) || 'click', element);
                    }
                    return true;
                },
                onTrack: onTrack,
                onSelect: onSelect,
                visualHighlightClass: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_VISUAL_TAGGING_HIGHLIGHT_CLASS"],
                messenger: messenger,
                cssSelectorAllowlist: cssSelectorAllowlist,
                actionClickAllowlist: actionClickAllowlist,
                extractDataFromDataSource: dataExtractor.extractDataFromDataSource,
                dataExtractor: dataExtractor,
                diagnostics: {
                    autocapture: {
                        version: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VERSION"]
                    }
                }
            });
            messenger.notify({
                action: 'selector-loaded'
            });
        }).catch(function() {
            var _a;
            (_a = messenger.logger) === null || _a === void 0 ? void 0 : _a.warn('Failed to initialize visual tagging selector');
        });
    });
    messenger.registerActionHandler('close-visual-tagging-selector', function() {
        var _a;
        // eslint-disable-next-line
        (_a = amplitudeVisualTaggingSelectorInstance === null || amplitudeVisualTaggingSelectorInstance === void 0 ? void 0 : amplitudeVisualTaggingSelectorInstance.close) === null || _a === void 0 ? void 0 : _a.call(amplitudeVisualTaggingSelectorInstance);
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-click.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackClicks",
    ()=>trackClicks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
function trackClicks(_a) {
    var amplitude = _a.amplitude, allObservables = _a.allObservables, shouldTrackEvent = _a.shouldTrackEvent, evaluateTriggers = _a.evaluateTriggers;
    var clickObservable = allObservables.clickObservable;
    var clickObservableFiltered = clickObservable.filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterOutNonTrackableEvents"]).filter(function(click) {
        // Only track clicks on elements that should be tracked,
        return shouldTrackEvent('click', click.closestTrackedAncestor);
    }).map(function(click) {
        return evaluateTriggers(click);
    });
    var clicks = clickObservableFiltered;
    return clicks.subscribe(function(click) {
        /* istanbul ignore next */ amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_ELEMENT_CLICKED_EVENT"], click.targetElementProperties);
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-change.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackChange",
    ()=>trackChange
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
function trackChange(_a) {
    var amplitude = _a.amplitude, allObservables = _a.allObservables, getEventProperties = _a.getEventProperties, shouldTrackEvent = _a.shouldTrackEvent, evaluateTriggers = _a.evaluateTriggers;
    var changeObservable = allObservables.changeObservable;
    var filteredChangeObservable = changeObservable.filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterOutNonTrackableEvents"]).filter(function(changeEvent) {
        // Only track change on elements that should be tracked,
        return shouldTrackEvent('change', changeEvent.closestTrackedAncestor);
    }).map(function(changeEvent) {
        return evaluateTriggers(changeEvent);
    });
    return filteredChangeObservable.subscribe(function(changeEvent) {
        /* istanbul ignore next */ amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_ELEMENT_CHANGED_EVENT"], getEventProperties('change', changeEvent.closestTrackedAncestor));
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-action-click.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackActionClick",
    ()=>trackActionClick
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
;
function trackActionClick(_a) {
    var amplitude = _a.amplitude, allObservables = _a.allObservables, options = _a.options, getEventProperties = _a.getEventProperties, shouldTrackEvent = _a.shouldTrackEvent, shouldTrackActionClick = _a.shouldTrackActionClick;
    var clickObservable = allObservables.clickObservable, mutationObservable = allObservables.mutationObservable, navigateObservable = allObservables.navigateObservable;
    var filteredClickObservable = clickObservable.filter(function(click) {
        return !shouldTrackEvent('click', click.closestTrackedAncestor);
    }).map(function(click) {
        // overwrite the closestTrackedAncestor with the closest element that is on the actionClickAllowlist
        var closestActionClickEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClosestElement"])(click.event.target, options.actionClickAllowlist);
        click.closestTrackedAncestor = closestActionClickEl;
        // overwrite the targetElementProperties with the properties of the closestActionClickEl
        if (click.closestTrackedAncestor !== null) {
            click.targetElementProperties = getEventProperties(click.type, click.closestTrackedAncestor);
        }
        return click;
    }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterOutNonTrackableEvents"]).filter(function(clickEvent) {
        // Only track change on elements that should be tracked
        return shouldTrackActionClick('click', clickEvent.closestTrackedAncestor);
    });
    var mutationOrNavigate = navigateObservable ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(mutationObservable, navigateObservable) : mutationObservable;
    var clickMutationNavigateObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(filteredClickObservable, mutationOrNavigate);
    var actionClickTimer = null;
    var lastClickEvent = null;
    var actionClickObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asyncMap"])(clickMutationNavigateObservable, function(event) {
        // clear any previous timer
        if (actionClickTimer) {
            clearTimeout(actionClickTimer);
            actionClickTimer = null;
        }
        if (event.type === 'click') {
            // mark the 'last click event'
            lastClickEvent = event;
            // set a timer to clear last click event if no mutation event between now and 500ms
            actionClickTimer = setTimeout(function() {
                actionClickTimer = null;
                lastClickEvent = null;
            }, 500);
            return Promise.resolve(null);
        } else {
            // if mutation/navigation + last click event, then it's an action click
            if (lastClickEvent) {
                var event_1 = lastClickEvent;
                lastClickEvent = null;
                return Promise.resolve(event_1);
            }
        }
        return Promise.resolve(null);
    });
    return actionClickObservable.subscribe(function(actionClick) {
        if (!actionClick) return;
        /* istanbul ignore next */ amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_ELEMENT_CLICKED_EVENT"], getEventProperties('click', actionClick.closestTrackedAncestor));
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-scroll.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackScroll",
    ()=>trackScroll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
function trackScroll(_a) {
    var amplitude = _a.amplitude, allObservables = _a.allObservables;
    // amplitude is reserved for future periodic scroll event tracking
    void amplitude;
    var scrollObservable = allObservables.scrollObservable;
    var state = {
        maxX: 0,
        maxY: 0
    };
    var scrollSubscription = scrollObservable.subscribe(function() {
        var _a, _b, _c, _d;
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        /* istanbul ignore next */ var currentX = Math.floor((_b = (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.scrollX) !== null && _a !== void 0 ? _a : globalScope === null || globalScope === void 0 ? void 0 : globalScope.pageXOffset) !== null && _b !== void 0 ? _b : 0);
        /* istanbul ignore next */ var currentY = Math.floor((_d = (_c = globalScope === null || globalScope === void 0 ? void 0 : globalScope.scrollY) !== null && _c !== void 0 ? _c : globalScope === null || globalScope === void 0 ? void 0 : globalScope.pageYOffset) !== null && _d !== void 0 ? _d : 0);
        // Update page-level max positions for Page View End event (never resets during page lifetime)
        state.maxX = Math.max(state.maxX, currentX);
        state.maxY = Math.max(state.maxY, currentY);
    });
    return {
        unsubscribe: function() {
            scrollSubscription.unsubscribe();
        },
        getState: function() {
            return state;
        },
        reset: function() {
            state.maxX = 0;
            state.maxY = 0;
        }
    };
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/observables.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClickObservable",
    ()=>createClickObservable,
    "createErrorObservable",
    ()=>createErrorObservable,
    "createExposureObservable",
    ()=>createExposureObservable,
    "createMouseMoveObservable",
    ()=>createMouseMoveObservable,
    "createMutationObservable",
    ()=>createMutationObservable,
    "createScrollObservable",
    ()=>createScrollObservable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript) <export default as Observable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$console$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/observers/console.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
;
;
/* eslint-disable-next-line no-restricted-globals */ var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
var createMutationObservable = function() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var mutationObserver = new MutationObserver(function(mutations) {
            observer.next(mutations);
        });
        if (document.body) {
            mutationObserver.observe(document.body, {
                childList: true,
                attributes: true,
                characterData: true,
                subtree: true
            });
        }
        return function() {
            return mutationObserver.disconnect();
        };
    });
};
var createClickObservable = function(clickType) {
    if (clickType === void 0) {
        clickType = 'click';
    }
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var _a;
        var handler = function(event) {
            observer.next(event);
        };
        (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.document.addEventListener(clickType, handler, {
            capture: true
        });
        return function() {
            var _a;
            (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.document.removeEventListener(clickType, handler, {
                capture: true
            });
        };
    });
};
var createScrollObservable = function() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var _a;
        var handler = function(event) {
            observer.next(event);
        };
        (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.addEventListener('scroll', handler);
        return function() {
            var _a;
            (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.removeEventListener('scroll', handler);
        };
    });
};
var createConsoleErrorObservable = function() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var handler = function(_) {
            var args = [];
            for(var _i = 1; _i < arguments.length; _i++){
                args[_i - 1] = arguments[_i];
            }
            /* istanbul ignore next */ var message = undefined;
            if (Array.isArray(args[0]) && typeof args[0][0] === 'string') {
                message = args[0][0];
            }
            observer.next({
                kind: 'console',
                message: message
            });
        };
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$console$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["consoleObserver"].addListener('error', handler);
        return function() {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$observers$2f$console$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["consoleObserver"].removeListener(handler);
        };
    });
};
var createExposureObservable = function(mutationObservable, selectorAllowlist) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var _a;
        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
        if (!(globalScope === null || globalScope === void 0 ? void 0 : globalScope.IntersectionObserver)) {
            return function() {
                return;
            };
        }
        var intersectionObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                observer.next(entry);
            });
        }, {
            root: null,
            rootMargin: '0px',
            threshold: 1.0
        });
        // Observe initial elements
        var selectorString = selectorAllowlist.join(',');
        /* istanbul ignore next */ var initialElements = (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.document.querySelectorAll(selectorString)) !== null && _a !== void 0 ? _a : [];
        initialElements.forEach(function(element) {
            intersectionObserver.observe(element);
        });
        // Use mutation observable to observe new elements that match the allowlist
        var mutationSubscription = mutationObservable.subscribe(function(_a) {
            var event = _a.event;
            return event.forEach(function(_a) {
                var addedNodes = _a.addedNodes;
                return addedNodes.forEach(function(node) {
                    if (!(node instanceof Element)) {
                        return;
                    }
                    if (node.matches(selectorString)) {
                        intersectionObserver.observe(node);
                    }
                    node.querySelectorAll(selectorString).forEach(function(child) {
                        intersectionObserver.observe(child);
                    });
                });
            });
        });
        return function() {
            mutationSubscription.unsubscribe();
            intersectionObserver.disconnect();
        };
    });
};
var createUnhandledErrorObservable = function() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var handler = function(event) {
            if (!(event instanceof ErrorEvent)) {
                return;
            }
            var output = {
                kind: 'error'
            };
            if (event.error instanceof Error || event.error instanceof DOMException) {
                output = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, output), {
                    message: event.error.message,
                    stack: event.error.stack,
                    filename: event.filename,
                    lineNumber: event.lineno,
                    columnNumber: event.colno
                });
            } else if (typeof event.error === 'string') {
                output.message = event.error;
            }
            observer.next(output);
        };
        globalScope.addEventListener('error', handler);
        return function() {
            globalScope.removeEventListener('error', handler);
        };
    });
};
var createUnhandledRejectionObservable = function() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var handler = function(event) {
            var output = {
                kind: 'unhandledrejection'
            };
            if (event.reason instanceof Error || event.reason instanceof DOMException) {
                output.message = event.reason.message;
                output.stack = event.reason.stack;
            } else if (typeof event.reason === 'string') {
                output.message = event.reason;
            }
            observer.next(output);
        };
        globalScope.addEventListener('unhandledrejection', handler);
        return function() {
            globalScope.removeEventListener('unhandledrejection', handler);
        };
    });
};
var createErrorObservable = function() {
    var unhandledErrorObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(createUnhandledErrorObservable(), createUnhandledRejectionObservable());
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(unhandledErrorObservable, createConsoleErrorObservable());
};
var createMouseMoveObservable = function() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var handler = function(event) {
            observer.next(event);
        };
        var args = {
            capture: true
        };
        globalScope.document.addEventListener('mousemove', handler, args);
        return function() {
            globalScope.document.removeEventListener('mousemove', handler, args);
        };
    });
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/matchEventToFilter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Matches an event to a single filter
 * @param event - The event to match
 * @param filter - The filter to match against
 * @returns boolean indicating if the event matches the filter
 */ __turbopack_context__.s([
    "matchEventToFilter",
    ()=>matchEventToFilter
]);
var matchEventToFilter = function(event, filter) {
    try {
        if (filter.subprop_key === '[Amplitude] Element Text') {
            // TODO: add support for the other operators
            return filter.subprop_op === 'is' && filter.subprop_value.includes(event.targetElementProperties['[Amplitude] Element Text']);
        } else if (filter.subprop_key === '[Amplitude] Element Hierarchy') {
            // Check if the element ancestory matches the CSS selector, always check this last since it is the most expensive
            return filter.subprop_op === 'autotrack css match' && !!event.closestTrackedAncestor.closest(filter.subprop_value.toString());
        }
    } catch (error) {
        console.error('Error matching event to filter', error);
        return false;
    }
    return false;
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/actions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Get DataSource
/**
 * Gets the DOM element specified by the data source configuration
 * @param dataSource - Configuration for finding the target element
 * @param contextElement - The element to start searching from
 * @returns The matching DOM element or undefined if not found
 */ __turbopack_context__.s([
    "executeActions",
    ()=>executeActions,
    "getDataSource",
    ()=>getDataSource
]);
var getDataSource = function(dataSource, contextElement) {
    // Only process DOM_ELEMENT type data sources
    try {
        if (dataSource.sourceType === 'DOM_ELEMENT') {
            // If scope is specified, find the closest ancestor matching the scope rather than using documentElement (html) as the scope
            var scopingElement = document.documentElement;
            if (dataSource.scope && contextElement) {
                scopingElement = contextElement.closest(dataSource.scope);
            }
            // If we have both a scope and selector, find the matching element
            if (scopingElement && dataSource.selector) {
                return scopingElement.querySelector(dataSource.selector);
            }
            // Return scopingElement if no selector was specified
            return scopingElement;
        }
    } catch (error) {
        return undefined;
    }
    // Return undefined for non-DOM_ELEMENT data sources
    return undefined;
};
var executeActions = function(actions, ev, dataExtractor) {
    actions.forEach(function(action) {
        // Skip if actions is string until action set is implemented
        if (typeof action === 'string') {
            return;
        }
        if (action.actionType === 'ATTACH_EVENT_PROPERTY') {
            var data = dataExtractor.extractDataFromDataSource(action.dataSource, ev.closestTrackedAncestor);
            // Attach data to event
            ev.targetElementProperties[action.destinationKey] = data;
        }
    });
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/triggers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TriggerEvaluator",
    ()=>TriggerEvaluator,
    "createLabeledEventToTriggerMap",
    ()=>createLabeledEventToTriggerMap,
    "createTriggerEvaluator",
    ()=>createTriggerEvaluator,
    "groupLabeledEventIdsByEventType",
    ()=>groupLabeledEventIdsByEventType,
    "matchEventToLabeledEvents",
    ()=>matchEventToLabeledEvents,
    "matchLabeledEventsToTriggers",
    ()=>matchLabeledEventsToTriggers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$matchEventToFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/matchEventToFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$actions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/actions.js [app-client] (ecmascript)");
;
;
;
var eventTypeToBrowserEventMap = {
    '[Amplitude] Element Clicked': 'click',
    '[Amplitude] Element Changed': 'change'
};
var groupLabeledEventIdsByEventType = function(labeledEvents) {
    var e_1, _a, e_2, _b;
    // Initialize all event types with empty sets
    var groupedLabeledEvents = Object.values(eventTypeToBrowserEventMap).reduce(function(acc, browserEvent) {
        acc[browserEvent] = new Set();
        return acc;
    }, {});
    // If there are no labeled events, return the initialized groupedLabeledEvents
    if (!labeledEvents) {
        return groupedLabeledEvents;
    }
    try {
        // Group labeled events by event type
        for(var labeledEvents_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(labeledEvents), labeledEvents_1_1 = labeledEvents_1.next(); !labeledEvents_1_1.done; labeledEvents_1_1 = labeledEvents_1.next()){
            var le = labeledEvents_1_1.value;
            try {
                try {
                    for(var _c = (e_2 = void 0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(le.definition)), _d = _c.next(); !_d.done; _d = _c.next()){
                        var def = _d.value;
                        var browserEvent = eventTypeToBrowserEventMap[def.event_type];
                        if (browserEvent) {
                            groupedLabeledEvents[browserEvent].add(le.id);
                        }
                    }
                } catch (e_2_1) {
                    e_2 = {
                        error: e_2_1
                    };
                } finally{
                    try {
                        if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
                    } finally{
                        if (e_2) throw e_2.error;
                    }
                }
            } catch (e) {
                // Skip this labeled event if there is an error
                console.warn('Skipping Labeled Event due to malformed definition', le === null || le === void 0 ? void 0 : le.id, e);
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (labeledEvents_1_1 && !labeledEvents_1_1.done && (_a = labeledEvents_1.return)) _a.call(labeledEvents_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    return groupedLabeledEvents;
};
var createLabeledEventToTriggerMap = function(triggers) {
    var e_3, _a, e_4, _b;
    var labeledEventToTriggerMap = new Map();
    try {
        for(var triggers_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(triggers), triggers_1_1 = triggers_1.next(); !triggers_1_1.done; triggers_1_1 = triggers_1.next()){
            var trigger = triggers_1_1.value;
            try {
                for(var _c = (e_4 = void 0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(trigger.conditions)), _d = _c.next(); !_d.done; _d = _c.next()){
                    var condition = _d.value;
                    if (condition.type === 'LABELED_EVENT') {
                        var eventId = condition.match.eventId;
                        // Get existing triggers for this event ID or initialize empty array
                        var existingTriggers = labeledEventToTriggerMap.get(eventId);
                        if (!existingTriggers) {
                            existingTriggers = [];
                            labeledEventToTriggerMap.set(eventId, existingTriggers);
                        }
                        // Add current trigger to the list of triggers for this event ID
                        existingTriggers.push(trigger);
                    }
                }
            } catch (e_4_1) {
                e_4 = {
                    error: e_4_1
                };
            } finally{
                try {
                    if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
                } finally{
                    if (e_4) throw e_4.error;
                }
            }
        }
    } catch (e_3_1) {
        e_3 = {
            error: e_3_1
        };
    } finally{
        try {
            if (triggers_1_1 && !triggers_1_1.done && (_a = triggers_1.return)) _a.call(triggers_1);
        } finally{
            if (e_3) throw e_3.error;
        }
    }
    return labeledEventToTriggerMap;
};
var matchEventToLabeledEvents = function(event, labeledEvents) {
    return labeledEvents.filter(function(le) {
        return le.definition.some(function(def) {
            return eventTypeToBrowserEventMap[def.event_type] === event.type && def.filters.every(function(filter) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$matchEventToFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchEventToFilter"])(event, filter);
            });
        });
    });
};
var matchLabeledEventsToTriggers = function(labeledEvents, leToTriggerMap) {
    var e_5, _a, e_6, _b;
    var matchingTriggers = new Set();
    try {
        for(var labeledEvents_2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(labeledEvents), labeledEvents_2_1 = labeledEvents_2.next(); !labeledEvents_2_1.done; labeledEvents_2_1 = labeledEvents_2.next()){
            var le = labeledEvents_2_1.value;
            var triggers = leToTriggerMap.get(le.id);
            if (triggers) {
                try {
                    for(var triggers_2 = (e_6 = void 0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(triggers)), triggers_2_1 = triggers_2.next(); !triggers_2_1.done; triggers_2_1 = triggers_2.next()){
                        var trigger = triggers_2_1.value;
                        matchingTriggers.add(trigger);
                    }
                } catch (e_6_1) {
                    e_6 = {
                        error: e_6_1
                    };
                } finally{
                    try {
                        if (triggers_2_1 && !triggers_2_1.done && (_b = triggers_2.return)) _b.call(triggers_2);
                    } finally{
                        if (e_6) throw e_6.error;
                    }
                }
            }
        }
    } catch (e_5_1) {
        e_5 = {
            error: e_5_1
        };
    } finally{
        try {
            if (labeledEvents_2_1 && !labeledEvents_2_1.done && (_a = labeledEvents_2.return)) _a.call(labeledEvents_2);
        } finally{
            if (e_5) throw e_5.error;
        }
    }
    return Array.from(matchingTriggers);
};
var TriggerEvaluator = function() {
    function TriggerEvaluator(groupedLabeledEvents, labeledEventToTriggerMap, dataExtractor, options) {
        this.groupedLabeledEvents = groupedLabeledEvents;
        this.labeledEventToTriggerMap = labeledEventToTriggerMap;
        this.dataExtractor = dataExtractor;
        this.options = options;
    }
    TriggerEvaluator.prototype.evaluate = function(event) {
        var e_7, _a;
        // If there is no pageActions, return the event as is
        var pageActions = this.options.pageActions;
        if (!pageActions) {
            return event;
        }
        // Find matching labeled events
        var matchingLabeledEvents = matchEventToLabeledEvents(event, Array.from(this.groupedLabeledEvents[event.type]).map(function(id) {
            return pageActions.labeledEvents[id];
        }));
        // Find matching conditions
        var matchingTriggers = matchLabeledEventsToTriggers(matchingLabeledEvents, this.labeledEventToTriggerMap);
        try {
            for(var matchingTriggers_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(matchingTriggers), matchingTriggers_1_1 = matchingTriggers_1.next(); !matchingTriggers_1_1.done; matchingTriggers_1_1 = matchingTriggers_1.next()){
                var trigger = matchingTriggers_1_1.value;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$actions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["executeActions"])(trigger.actions, event, this.dataExtractor);
            }
        } catch (e_7_1) {
            e_7 = {
                error: e_7_1
            };
        } finally{
            try {
                if (matchingTriggers_1_1 && !matchingTriggers_1_1.done && (_a = matchingTriggers_1.return)) _a.call(matchingTriggers_1);
            } finally{
                if (e_7) throw e_7.error;
            }
        }
        return event;
    };
    TriggerEvaluator.prototype.update = function(groupedLabeledEvents, labeledEventToTriggerMap, options) {
        this.groupedLabeledEvents = groupedLabeledEvents;
        this.labeledEventToTriggerMap = labeledEventToTriggerMap;
        this.options = options;
    };
    return TriggerEvaluator;
}();
;
var createTriggerEvaluator = function(groupedLabeledEvents, labeledEventToTriggerMap, dataExtractor, options) {
    return new TriggerEvaluator(groupedLabeledEvents, labeledEventToTriggerMap, dataExtractor, options);
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/hierarchy.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_HIERARCHY_LENGTH",
    ()=>MAX_HIERARCHY_LENGTH,
    "getAncestors",
    ()=>getAncestors,
    "getElementProperties",
    ()=>getElementProperties
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/helpers.js [app-client] (ecmascript)");
;
;
;
;
;
var BLOCKED_ATTRIBUTES = new Set([
    // Already captured elsewhere in the hierarchy object
    'id',
    'class',
    // non-useful and potentially large attribute
    'style',
    // sensitive as prefilled form data may populate this attribute
    'value',
    // DOM events
    'onclick',
    'onchange',
    'oninput',
    'onblur',
    'onsubmit',
    'onfocus',
    'onkeydown',
    'onkeyup',
    'onkeypress',
    // React specific
    'data-reactid',
    'data-react-checksum',
    'data-reactroot',
    // Amplitude specific - used for redaction but should not be included in getElementProperties
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DATA_AMP_MASK_ATTRIBUTES"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_MASK_ATTRIBUTE"]
]);
var SENSITIVE_ELEMENT_ATTRIBUTE_ALLOWLIST = [
    'type'
];
var SVG_TAGS = [
    'svg',
    'path',
    'g'
];
var HIGHLY_SENSITIVE_INPUT_TYPES = [
    'password',
    'hidden'
];
var MAX_HIERARCHY_LENGTH = 1024;
function getElementProperties(element, userMaskedAttributeNames) {
    var e_1, _a;
    var _b, _c, _d, _e;
    if (element === null) {
        return null;
    }
    var tagName = String(element.tagName).toLowerCase();
    var properties = {
        tag: tagName
    };
    var siblings = Array.from((_c = (_b = element.parentElement) === null || _b === void 0 ? void 0 : _b.children) !== null && _c !== void 0 ? _c : []);
    if (siblings.length) {
        properties.index = siblings.indexOf(element);
        properties.indexOfType = siblings.filter(function(el) {
            return el.tagName === element.tagName;
        }).indexOf(element);
    }
    var prevSiblingTag = (_e = (_d = element.previousElementSibling) === null || _d === void 0 ? void 0 : _d.tagName) === null || _e === void 0 ? void 0 : _e.toLowerCase();
    if (prevSiblingTag) {
        properties.prevSib = String(prevSiblingTag);
    }
    var id = element.getAttribute('id');
    if (id) {
        properties.id = String(id);
    }
    var classes = Array.from(element.classList);
    if (classes.length) {
        properties.classes = classes;
    }
    var attributes = {};
    var attributesArray = Array.from(element.attributes);
    var filteredAttributes = attributesArray.filter(function(attr) {
        return !BLOCKED_ATTRIBUTES.has(attr.name);
    });
    var isSensitiveElement = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNonSensitiveElement"])(element);
    // if input is hidden or password or for SVGs, skip attribute collection entirely
    if (!HIGHLY_SENSITIVE_INPUT_TYPES.includes(String(element.getAttribute('type'))) && !SVG_TAGS.includes(tagName)) {
        try {
            for(var filteredAttributes_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(filteredAttributes), filteredAttributes_1_1 = filteredAttributes_1.next(); !filteredAttributes_1_1.done; filteredAttributes_1_1 = filteredAttributes_1.next()){
                var attr = filteredAttributes_1_1.value;
                // If sensitive element, only allow certain attributes
                if (isSensitiveElement && !SENSITIVE_ELEMENT_ATTRIBUTE_ALLOWLIST.includes(attr.name)) {
                    continue;
                }
                if (userMaskedAttributeNames.has(attr.name)) {
                    attributes[attr.name] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MASKED_TEXT_VALUE"];
                    continue;
                }
                // Finally cast attribute value to string and limit attribute value length
                attributes[attr.name] = String(attr.value).substring(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MAX_ATTRIBUTE_LENGTH"]);
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (filteredAttributes_1_1 && !filteredAttributes_1_1.done && (_a = filteredAttributes_1.return)) _a.call(filteredAttributes_1);
            } finally{
                if (e_1) throw e_1.error;
            }
        }
    }
    if (Object.keys(attributes).length) {
        properties.attrs = attributes;
    }
    return properties;
}
function getAncestors(targetEl) {
    var ancestors = [];
    if (!targetEl) {
        return ancestors;
    }
    // Add self to the list of ancestors
    ancestors.push(targetEl);
    var current = targetEl.parentElement;
    while(current && current.tagName !== 'HTML'){
        ancestors.push(current);
        current = current.parentElement;
    }
    return ancestors;
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/libs/element-path.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cssPath",
    ()=>cssPath
]);
/* istanbul ignore file */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
// Code is adapted from The Chromium Authors.
// Source: https://github.com/ChromeDevTools/devtools-frontend/blob/main/front_end/panels/elements/DOMPath.ts#L14
// License: BSD-style license
//
// Copyright 2014 The Chromium Authors
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//    * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//    * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
var Step = function() {
    function Step(value, optimized) {
        this.value = value;
        this.optimized = optimized;
    }
    Step.prototype.toString = function() {
        return this.value;
    };
    return Step;
}();
var cssPath = function(node, optimized) {
    // `node` is already an Element; this check is defensive.
    if (node.nodeType !== Node.ELEMENT_NODE) {
        return '';
    }
    var steps = [];
    var contextNode = node;
    while(contextNode){
        var step = cssPathStep(contextNode, Boolean(optimized), contextNode === node);
        if (!step) {
            break;
        } // bail out early
        steps.push(step);
        if (step.optimized) {
            break;
        }
        contextNode = contextNode.parentElement;
    }
    steps.reverse();
    return steps.join(' > ');
};
var cssPathStep = function(node, optimized, isTargetNode) {
    var e_1, _a;
    if (node.nodeType !== Node.ELEMENT_NODE) {
        return null;
    }
    var id = node.getAttribute('id');
    if (optimized) {
        if (id) {
            return new Step(idSelector(id), true);
        }
        var nodeNameLower = node.tagName.toLowerCase();
        if (nodeNameLower === 'body' || nodeNameLower === 'head' || nodeNameLower === 'html') {
            return new Step(nodeNameLower, true);
        }
    }
    var nodeName = node.tagName.toLowerCase();
    if (id) {
        return new Step(nodeName + idSelector(id), true);
    }
    var parent = node.parentNode;
    if (!parent || parent.nodeType === Node.DOCUMENT_NODE) {
        return new Step(nodeName, true);
    }
    function prefixedElementClassNames(el) {
        var classAttribute = el.getAttribute('class');
        if (!classAttribute) {
            return [];
        }
        return classAttribute.split(/\s+/g).filter(Boolean).map(function(name) {
            // The prefix is required to store "__proto__" in a object-based map.
            return '$' + name;
        });
    }
    function idSelector(id) {
        return '#' + CSS.escape(id);
    }
    var prefixedOwnClassNamesArray = prefixedElementClassNames(node);
    var needsClassNames = false;
    var needsNthChild = false;
    var ownIndex = -1;
    var elementIndex = -1;
    var siblings = parent.children;
    for(var i = 0; siblings && (ownIndex === -1 || !needsNthChild) && i < siblings.length; ++i){
        var sibling = siblings[i];
        if (sibling.nodeType !== Node.ELEMENT_NODE) {
            continue;
        }
        elementIndex += 1;
        if (sibling === node) {
            ownIndex = elementIndex;
            continue;
        }
        if (needsNthChild) {
            continue;
        }
        if (sibling.tagName.toLowerCase() !== nodeName) {
            continue;
        }
        needsClassNames = true;
        var ownClassNames = new Set(prefixedOwnClassNamesArray);
        if (!ownClassNames.size) {
            needsNthChild = true;
            continue;
        }
        var siblingClassNamesArray = prefixedElementClassNames(sibling);
        for(var j = 0; j < siblingClassNamesArray.length; ++j){
            var siblingClass = siblingClassNamesArray[j];
            if (!ownClassNames.has(siblingClass)) {
                continue;
            }
            ownClassNames.delete(siblingClass);
            if (!ownClassNames.size) {
                needsNthChild = true;
                break;
            }
        }
    }
    var result = nodeName;
    if (isTargetNode && nodeName.toLowerCase() === 'input' && node.getAttribute('type') && !node.getAttribute('id') && !node.getAttribute('class')) {
        result += '[type=' + CSS.escape(node.getAttribute('type') || '') + ']';
    }
    if (needsNthChild) {
        result += ':nth-child(' + String(ownIndex + 1) + ')';
    } else if (needsClassNames) {
        try {
            for(var prefixedOwnClassNamesArray_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(prefixedOwnClassNamesArray), prefixedOwnClassNamesArray_1_1 = prefixedOwnClassNamesArray_1.next(); !prefixedOwnClassNamesArray_1_1.done; prefixedOwnClassNamesArray_1_1 = prefixedOwnClassNamesArray_1.next()){
                var prefixedName = prefixedOwnClassNamesArray_1_1.value;
                result += '.' + CSS.escape(prefixedName.slice(1));
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (prefixedOwnClassNamesArray_1_1 && !prefixedOwnClassNamesArray_1_1.done && (_a = prefixedOwnClassNamesArray_1.return)) _a.call(prefixedOwnClassNamesArray_1);
            } finally{
                if (e_1) throw e_1.error;
            }
        }
    }
    return new Step(result, false);
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/data-extractor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DataExtractor",
    ()=>DataExtractor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$hierarchy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/hierarchy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$actions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/actions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$libs$2f$element$2d$path$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/libs/element-path.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
var DataExtractor = function() {
    function DataExtractor(options, context) {
        var e_1, _a;
        var _this = this;
        var _b;
        /**
         * Wrapper method to replace sensitive strings using the helper function
         * @param text - The text to search for sensitive data
         * @returns The text with sensitive data replaced by masked text
         */ this.replaceSensitiveString = function(text) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceSensitiveString"])(text, _this.additionalMaskTextPatterns);
        };
        // Get the DOM hierarchy of the element, starting from the target element to the root element.
        this.getHierarchy = function(element) {
            var e_2, _a;
            var _b, _c;
            var startTime = performance.now();
            var hierarchy = [];
            if (!element) {
                return [];
            }
            // Get list of ancestors including itself and get properties at each level in the hierarchy
            var ancestors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$hierarchy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAncestors"])(element);
            // Build attributes to mask map
            var elementToAttributesToMaskMap = new Map();
            for(var i = ancestors.length - 1; i >= 0; i--){
                var node = ancestors[i];
                if (node) {
                    var attributesToMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAttributesToMask"])(node.getAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DATA_AMP_MASK_ATTRIBUTES"]));
                    var ancestorAttributesToMask = i === ancestors.length - 1 ? [] : (_b = elementToAttributesToMaskMap.get(ancestors[i + 1])) !== null && _b !== void 0 ? _b : new Set();
                    var combinedAttributesToMask = new Set((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(ancestorAttributesToMask), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(attributesToMask), false));
                    elementToAttributesToMaskMap.set(node, combinedAttributesToMask);
                }
            }
            hierarchy = ancestors.map(function(el) {
                var _a;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$hierarchy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getElementProperties"])(el, (_a = elementToAttributesToMaskMap.get(el)) !== null && _a !== void 0 ? _a : new Set());
            });
            var _loop_1 = function(hierarchyNode) {
                if (hierarchyNode === null || hierarchyNode === void 0 ? void 0 : hierarchyNode.attrs) {
                    Object.entries(hierarchyNode.attrs).forEach(function(_a) {
                        var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), key = _b[0], value = _b[1];
                        if (hierarchyNode.attrs) {
                            hierarchyNode.attrs[key] = _this.replaceSensitiveString(value);
                        }
                    });
                }
            };
            try {
                // Search for and mask any sensitive attribute values
                for(var hierarchy_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(hierarchy), hierarchy_1_1 = hierarchy_1.next(); !hierarchy_1_1.done; hierarchy_1_1 = hierarchy_1.next()){
                    var hierarchyNode = hierarchy_1_1.value;
                    _loop_1(hierarchyNode);
                }
            } catch (e_2_1) {
                e_2 = {
                    error: e_2_1
                };
            } finally{
                try {
                    if (hierarchy_1_1 && !hierarchy_1_1.done && (_a = hierarchy_1.return)) _a.call(hierarchy_1);
                } finally{
                    if (e_2) throw e_2.error;
                }
            }
            var endTime = performance.now();
            (_c = _this.diagnosticsClient) === null || _c === void 0 ? void 0 : _c.recordHistogram('autocapturePlugin.getHierarchy', endTime - startTime);
            return hierarchy;
        };
        this.getNearestLabel = function(element) {
            var parent = element.parentElement;
            if (!parent) {
                return '';
            }
            var labelElement;
            try {
                labelElement = parent.querySelector(':scope>span,h1,h2,h3,h4,h5,h6');
            } catch (_a) {
                /* istanbul ignore next */ labelElement = null;
            }
            if (labelElement) {
                /* istanbul ignore next */ return _this.getText(labelElement);
            }
            return _this.getNearestLabel(parent);
        };
        this.getElementPath = function(element) {
            var _a;
            if (!element) {
                return '';
            }
            var startTime = performance.now();
            var elementPath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$libs$2f$element$2d$path$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cssPath"])(element);
            var endTime = performance.now();
            (_a = _this.diagnosticsClient) === null || _a === void 0 ? void 0 : _a.recordHistogram('autocapturePlugin.getElementPath', endTime - startTime);
            return elementPath;
        };
        // Returns the Amplitude event properties for the given element.
        this.getEventProperties = function(actionType, element, dataAttributePrefix) {
            var _a;
            var _b, _c, _d;
            /* istanbul ignore next */ var tag = (_c = (_b = element === null || element === void 0 ? void 0 : element.tagName) === null || _b === void 0 ? void 0 : _b.toLowerCase) === null || _c === void 0 ? void 0 : _c.call(_b);
            /* istanbul ignore next */ var rect = typeof element.getBoundingClientRect === 'function' ? element.getBoundingClientRect() : {
                left: null,
                top: null
            };
            var hierarchy = _this.getHierarchy(element);
            var currentElementAttributes = (_d = hierarchy[0]) === null || _d === void 0 ? void 0 : _d.attrs;
            var nearestLabel = _this.getNearestLabel(element);
            var attributes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractPrefixedAttributes"])(currentElementAttributes !== null && currentElementAttributes !== void 0 ? currentElementAttributes : {}, dataAttributePrefix);
            /* istanbul ignore next */ var properties = (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_HIERARCHY"]] = hierarchy, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_TAG"]] = tag, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_TEXT"]] = _this.getText(element), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_LEFT"]] = rect.left == null ? null : Math.round(rect.left), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_TOP"]] = rect.top == null ? null : Math.round(rect.top), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_ATTRIBUTES"]] = attributes, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_PATH"]] = _this.getElementPath(element), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_PARENT_LABEL"]] = nearestLabel, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_PAGE_URL"]] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(window.location.href.split('?')[0]), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_PAGE_TITLE"]] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageTitle"])(_this.replaceSensitiveString), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT"]] = window.innerHeight, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH"]] = window.innerWidth, _a);
            var pageViewId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentPageViewId"])();
            /* istanbul ignore next */ if (pageViewId) {
                /* istanbul ignore next */ properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_PAGE_VIEW_ID"]] = pageViewId;
            }
            // id is never masked, so always include it
            properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_ID"]] = element.getAttribute('id') || '';
            // class is never masked, so always include it
            properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_CLASS"]] = element.getAttribute('class');
            properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_ARIA_LABEL"]] = currentElementAttributes === null || currentElementAttributes === void 0 ? void 0 : currentElementAttributes['aria-label'];
            if (tag === 'a' && actionType === 'click' && element instanceof HTMLAnchorElement) {
                var href = element.href.substring(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MAX_ATTRIBUTE_LENGTH"]);
                properties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_HREF"]] = _this.replaceSensitiveString(href); // we don't use hierarchy here because we don't want href value to be changed
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeEmptyProperties"])(properties);
        };
        this.addTypeAndTimestamp = function(event, type) {
            return {
                event: event,
                timestamp: Date.now(),
                type: type
            };
        };
        this.addAdditionalEventProperties = function(event, type, selectorAllowlist, dataAttributePrefix, // capture the event if the cursor is a "pointer" when this element is clicked on
        // reason: a "pointer" cursor indicates that an element should be interactable
        //         regardless of the element's tag name
        isCapturingCursorPointer) {
            if (isCapturingCursorPointer === void 0) {
                isCapturingCursorPointer = false;
            }
            var baseEvent = _this.addTypeAndTimestamp(event, type);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElementBasedEvent"])(baseEvent) && baseEvent.event.target !== null) {
                if (isCapturingCursorPointer) {
                    var isCursorPointer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElementPointerCursor"])(baseEvent.event.target, baseEvent.type);
                    if (isCursorPointer) {
                        baseEvent.closestTrackedAncestor = baseEvent.event.target;
                        baseEvent.targetElementProperties = _this.getEventProperties(baseEvent.type, baseEvent.closestTrackedAncestor, dataAttributePrefix);
                        return baseEvent;
                    }
                }
                // Retrieve additional event properties from the target element
                var closestTrackedAncestor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClosestElement"])(baseEvent.event.target, selectorAllowlist);
                if (closestTrackedAncestor) {
                    baseEvent.closestTrackedAncestor = closestTrackedAncestor;
                    baseEvent.targetElementProperties = _this.getEventProperties(baseEvent.type, closestTrackedAncestor, dataAttributePrefix);
                }
                return baseEvent;
            }
            return baseEvent;
        };
        this.extractDataFromDataSource = function(dataSource, contextElement) {
            // Extract from DOM Element
            if (dataSource.sourceType === 'DOM_ELEMENT') {
                var sourceElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$actions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataSource"])(dataSource, contextElement);
                if (!sourceElement) {
                    return undefined;
                }
                if (dataSource.elementExtractType === 'TEXT') {
                    return _this.getText(sourceElement);
                } else if (dataSource.elementExtractType === 'ATTRIBUTE' && dataSource.attribute) {
                    return sourceElement.getAttribute(dataSource.attribute);
                }
                return undefined;
            }
            // TODO: Extract from other source types
            return undefined;
        };
        // Traverse text content without cloning DOM nodes, which avoids media/network side effects
        // from recreating nested elements such as <video>, <audio>, or <img>.
        this.getTextWithMaskedDescendants = function(element) {
            var e_3, _a;
            var maskedSelector = "[".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_MASK_ATTRIBUTE"], "], [contenteditable]");
            // Fast path: if no masked descendants exist, rely on native text extraction.
            if (!element.querySelector(maskedSelector)) {
                return element.innerText;
            }
            var output = '';
            var childNodes = Array.from(element.childNodes);
            try {
                for(var childNodes_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(childNodes), childNodes_1_1 = childNodes_1.next(); !childNodes_1_1.done; childNodes_1_1 = childNodes_1.next()){
                    var childNode = childNodes_1_1.value;
                    if (childNode.nodeType === Node.TEXT_NODE) {
                        output += childNode.textContent || '';
                        continue;
                    }
                    if (!(childNode instanceof Element)) {
                        continue;
                    }
                    // Replace entire masked/contenteditable subtrees with the mask token.
                    if (childNode.hasAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_MASK_ATTRIBUTE"]) || childNode.hasAttribute('contenteditable')) {
                        output += __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MASKED_TEXT_VALUE"];
                        continue;
                    }
                    output += _this.getTextWithMaskedDescendants(childNode);
                }
            } catch (e_3_1) {
                e_3 = {
                    error: e_3_1
                };
            } finally{
                try {
                    if (childNodes_1_1 && !childNodes_1_1.done && (_a = childNodes_1.return)) _a.call(childNodes_1);
                } finally{
                    if (e_3) throw e_3.error;
                }
            }
            return output;
        };
        this.getText = function(element) {
            // Check if element or any parent has data-amp-mask attribute
            var hasMaskAttribute = element.closest("[".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_MASK_ATTRIBUTE"], "]")) !== null;
            if (hasMaskAttribute) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MASKED_TEXT_VALUE"];
            }
            var output = '';
            if (!element.querySelector("[".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TEXT_MASK_ATTRIBUTE"], "], [contenteditable]"))) {
                output = element.innerText || '';
            } else {
                output = _this.getTextWithMaskedDescendants(element);
            }
            return _this.replaceSensitiveString(output.substring(0, 255)).replace(/\s+/g, ' ').trim();
        };
        // Returns the element properties for the given element in Visual Labeling.
        this.getEventTagProps = function(element) {
            var _a;
            var _b, _c;
            if (!element) {
                return {};
            }
            /* istanbul ignore next */ var tag = (_c = (_b = element === null || element === void 0 ? void 0 : element.tagName) === null || _b === void 0 ? void 0 : _b.toLowerCase) === null || _c === void 0 ? void 0 : _c.call(_b);
            var properties = (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_TAG"]] = tag, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_ELEMENT_TEXT"]] = _this.getText(element), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_PAGE_URL"]] = window.location.href.split('?')[0], _a);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeEmptyProperties"])(properties);
        };
        this.diagnosticsClient = context === null || context === void 0 ? void 0 : context.diagnosticsClient;
        var rawPatterns = (_b = options.maskTextRegex) !== null && _b !== void 0 ? _b : [];
        var compiled = [];
        try {
            for(var rawPatterns_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(rawPatterns), rawPatterns_1_1 = rawPatterns_1.next(); !rawPatterns_1_1.done; rawPatterns_1_1 = rawPatterns_1.next()){
                var entry = rawPatterns_1_1.value;
                if (compiled.length >= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MAX_MASK_TEXT_PATTERNS"]) {
                    break;
                }
                if (entry instanceof RegExp) {
                    compiled.push(entry);
                } else if ('pattern' in entry && typeof entry.pattern === 'string') {
                    try {
                        compiled.push(new RegExp(entry.pattern, 'i'));
                    } catch (_c) {
                    // ignore invalid pattern strings
                    }
                }
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (rawPatterns_1_1 && !rawPatterns_1_1.done && (_a = rawPatterns_1.return)) _a.call(rawPatterns_1);
            } finally{
                if (e_1) throw e_1.error;
            }
        }
        this.additionalMaskTextPatterns = compiled;
    }
    return DataExtractor;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-exposure.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackExposure",
    ()=>trackExposure
]);
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/element-interactions.js [app-client] (ecmascript)");
;
function trackExposure(_a) {
    var allObservables = _a.allObservables, onExposure = _a.onExposure, dataExtractor = _a.dataExtractor, _b = _a.exposureDuration, exposureDuration = _b === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_EXPOSURE_DURATION"] : _b;
    // Track which elements have been marked as exposed (per-element state)
    var exposureMap = new Map();
    // Track active timers for elements that are currently visible but not yet exposed
    var exposureTimerMap = new Map();
    var exposureObservable = allObservables.exposureObservable;
    var exposureSubscription = exposureObservable.subscribe(function(event) {
        var entry = event;
        var element = entry.target;
        if (entry.isIntersecting) {
            // Element became visible - start exposure timer if not already exposed
            if (!exposureMap.get(element)) {
                var timer = setTimeout(function() {
                    // Element has been visible for exposureDuration - mark as exposed
                    exposureMap.set(element, true);
                    // Record the CSS selector path in the shared exposure state
                    var elementPath = dataExtractor.getElementPath(element);
                    onExposure(elementPath);
                    // Clear the timer reference
                    exposureTimerMap.set(element, null);
                }, exposureDuration);
                exposureTimerMap.set(element, timer);
            }
        } else if (!entry.isIntersecting && entry.intersectionRatio < 1.0) {
            // Element left viewport - cancel exposure timer if one exists
            var timer = exposureTimerMap.get(element);
            if (timer) {
                clearTimeout(timer);
                exposureTimerMap.set(element, null);
            }
        }
    });
    return {
        unsubscribe: function() {
            exposureSubscription.unsubscribe();
        },
        reset: function() {
            exposureTimerMap.forEach(function(timer) {
                if (timer) {
                    clearTimeout(timer);
                }
            });
            exposureTimerMap.clear();
            exposureMap.clear();
        }
    };
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-viewport-content-updated.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fireViewportContentUpdated",
    ()=>fireViewportContentUpdated,
    "onExposure",
    ()=>onExposure
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/url-utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
;
;
;
function fireViewportContentUpdated(_a) {
    var _b;
    var _c, _d, _e, _f, _g;
    var amplitude = _a.amplitude, scrollTracker = _a.scrollTracker, currentElementExposed = _a.currentElementExposed, elementExposedForPage = _a.elementExposedForPage, exposureTracker = _a.exposureTracker, isPageEnd = _a.isPageEnd, lastScroll = _a.lastScroll;
    var pageScrollMaxState = scrollTracker.getState();
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore next */ var viewportWidth = (_c = globalScope === null || globalScope === void 0 ? void 0 : globalScope.innerWidth) !== null && _c !== void 0 ? _c : 0;
    /* istanbul ignore next */ var viewportHeight = (_d = globalScope === null || globalScope === void 0 ? void 0 : globalScope.innerHeight) !== null && _d !== void 0 ? _d : 0;
    var eventProperties = (_b = {}, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_PAGE_URL"]] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$url$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDecodeURI"])(/* istanbul ignore next */ (_g = (_f = (_e = globalScope === null || globalScope === void 0 ? void 0 : globalScope.location) === null || _e === void 0 ? void 0 : _e.href) === null || _f === void 0 ? void 0 : _f.split('?')[0]) !== null && _g !== void 0 ? _g : ''), _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_MAX_PAGE_X"]] = pageScrollMaxState.maxX + viewportWidth, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_MAX_PAGE_Y"]] = pageScrollMaxState.maxY + viewportHeight, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT"]] = viewportHeight, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH"]] = viewportWidth, _b['[Amplitude] Element Exposed'] = Array.from(currentElementExposed), _b);
    var pageViewId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentPageViewId"])();
    if (pageViewId) {
        eventProperties[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_EVENT_PROP_PAGE_VIEW_ID"]] = pageViewId;
    }
    // If elements exposed is empty and max scroll is same as last event, don't track
    if (currentElementExposed.size === 0 && pageScrollMaxState.maxX === lastScroll.maxX && pageScrollMaxState.maxY === lastScroll.maxY) {
        if (isPageEnd) {
            scrollTracker.reset();
            elementExposedForPage.clear();
            exposureTracker === null || exposureTracker === void 0 ? void 0 : exposureTracker.reset();
        }
        return;
    }
    /* istanbul ignore next */ amplitude === null || amplitude === void 0 ? void 0 : amplitude.track('[Amplitude] Viewport Content Updated', eventProperties);
    lastScroll.maxX = pageScrollMaxState.maxX;
    lastScroll.maxY = pageScrollMaxState.maxY;
    // Clear current batch
    currentElementExposed.clear();
    if (isPageEnd) {
        // Reset state for next page view
        scrollTracker.reset();
        elementExposedForPage.clear();
        exposureTracker === null || exposureTracker === void 0 ? void 0 : exposureTracker.reset();
    }
}
function onExposure(elementPath, elementExposedForPage, currentElementExposed, fireViewportContentUpdatedCallback) {
    if (elementExposedForPage.has(elementPath)) {
        return;
    }
    elementExposedForPage.add(elementPath);
    currentElementExposed.add(elementPath);
    // Check if current set size exceeds 18k chars
    var exposedArray = Array.from(currentElementExposed);
    var exposedString = JSON.stringify(exposedArray);
    if (exposedString.length >= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MAX_ELEMENT_EXPOSED_STR_LENGTH"]) {
        fireViewportContentUpdatedCallback(false);
    }
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture-plugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ObservablesEnum",
    ()=>ObservablesEnum,
    "autocapturePlugin",
    ()=>autocapturePlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/element-interactions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$base$2d$window$2d$messenger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/base-window-messenger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$background$2d$capture$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/background-capture.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/version.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/messenger/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$libs$2f$messenger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/libs/messenger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-click.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$change$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-change.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$action$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-action-click.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$scroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-scroll.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/observables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$triggers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/pageActions/triggers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$data$2d$extractor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/data-extractor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript) <export default as Observable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$exposure$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-exposure.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$viewport$2d$content$2d$updated$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-viewport-content-updated.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var ObservablesEnum;
(function(ObservablesEnum) {
    ObservablesEnum["ClickObservable"] = "clickObservable";
    ObservablesEnum["ChangeObservable"] = "changeObservable";
    ObservablesEnum["NavigateObservable"] = "navigateObservable";
    ObservablesEnum["MutationObservable"] = "mutationObservable";
    ObservablesEnum["ScrollObservable"] = "scrollObservable";
    ObservablesEnum["ExposureObservable"] = "exposureObservable";
    ObservablesEnum["BrowserErrorObservable"] = "browserErrorObservable";
    ObservablesEnum["SelectionObservable"] = "selectionObservable";
    ObservablesEnum["MouseMoveObservable"] = "mouseMoveObservable";
})(ObservablesEnum || (ObservablesEnum = {}));
var autocapturePlugin = function(options, context) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    if (options === void 0) {
        options = {};
    }
    // Set the plugin version tag
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    context === null || context === void 0 ? void 0 : context.diagnosticsClient.setTag('plugin.autocapture.version', __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VERSION"]);
    var _o = options.dataAttributePrefix, dataAttributePrefix = _o === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DATA_ATTRIBUTE_PREFIX"] : _o, _p = options.visualTaggingOptions, visualTaggingOptions = _p === void 0 ? {
        enabled: true
    } : _p;
    options.cssSelectorAllowlist = (_a = options.cssSelectorAllowlist) !== null && _a !== void 0 ? _a : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CSS_SELECTOR_ALLOWLIST"];
    options.actionClickAllowlist = (_b = options.actionClickAllowlist) !== null && _b !== void 0 ? _b : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ACTION_CLICK_ALLOWLIST"];
    options.debounceTime = (_c = options.debounceTime) !== null && _c !== void 0 ? _c : 0;
    var isViewportContentUpdatedEnabled = ((_d = options.viewportContentUpdated) === null || _d === void 0 ? void 0 : _d.enabled) !== false;
    var resolvedExposureDuration = (_g = (_f = (_e = options.viewportContentUpdated) === null || _e === void 0 ? void 0 : _e.exposureDuration) !== null && _f !== void 0 ? _f : options.exposureDuration) !== null && _g !== void 0 ? _g : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_EXPOSURE_DURATION"];
    options.viewportContentUpdated = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, options.viewportContentUpdated), {
        exposureDuration: resolvedExposureDuration
    });
    options.pageUrlExcludelist = (_h = options.pageUrlExcludelist) === null || _h === void 0 ? void 0 : _h.reduce(function(acc, excludePattern) {
        if (typeof excludePattern === 'string') {
            acc.push(excludePattern);
        }
        if (excludePattern instanceof RegExp) {
            acc.push(excludePattern);
        }
        if (typeof excludePattern === 'object' && excludePattern !== null && 'pattern' in excludePattern) {
            try {
                acc.push(new RegExp(excludePattern.pattern));
            } catch (regexError) {
                console.warn("Invalid regex pattern: ".concat(excludePattern.pattern), regexError);
                return acc;
            }
        }
        return acc;
    }, []);
    var name = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PLUGIN_NAME"];
    var type = 'enrichment';
    var subscriptions = [];
    var dataExtractor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$data$2d$extractor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataExtractor"](options, context);
    // Page-level state shared across trackers, emitted in a single Page View End event on beforeunload
    // elementExposedForPage holds the total set of elements seen during the entire page view lifetime
    var elementExposedForPage = new Set();
    // currentElementExposed only holds the set of elements that will be flushed during the next [Amplitude] Viewport Content Updated event
    var currentElementExposed = new Set();
    var beforeUnloadCleanup;
    var createObservables = function() {
        var _a;
        var clickObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClickObservable"])().map(function(click) {
            return dataExtractor.addAdditionalEventProperties(click, 'click', options.cssSelectorAllowlist, dataAttributePrefix);
        }));
        var changeObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
            var _a;
            var handler = function(changeEvent) {
                var enrichedChangeEvent = dataExtractor.addAdditionalEventProperties(changeEvent, 'change', options.cssSelectorAllowlist, dataAttributePrefix);
                observer.next(enrichedChangeEvent);
            };
            /* istanbul ignore next */ (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.document.addEventListener('change', handler, {
                capture: true
            });
            /* istanbul ignore next */ return function() {
                var _a;
                return (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.document.removeEventListener('change', handler);
            };
        }));
        // Create observable for URL changes
        var navigateObservable;
        /* istanbul ignore next */ if (window.navigation) {
            navigateObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
                var handler = function(navigateEvent) {
                    var enrichedNavigateEvent = dataExtractor.addAdditionalEventProperties(navigateEvent, 'navigate', options.cssSelectorAllowlist, dataAttributePrefix);
                    observer.next(enrichedNavigateEvent);
                };
                window.navigation.addEventListener('navigate', handler);
                return function() {
                    window.navigation.removeEventListener('navigate', handler);
                };
            }));
        }
        var mutationObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMutationObservable"])().map(function(mutation) {
            return dataExtractor.addAdditionalEventProperties(mutation, 'mutation', options.cssSelectorAllowlist, dataAttributePrefix);
        }));
        var scrollObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createScrollObservable"])();
        var exposureObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createExposureObservable"])(mutationObservable, options.cssSelectorAllowlist);
        return _a = {}, _a[ObservablesEnum.ChangeObservable] = changeObservable, // [ObservablesEnum.ErrorObservable]: errorObservable,
        _a[ObservablesEnum.ClickObservable] = clickObservable, _a[ObservablesEnum.MutationObservable] = mutationObservable, _a[ObservablesEnum.NavigateObservable] = navigateObservable, _a[ObservablesEnum.ScrollObservable] = scrollObservable, _a[ObservablesEnum.ExposureObservable] = exposureObservable, _a;
    };
    // Group labeled events by event type (eg. click, change)
    var groupedLabeledEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$triggers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupLabeledEventIdsByEventType"])(Object.values((_k = (_j = options.pageActions) === null || _j === void 0 ? void 0 : _j.labeledEvents) !== null && _k !== void 0 ? _k : {}));
    var labeledEventToTriggerMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$triggers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createLabeledEventToTriggerMap"])((_m = (_l = options.pageActions) === null || _l === void 0 ? void 0 : _l.triggers) !== null && _m !== void 0 ? _m : []);
    // Evaluate triggers for the given event by running the actions associated with the matching triggers
    var evaluateTriggers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$triggers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTriggerEvaluator"])(groupedLabeledEvents, labeledEventToTriggerMap, dataExtractor, options);
    // Function to recalculate internal variables when remote config is updated
    var recomputePageActionsData = function(remotePageActions) {
        var _a, _b;
        if (remotePageActions) {
            // Merge remote config with local options
            options.pageActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, options.pageActions), remotePageActions);
            // Recalculate internal variables
            groupedLabeledEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$triggers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupLabeledEventIdsByEventType"])(Object.values((_a = options.pageActions.labeledEvents) !== null && _a !== void 0 ? _a : {}));
            labeledEventToTriggerMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$pageActions$2f$triggers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createLabeledEventToTriggerMap"])((_b = options.pageActions.triggers) !== null && _b !== void 0 ? _b : []);
            // Update evaluateTriggers function
            evaluateTriggers.update(groupedLabeledEvents, labeledEventToTriggerMap, options);
        }
    };
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var pageViewEndFired, lastScroll, shouldTrackEvent, shouldTrackActionClick, allObservables, clickTrackingSubscription, changeSubscription, actionClickSubscription, scrollTracker, trackers, globalScope, handleViewportContentUpdated, handleExposure, beforeUnloadHandler_1, navigateObservable, popstateHandler_1, originalPushState_1, allowlist, actionClickAllowlist, messenger;
            var _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                /* istanbul ignore if */ if (typeof document === 'undefined') {
                    return [
                        2 /*return*/ 
                    ];
                }
                pageViewEndFired = false;
                lastScroll = {
                    maxX: undefined,
                    maxY: undefined
                };
                // Fetch remote config for pageActions in a non-blocking manner
                if (config.fetchRemoteConfig) {
                    if (!config.remoteConfigClient) {
                        // TODO(xinyi): Diagnostics.recordEvent
                        config.loggerProvider.debug('Remote config client is not provided, skipping remote config fetch');
                    } else {
                        config.remoteConfigClient.subscribe('configs.analyticsSDK.pageActions', 'all', function(remoteConfig) {
                            recomputePageActionsData(remoteConfig);
                        });
                    }
                }
                shouldTrackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShouldTrackEvent"])(options, options.cssSelectorAllowlist);
                shouldTrackActionClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShouldTrackEvent"])(options, options.actionClickAllowlist);
                allObservables = createObservables();
                clickTrackingSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackClicks"])({
                    allObservables: allObservables,
                    amplitude: amplitude,
                    shouldTrackEvent: shouldTrackEvent,
                    evaluateTriggers: evaluateTriggers.evaluate.bind(evaluateTriggers)
                });
                subscriptions.push(clickTrackingSubscription);
                changeSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$change$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackChange"])({
                    allObservables: allObservables,
                    getEventProperties: function() {
                        var args = [];
                        for(var _i = 0; _i < arguments.length; _i++){
                            args[_i] = arguments[_i];
                        }
                        return dataExtractor.getEventProperties.apply(dataExtractor, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(args), false), [
                            dataAttributePrefix
                        ], false));
                    },
                    amplitude: amplitude,
                    shouldTrackEvent: shouldTrackEvent,
                    evaluateTriggers: evaluateTriggers.evaluate.bind(evaluateTriggers)
                });
                subscriptions.push(changeSubscription);
                actionClickSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$action$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackActionClick"])({
                    allObservables: allObservables,
                    options: options,
                    getEventProperties: function() {
                        var args = [];
                        for(var _i = 0; _i < arguments.length; _i++){
                            args[_i] = arguments[_i];
                        }
                        return dataExtractor.getEventProperties.apply(dataExtractor, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(args), false), [
                            dataAttributePrefix
                        ], false));
                    },
                    amplitude: amplitude,
                    shouldTrackEvent: shouldTrackEvent,
                    shouldTrackActionClick: shouldTrackActionClick
                });
                if (actionClickSubscription) {
                    subscriptions.push(actionClickSubscription);
                }
                scrollTracker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$scroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackScroll"])({
                    allObservables: allObservables,
                    amplitude: amplitude
                });
                subscriptions.push(scrollTracker);
                trackers = {};
                globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
                handleViewportContentUpdated = function(isPageEnd) {
                    if (isPageEnd && pageViewEndFired) {
                        return;
                    }
                    setTimeout(function() {
                        pageViewEndFired = false;
                    }, 100);
                    pageViewEndFired = true;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$viewport$2d$content$2d$updated$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fireViewportContentUpdated"])({
                        amplitude: amplitude,
                        scrollTracker: scrollTracker,
                        currentElementExposed: currentElementExposed,
                        elementExposedForPage: elementExposedForPage,
                        exposureTracker: trackers.exposure,
                        isPageEnd: isPageEnd,
                        lastScroll: lastScroll
                    });
                };
                handleExposure = function(elementPath) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$viewport$2d$content$2d$updated$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onExposure"])(elementPath, elementExposedForPage, currentElementExposed, handleViewportContentUpdated);
                };
                if (isViewportContentUpdatedEnabled) {
                    trackers.exposure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$exposure$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackExposure"])({
                        allObservables: allObservables,
                        onExposure: handleExposure,
                        dataExtractor: dataExtractor,
                        exposureDuration: resolvedExposureDuration
                    });
                    if (trackers.exposure) {
                        subscriptions.push(trackers.exposure);
                    }
                    beforeUnloadHandler_1 = function() {
                        handleViewportContentUpdated(true);
                    };
                    /* istanbul ignore next */ globalScope === null || globalScope === void 0 ? void 0 : globalScope.addEventListener('beforeunload', beforeUnloadHandler_1);
                    beforeUnloadCleanup = function() {
                        /* istanbul ignore next */ globalScope === null || globalScope === void 0 ? void 0 : globalScope.removeEventListener('beforeunload', beforeUnloadHandler_1);
                    };
                    // Ensure cleanup on teardown as well
                    subscriptions.push({
                        unsubscribe: function() {
                            return beforeUnloadCleanup();
                        }
                    });
                    navigateObservable = allObservables[ObservablesEnum.NavigateObservable];
                    if (navigateObservable) {
                        subscriptions.push(navigateObservable.subscribe(function() {
                            handleViewportContentUpdated(true);
                        }));
                    } else if (globalScope) {
                        popstateHandler_1 = function() {
                            handleViewportContentUpdated(true);
                        };
                        /* istanbul ignore next */ // Fallback for SPA tracking when Navigation API is not available
                        globalScope.addEventListener('popstate', popstateHandler_1);
                        originalPushState_1 = globalScope.history.pushState;
                        if (globalScope.history && originalPushState_1) {
                            // eslint-disable-next-line @typescript-eslint/unbound-method
                            globalScope.history.pushState = new Proxy(originalPushState_1, {
                                apply: function(target, thisArg, _a) {
                                    var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 3), state = _b[0], unused = _b[1], url = _b[2];
                                    target.apply(thisArg, [
                                        state,
                                        unused,
                                        url
                                    ]);
                                    handleViewportContentUpdated(true);
                                }
                            });
                        }
                        subscriptions.push({
                            unsubscribe: function() {
                                /* istanbul ignore next */ globalScope.removeEventListener('popstate', popstateHandler_1);
                                /* istanbul ignore next */ if (globalScope.history && originalPushState_1) {
                                    globalScope.history.pushState = originalPushState_1;
                                }
                            }
                        });
                    }
                }
                /* istanbul ignore next */ (_a = config === null || config === void 0 ? void 0 : config.loggerProvider) === null || _a === void 0 ? void 0 : _a.log("".concat(name, " has been successfully added."));
                // Setup visual tagging and background capture on the shared messenger singleton.
                // Using the singleton ensures a single message listener per page, even when
                // session-replay is also loaded.
                if (window.opener && visualTaggingOptions.enabled) {
                    allowlist = options.cssSelectorAllowlist;
                    actionClickAllowlist = options.actionClickAllowlist;
                    messenger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$base$2d$window$2d$messenger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOrCreateWindowMessenger"])();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$libs$2f$messenger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["enableVisualTagging"])(messenger, {
                        dataExtractor: dataExtractor,
                        isElementSelectable: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShouldTrackEvent"])(options, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(allowlist), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(actionClickAllowlist), false)),
                        cssSelectorAllowlist: allowlist,
                        actionClickAllowlist: actionClickAllowlist
                    });
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$background$2d$capture$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["enableBackgroundCapture"])(messenger);
                    /* istanbul ignore next */ messenger.setup((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
                        logger: config === null || config === void 0 ? void 0 : config.loggerProvider
                    }, (config === null || config === void 0 ? void 0 : config.serverZone) && {
                        endpoint: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$messenger$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AMPLITUDE_ORIGINS_MAP"][config.serverZone]
                    }));
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var subscriptions_1, subscriptions_1_1, subscription;
            var e_1, _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                try {
                    for(subscriptions_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(subscriptions), subscriptions_1_1 = subscriptions_1.next(); !subscriptions_1_1.done; subscriptions_1_1 = subscriptions_1.next()){
                        subscription = subscriptions_1_1.value;
                        subscription.unsubscribe();
                    }
                } catch (e_1_1) {
                    e_1 = {
                        error: e_1_1
                    };
                } finally{
                    try {
                        if (subscriptions_1_1 && !subscriptions_1_1.done && (_a = subscriptions_1.return)) _a.call(subscriptions_1);
                    } finally{
                        if (e_1) throw e_1.error;
                    }
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-dead-click.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackDeadClick",
    ()=>trackDeadClick
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
;
;
var DEAD_CLICK_TIMEOUT = 3000; // 3 seconds to wait for an activity to happen
var CHANGE_EVENTS = [
    'mutation',
    'navigate'
];
function trackDeadClick(_a) {
    var amplitude = _a.amplitude, allObservables = _a.allObservables, getEventProperties = _a.getEventProperties, shouldTrackDeadClick = _a.shouldTrackDeadClick;
    var clickObservable = allObservables.clickObservable, mutationObservable = allObservables.mutationObservable, navigateObservable = allObservables.navigateObservable;
    var filteredClickObservable = clickObservable.filter(function(click) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterOutNonTrackableEvents"])(click) && shouldTrackDeadClick('click', click.closestTrackedAncestor) && click.event.target instanceof Element && click.event.target.closest('a[target="_blank"]') === null && click.event.button === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MouseButton"].LEFT_OR_TOUCH_CONTACT;
    });
    /* istanbul ignore next */ var changeObservables = navigateObservable ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(mutationObservable, navigateObservable) : mutationObservable;
    var clicksAndChangeObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(filteredClickObservable, changeObservables);
    var deadClickTimer = null;
    var deadClickObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asyncMap"])(clicksAndChangeObservable, function(event) {
        if (deadClickTimer && CHANGE_EVENTS.includes(event.type)) {
            // a mutation or navigation means it's not a dead click, so clear the timer
            clearTimeout(deadClickTimer);
            deadClickTimer = null;
            return Promise.resolve(null);
        } else if (event.type === 'click') {
            // if a dead click is already on-deck, return null.
            // this throttles dead clicks events so no more than one dead click event
            // is tracked per every DEAD_CLICK_TIMEOUT ms.
            if (deadClickTimer) {
                return Promise.resolve(null);
            }
            return new Promise(function(resolve) {
                deadClickTimer = setTimeout(function() {
                    resolve(event);
                    deadClickTimer = null;
                }, DEAD_CLICK_TIMEOUT);
            });
        }
        // unreachable code, but needed to satisfy the type checker
        return Promise.resolve(null);
    });
    return deadClickObservable.subscribe(function(actionClick) {
        if (!actionClick) return;
        var deadClickEvent = {
            '[Amplitude] X': actionClick.event.clientX,
            '[Amplitude] Y': actionClick.event.clientY
        };
        amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_ELEMENT_DEAD_CLICKED_EVENT"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, getEventProperties('click', actionClick.closestTrackedAncestor)), deadClickEvent), {
            time: actionClick.timestamp
        });
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-rage-click.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackRageClicks",
    ()=>trackRageClicks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/frustration-interactions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
;
var RAGE_CLICK_THRESHOLD = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_RAGE_CLICK_THRESHOLD"];
var RAGE_CLICK_WINDOW_MS = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_RAGE_CLICK_WINDOW_MS"];
var RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD"];
function addCoordinates(regionBox, click) {
    var _a, _b, _c, _d;
    var _e = click.event, pageX = _e.pageX, pageY = _e.pageY;
    regionBox.yMin = Math.min((_a = regionBox.yMin) !== null && _a !== void 0 ? _a : pageY, pageY);
    regionBox.yMax = Math.max((_b = regionBox.yMax) !== null && _b !== void 0 ? _b : pageY, pageY);
    regionBox.xMin = Math.min((_c = regionBox.xMin) !== null && _c !== void 0 ? _c : pageX, pageX);
    regionBox.xMax = Math.max((_d = regionBox.xMax) !== null && _d !== void 0 ? _d : pageX, pageX);
    regionBox.isOutOfBounds = regionBox.yMax - regionBox.yMin > RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD || regionBox.xMax - regionBox.xMin > RAGE_CLICK_OUT_OF_BOUNDS_THRESHOLD;
}
function getRageClickAnalyticsEvent(clickWindow) {
    /* istanbul ignore if */ if (clickWindow.length === 0) {
        return null;
    }
    var firstClick = clickWindow[0];
    var lastClick = clickWindow[clickWindow.length - 1];
    var rageClickEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
        '[Amplitude] Begin Time': new Date(firstClick.timestamp).toISOString(),
        '[Amplitude] End Time': new Date(lastClick.timestamp).toISOString(),
        '[Amplitude] Duration': lastClick.timestamp - firstClick.timestamp,
        '[Amplitude] Clicks': clickWindow.map(function(click) {
            return {
                X: click.event.pageX,
                Y: click.event.pageY,
                Time: click.timestamp
            };
        }),
        '[Amplitude] Click Count': clickWindow.length
    }, firstClick.targetElementProperties);
    return {
        rageClickEvent: rageClickEvent,
        time: firstClick.timestamp
    };
}
function isClickOutsideRageClickWindow(clickWindow, click) {
    var firstIndex = Math.max(0, clickWindow.length - RAGE_CLICK_THRESHOLD + 1);
    var firstClick = clickWindow[firstIndex];
    return click.timestamp - firstClick.timestamp >= RAGE_CLICK_WINDOW_MS;
}
function isNewElement(clickWindow, click) {
    return clickWindow.length > 0 && clickWindow[clickWindow.length - 1].closestTrackedAncestor !== click.closestTrackedAncestor;
}
function trackRageClicks(_a) {
    var _this = this;
    var amplitude = _a.amplitude, allObservables = _a.allObservables, shouldTrackRageClick = _a.shouldTrackRageClick;
    var clickObservable = allObservables.clickObservable, selectionObservable = allObservables.selectionObservable;
    // Keep track of all clicks within the sliding window
    var clickWindow = [];
    // Keep track of the region box for all clicks, to determine when a rage click is out of bounds
    var clickBoundingBox = {};
    var pendingRageClick = null;
    // helper function to reset the click window and region box
    function resetClickWindow(click) {
        clickWindow = [];
        clickBoundingBox = {};
        if (click) {
            addCoordinates(clickBoundingBox, click);
            clickWindow.push(click);
        }
    }
    var rageClickObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asyncMap"])(clickObservable.filter(function(click) {
        return shouldTrackRageClick('click', click.closestTrackedAncestor);
    }), function(click) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
            var resolutionValue;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                // add this click's coordinates to the bounding box
                addCoordinates(clickBoundingBox, click);
                resolutionValue = null;
                // if current click is:
                //  1. first click in the window
                //  2. on a new element
                //  3. outside the rage click time window
                //  4. out of bounds
                // then start a new click window
                if (clickWindow.length === 0 || isNewElement(clickWindow, click) || isClickOutsideRageClickWindow(clickWindow, click) || clickBoundingBox.isOutOfBounds) {
                    // if there was a previous Rage Click Event on deck, then send it
                    if (pendingRageClick) {
                        resolutionValue = getRageClickAnalyticsEvent(clickWindow);
                    }
                    resetClickWindow(click);
                } else {
                    clickWindow.push(click);
                }
                // if there was a previous Rage Click Event on deck, then resolve it
                if (pendingRageClick) {
                    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                    clearTimeout(pendingRageClick.timerId);
                    pendingRageClick.resolve(resolutionValue);
                    pendingRageClick = null;
                }
                // if we have enough clicks to be a rage click, set a timout to trigger the rage
                // click event after the time threshold is reached.
                // This will be cancelled if a new click is tracked within the time threshold.
                if (clickWindow.length >= RAGE_CLICK_THRESHOLD) {
                    return [
                        2 /*return*/ ,
                        new Promise(function(resolve) {
                            pendingRageClick = {
                                resolve: resolve,
                                timerId: setTimeout(function() {
                                    resolve(getRageClickAnalyticsEvent(clickWindow));
                                }, RAGE_CLICK_WINDOW_MS)
                            };
                        })
                    ];
                }
                return [
                    2 /*return*/ ,
                    null
                ];
            });
        });
    });
    // reset the click window when a selection change occurs
    /* istanbul ignore next */ var selectionSubscription = selectionObservable === null || selectionObservable === void 0 ? void 0 : selectionObservable.subscribe(function() {
        resetClickWindow();
    });
    var rageClickSubscription = rageClickObservable.subscribe(function(data) {
        /* istanbul ignore if */ if (data === null) {
            return;
        }
        amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_ELEMENT_RAGE_CLICKED_EVENT"], data.rageClickEvent, {
            time: data.time
        });
    });
    return {
        unsubscribe: function() {
            rageClickSubscription.unsubscribe();
            /* istanbul ignore next */ selectionSubscription === null || selectionSubscription === void 0 ? void 0 : selectionSubscription.unsubscribe();
        }
    };
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-error-click.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackErrorClicks",
    ()=>trackErrorClicks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
;
;
;
;
var ERROR_CLICK_TIMEOUT = 2000; // 2 seconds to wait for an error to happen
function trackErrorClicks(_a) {
    var amplitude = _a.amplitude, allObservables = _a.allObservables, shouldTrackErrorClick = _a.shouldTrackErrorClick;
    var clickObservable = allObservables.clickObservable, browserErrorObservable = allObservables.browserErrorObservable;
    var filteredClickObservable = clickObservable.filter(function(click) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterOutNonTrackableEvents"])(click) && shouldTrackErrorClick('click', click.closestTrackedAncestor) && click.event.target instanceof Element && click.event.target.closest('a[target="_blank"]') === null && click.event.button === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MouseButton"].LEFT_OR_TOUCH_CONTACT;
    });
    var errorClickTimer = null;
    var latestClickEvent = null;
    var clearClickTimer = function() {
        if (errorClickTimer !== null) {
            clearTimeout(errorClickTimer);
            errorClickTimer = null;
        }
        latestClickEvent = null;
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["merge"])(filteredClickObservable, browserErrorObservable).subscribe(function(event) {
        var _a;
        if (event.type === 'click') {
            clearClickTimer();
            latestClickEvent = event;
            errorClickTimer = setTimeout(clearClickTimer, ERROR_CLICK_TIMEOUT);
            return;
        }
        if (event.type === 'error' && latestClickEvent) {
            amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_ELEMENT_ERROR_CLICKED_EVENT"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((_a = {}, _a['[Amplitude] Kind'] = event.event.kind, _a['[Amplitude] Message'] = event.event.message, _a['[Amplitude] Stack'] = event.event.stack, _a['[Amplitude] Filename'] = event.event.filename, _a['[Amplitude] Line Number'] = event.event.lineNumber, _a['[Amplitude] Column Number'] = event.event.columnNumber, _a), latestClickEvent.targetElementProperties));
            clearClickTimer();
        }
    });
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-thrashed-cursor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createMouseDirectionChangeObservable",
    ()=>createMouseDirectionChangeObservable,
    "createThrashedCursorObservable",
    ()=>createThrashedCursorObservable,
    "trackThrashedCursor",
    ()=>trackThrashedCursor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript) <export default as Observable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
;
;
;
var Direction;
(function(Direction) {
    Direction["INCREASING"] = "increasing";
    Direction["DECREASING"] = "decreasing";
})(Direction || (Direction = {}));
var Axis;
(function(Axis) {
    Axis["X"] = "x";
    Axis["Y"] = "y";
})(Axis || (Axis = {}));
var createMouseDirectionChangeObservable = function(_a) {
    var allWindowObservables = _a.allWindowObservables;
    var mouseMoveObservable = allWindowObservables.mouseMoveObservable;
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var lastPosition = null;
        var xDirection = null;
        var yDirection = null;
        return mouseMoveObservable.subscribe(function(event) {
            var currentPosition = {
                x: event.clientX,
                y: event.clientY
            };
            if (lastPosition === null) {
                lastPosition = currentPosition;
                return;
            }
            if (currentPosition.x > lastPosition.x) {
                if (xDirection === Direction.DECREASING) {
                    observer.next(Axis.X);
                }
                xDirection = Direction.INCREASING;
            } else if (currentPosition.x < lastPosition.x) {
                if (xDirection === Direction.INCREASING) {
                    observer.next(Axis.X);
                }
                xDirection = Direction.DECREASING;
            }
            if (currentPosition.y > lastPosition.y) {
                if (yDirection === Direction.DECREASING) {
                    observer.next(Axis.Y);
                }
                yDirection = Direction.INCREASING;
            } else if (currentPosition.y < lastPosition.y) {
                if (yDirection === Direction.INCREASING) {
                    observer.next(Axis.Y);
                }
                yDirection = Direction.DECREASING;
            }
            lastPosition = currentPosition;
        });
    });
};
function addDirectionChange(directionChangeSeries) {
    var now = +Date.now();
    directionChangeSeries.startTime = directionChangeSeries.startTime || now;
    // add this direction change to the series (fixed length array to avoid memory leaks)
    var changes = directionChangeSeries.changes, changesThreshold = directionChangeSeries.changesThreshold;
    changes.push(now);
    if (changes.length > changesThreshold) changes.shift();
}
// checks if there are enough direction changes within window + threshold
// for it to be considered a thrashed cursor
function isThrashedCursor(directionChanges) {
    var changes = directionChanges.changes, changesThreshold = directionChanges.changesThreshold, thresholdMs = directionChanges.thresholdMs;
    if (changes.length < changesThreshold) return false;
    var delta = changes[changes.length - 1] - changes[0];
    return delta < thresholdMs;
}
function resetDirectionChangeSeries(directionChangeSeries) {
    directionChangeSeries.changes = [];
    directionChangeSeries.startTime = undefined;
}
// if the time between first and last change is greater than the threshold,
// shift the window to the right until it is below the threshold
function adjustWindow(directionChanges) {
    var changes = directionChanges.changes, thresholdMs = directionChanges.thresholdMs;
    // find the first change that is within the threshold
    var leftPtr = 0;
    var lastChange = changes[changes.length - 1];
    for(; leftPtr < changes.length; leftPtr++){
        var delta = lastChange - changes[leftPtr];
        if (delta < thresholdMs) {
            break;
        }
    }
    if (leftPtr === 0) return;
    directionChanges.startTime = changes[leftPtr];
    directionChanges.changes.splice(0, leftPtr);
}
function getPendingThrashedCursor(directionChangesX, directionChangesY) {
    var startTime = undefined;
    if (isThrashedCursor(directionChangesX)) {
        startTime = directionChangesX.startTime;
    }
    if (isThrashedCursor(directionChangesY)) {
        var startTimeY = directionChangesY.startTime;
        if (startTimeY && (!startTime || startTimeY < startTime)) {
            startTime = startTimeY;
        }
    }
    return startTime;
}
var DEFAULT_THRESHOLD = 20;
var DEFAULT_WINDOW_MS = 2000;
var createThrashedCursorObservable = function(_a) {
    var mouseDirectionChangeObservable = _a.mouseDirectionChangeObservable, _b = _a.directionChanges, directionChanges = _b === void 0 ? DEFAULT_THRESHOLD : _b, _c = _a.thresholdMs, thresholdMs = _c === void 0 ? DEFAULT_WINDOW_MS : _c;
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
        var xDirectionChanges = {
            changes: [],
            changesThreshold: directionChanges,
            thresholdMs: thresholdMs
        };
        var yDirectionChanges = {
            changes: [],
            changesThreshold: directionChanges,
            thresholdMs: thresholdMs
        };
        var pendingThrashedCursor = undefined;
        var timer = null;
        function emitPendingThrashedCursor() {
            if (pendingThrashedCursor !== undefined) {
                observer.next(pendingThrashedCursor);
                pendingThrashedCursor = undefined;
                // reset window
                if (timer !== null) clearTimeout(timer);
                resetDirectionChangeSeries(xDirectionChanges);
                resetDirectionChangeSeries(yDirectionChanges);
            }
        }
        return mouseDirectionChangeObservable.subscribe(function(axis) {
            if (timer !== null) clearTimeout(timer);
            addDirectionChange(axis === Axis.X ? xDirectionChanges : yDirectionChanges);
            var nextPendingThrashedCursor = getPendingThrashedCursor(xDirectionChanges, yDirectionChanges);
            if (nextPendingThrashedCursor) {
                // if we're in a thrashed cursor window, debounce it for "thresholdMs" duration
                // this is so that we do not restart the window if more direction changes are
                // detected in this series
                pendingThrashedCursor = pendingThrashedCursor || nextPendingThrashedCursor;
                timer = setTimeout(function() {
                    emitPendingThrashedCursor();
                    timer = null;
                }, thresholdMs);
            } else {
                emitPendingThrashedCursor();
            }
            adjustWindow(xDirectionChanges);
            adjustWindow(yDirectionChanges);
            /* istanbul ignore next */ return function() {
                /* istanbul ignore if */ if (timer !== null) {
                    clearTimeout(timer);
                    timer = null;
                }
            };
        });
    });
};
var trackThrashedCursor = function(_a) {
    var amplitude = _a.amplitude, options = _a.options, allObservables = _a.allObservables, _b = _a.directionChanges, directionChanges = _b === void 0 ? DEFAULT_THRESHOLD : _b, _c = _a.thresholdMs, thresholdMs = _c === void 0 ? DEFAULT_WINDOW_MS : _c;
    var mouseDirectionChangeObservable = createMouseDirectionChangeObservable({
        allWindowObservables: allObservables
    });
    var thrashedCursorObservable = createThrashedCursorObservable({
        mouseDirectionChangeObservable: mouseDirectionChangeObservable,
        directionChanges: directionChanges,
        thresholdMs: thresholdMs
    });
    return thrashedCursorObservable.subscribe(function(time) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUrlAllowed"])(options)) {
            return;
        }
        amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_THRASHED_CURSOR_EVENT"], undefined, {
            time: time
        });
    });
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/frustration-plugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "frustrationPlugin",
    ()=>frustrationPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
/* eslint-disable no-restricted-globals */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/element-interactions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/observable.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zen-observable@0.10.0/node_modules/zen-observable/index.js [app-client] (ecmascript) <export default as Observable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/frustration-interactions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$dead$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-dead-click.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$rage$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-rage-click.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture-plugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/observables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$data$2d$extractor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/data-extractor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$error$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-error-click.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$thrashed$2d$cursor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-thrashed-cursor.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
/**
 * Helper function to extract the css selector allowlist
 * from the frustration interactions options for a specific
 * autocapture feature.
 */ function getCssSelectorAllowlist(options, attribute, defaultAllowlist, enabled) {
    if (!enabled) {
        return [];
    }
    var config = options[attribute];
    if (typeof config === 'object' && config !== null && 'cssSelectorAllowlist' in config && Array.isArray(config.cssSelectorAllowlist)) {
        return config.cssSelectorAllowlist;
    }
    return defaultAllowlist;
}
var MINIMUM_THRASHED_CURSOR_DIRECTION_CHANGES = 5;
var MAXIMUM_THRASHED_CURSOR_THRESHOLD = 4000;
var frustrationPlugin = function(options) {
    var _a;
    if (options === void 0) {
        options = {};
    }
    var name = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FRUSTRATION_PLUGIN_NAME"];
    var type = 'enrichment';
    var subscriptions = [];
    var isErrorClicksEnabled = options.errorClicks !== false;
    // if errorClicks is not defined, disable it
    // change this once it moves out of @experimental
    if (!options.errorClicks) {
        isErrorClicksEnabled = false;
    }
    // Check if each feature is enabled
    var deadClicksEnabled = options.deadClicks !== false && options.deadClicks !== null;
    var rageClicksEnabled = options.rageClicks !== false && options.rageClicks !== null;
    var thrashedCursorEnabled = options.thrashedCursor !== false && options.thrashedCursor !== null;
    if (!options.thrashedCursor) {
        thrashedCursorEnabled = false;
    }
    // Get CSS selectors for enabled features
    var rageCssSelectors = getCssSelectorAllowlist(options, 'rageClicks', __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_RAGE_CLICK_ALLOWLIST"], rageClicksEnabled);
    var deadCssSelectors = getCssSelectorAllowlist(options, 'deadClicks', __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DEAD_CLICK_ALLOWLIST"], deadClicksEnabled);
    var errorCssSelectors = getCssSelectorAllowlist(options, 'errorClicks', __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$frustration$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ERROR_CLICK_ALLOWLIST"], isErrorClicksEnabled);
    var dataAttributePrefix = (_a = options.dataAttributePrefix) !== null && _a !== void 0 ? _a : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DATA_ATTRIBUTE_PREFIX"];
    var dataExtractor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$data$2d$extractor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataExtractor"](options);
    // combine the selector lists from enabled features to determine which clicked elements should be filtered
    var combinedCssSelectors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(new Set((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(rageCssSelectors), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(deadCssSelectors), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(errorCssSelectors), false))), false);
    // Create observables on events on the window
    var createObservables = function() {
        var _a;
        var clickObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClickObservable"])('pointerdown').map(function(click) {
            return dataExtractor.addAdditionalEventProperties(click, 'click', combinedCssSelectors, dataAttributePrefix, true);
        }));
        var browserErrorObservables = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createErrorObservable"])().map(function(error) {
            return dataExtractor.addTypeAndTimestamp(error, 'error');
        }));
        var enrichedMutationObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMutationObservable"])().map(function(mutation) {
            return dataExtractor.addAdditionalEventProperties(mutation, 'mutation', combinedCssSelectors, dataAttributePrefix);
        }));
        var enrichedNavigateObservable;
        if (window.navigation) {
            var navigateObservable = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
                var handler = function(event) {
                    observer.next((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, event), {
                        type: 'navigate'
                    }));
                };
                window.navigation.addEventListener('navigate', handler);
                return function() {
                    window.navigation.removeEventListener('navigate', handler);
                };
            });
            enrichedNavigateObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])(navigateObservable.map(function(navigate) {
                return dataExtractor.addAdditionalEventProperties(navigate, 'navigate', combinedCssSelectors, dataAttributePrefix);
            }));
        }
        var selectionObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zen$2d$observable$40$0$2e$10$2e$0$2f$node_modules$2f$zen$2d$observable$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Observable$3e$__["Observable"](function(observer) {
            var handler = function() {
                var el = document.activeElement;
                // handle input and textarea
                // if the selectionStart and selectionEnd are the same, it means
                // nothing is selected (collapsed) and the cursor position is one point
                if (el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT')) {
                    var start = void 0;
                    var end = void 0;
                    try {
                        start = el.selectionStart;
                        end = el.selectionEnd;
                        if (start === end) return; // collapsed
                    } catch (error) {
                        // input that doesn't support selectionStart/selectionEnd (like checkbox)
                        // do nothing here
                        return;
                    }
                    return observer.next();
                }
                // handle non-input elements
                // non-input elements have an attribute called "isCollapsed" which
                // if true, indicates there "is currently not any text selected"
                // (see https://developer.mozilla.org/en-US/docs/Web/API/Selection/isCollapsed)
                var selection = window.getSelection();
                if (!selection || selection.isCollapsed) return;
                return observer.next();
            };
            window.document.addEventListener('selectionchange', handler);
            return function() {
                window.document.removeEventListener('selectionchange', handler);
            };
        }));
        var mouseMoveObservable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$observable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["multicast"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$observables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMouseMoveObservable"])());
        return _a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObservablesEnum"].ClickObservable] = clickObservable, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObservablesEnum"].MutationObservable] = enrichedMutationObservable, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObservablesEnum"].NavigateObservable] = enrichedNavigateObservable, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObservablesEnum"].BrowserErrorObservable] = browserErrorObservables, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObservablesEnum"].SelectionObservable] = selectionObservable, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ObservablesEnum"].MouseMoveObservable] = mouseMoveObservable, _a;
    };
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var allObservables, shouldTrackRageClick, rageClickSubscription, shouldTrackDeadClick, deadClickSubscription, shouldTrackErrorClick, errorClickSubscription, directionChanges, thresholdMs, thrashedCursorSubscription;
            var _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                /* istanbul ignore if */ if (typeof document === 'undefined') {
                    return [
                        2 /*return*/ 
                    ];
                }
                allObservables = createObservables();
                // Create subscriptions only for enabled features
                if (rageClicksEnabled) {
                    shouldTrackRageClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShouldTrackEvent"])(options, rageCssSelectors);
                    rageClickSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$rage$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackRageClicks"])({
                        allObservables: allObservables,
                        amplitude: amplitude,
                        shouldTrackRageClick: shouldTrackRageClick
                    });
                    subscriptions.push(rageClickSubscription);
                }
                if (deadClicksEnabled) {
                    shouldTrackDeadClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShouldTrackEvent"])(options, deadCssSelectors);
                    deadClickSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$dead$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackDeadClick"])({
                        amplitude: amplitude,
                        allObservables: allObservables,
                        getEventProperties: function(actionType, element) {
                            return dataExtractor.getEventProperties(actionType, element, dataAttributePrefix);
                        },
                        shouldTrackDeadClick: shouldTrackDeadClick
                    });
                    subscriptions.push(deadClickSubscription);
                }
                if (isErrorClicksEnabled) {
                    shouldTrackErrorClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createShouldTrackEvent"])(options, errorCssSelectors);
                    errorClickSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$error$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackErrorClicks"])({
                        amplitude: amplitude,
                        allObservables: allObservables,
                        shouldTrackErrorClick: shouldTrackErrorClick
                    });
                    subscriptions.push(errorClickSubscription);
                }
                if (thrashedCursorEnabled) {
                    directionChanges = void 0, thresholdMs = void 0;
                    if (typeof options.thrashedCursor === 'object') {
                        directionChanges = options.thrashedCursor.directionChanges;
                        thresholdMs = options.thrashedCursor.threshold;
                        if (directionChanges && directionChanges < MINIMUM_THRASHED_CURSOR_DIRECTION_CHANGES) {
                            config.loggerProvider.warn("'thrashedCursor.directionChanges' of ".concat(directionChanges, " is below the minimum of ").concat(MINIMUM_THRASHED_CURSOR_DIRECTION_CHANGES, ", setting to ").concat(MINIMUM_THRASHED_CURSOR_DIRECTION_CHANGES));
                            directionChanges = MINIMUM_THRASHED_CURSOR_DIRECTION_CHANGES;
                        }
                        if (thresholdMs && thresholdMs > MAXIMUM_THRASHED_CURSOR_THRESHOLD) {
                            config.loggerProvider.warn("'thrashedCursor.threshold' of ".concat(thresholdMs, " is above the maximum of ").concat(MAXIMUM_THRASHED_CURSOR_THRESHOLD, ", setting to ").concat(MAXIMUM_THRASHED_CURSOR_THRESHOLD));
                            thresholdMs = MAXIMUM_THRASHED_CURSOR_THRESHOLD;
                        }
                    }
                    thrashedCursorSubscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$thrashed$2d$cursor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackThrashedCursor"])({
                        amplitude: amplitude,
                        options: options,
                        allObservables: allObservables,
                        directionChanges: directionChanges,
                        thresholdMs: thresholdMs
                    });
                    subscriptions.push(thrashedCursorSubscription);
                }
                /* istanbul ignore next */ (_a = config === null || config === void 0 ? void 0 : config.loggerProvider) === null || _a === void 0 ? void 0 : _a.log("".concat(name, " has been successfully added."));
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var subscriptions_1, subscriptions_1_1, subscription;
            var e_1, _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                try {
                    for(subscriptions_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(subscriptions), subscriptions_1_1 = subscriptions_1.next(); !subscriptions_1_1.done; subscriptions_1_1 = subscriptions_1.next()){
                        subscription = subscriptions_1_1.value;
                        subscription.unsubscribe();
                    }
                } catch (e_1_1) {
                    e_1 = {
                        error: e_1_1
                    };
                } finally{
                    try {
                        if (subscriptions_1_1 && !subscriptions_1_1.done && (_a = subscriptions_1.return)) _a.call(subscriptions_1);
                    } finally{
                        if (e_1) throw e_1.error;
                    }
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-long-task.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackMainThreadBlock",
    ()=>trackMainThreadBlock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/helpers.js [app-client] (ecmascript)");
;
;
;
var DEFAULT_DURATION_THRESHOLD = 100; // ms
var MEASURE_BUFFER_WINDOW_MS = 10000;
function getOverlappingMeasures(entry, measures) {
    var taskEnd = entry.startTime + entry.duration;
    return measures.filter(function(measure) {
        return measure.startTime < taskEnd && measure.startTime + measure.duration > entry.startTime;
    }).map(function(measure) {
        return measure.name;
    });
}
function buildLoAFProperties(entry, measures) {
    var _a;
    var overlappingMeasures = getOverlappingMeasures(entry, measures);
    var scripts = (_a = entry.scripts) !== null && _a !== void 0 ? _a : [];
    var scriptURLs = scripts.map(function(s) {
        return s.sourceURL;
    }).filter(Boolean);
    var scriptFunctions = scripts.map(function(s) {
        return s.sourceFunctionName;
    }).filter(Boolean);
    var scriptPositions = scripts.map(function(s) {
        return s.sourceCharPosition;
    }).filter(function(p) {
        return typeof p === 'number' && p >= 0;
    });
    var invokerTypes = scripts.map(function(s) {
        return s.invokerType;
    }).filter(Boolean);
    var invokers = scripts.map(function(s) {
        return s.invoker;
    }).filter(Boolean);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
        '[Amplitude] Main Thread Block Source': 'long-animation-frame',
        '[Amplitude] Main Thread Block Duration': entry.duration,
        '[Amplitude] Main Thread Block Blocking Duration': entry.blockingDuration,
        '[Amplitude] Main Thread Block Start Time': entry.startTime
    }, overlappingMeasures.length > 0 && {
        '[Amplitude] Main Thread Block Measures': overlappingMeasures
    }), {
        '[Amplitude] Main Thread Block Render Start': entry.renderStart,
        '[Amplitude] Main Thread Block Style And Layout Start': entry.styleAndLayoutStart,
        '[Amplitude] Main Thread Block Script Count': scripts.length
    }), scriptURLs.length > 0 && {
        '[Amplitude] Main Thread Block Script URLs': scriptURLs
    }), scriptFunctions.length > 0 && {
        '[Amplitude] Main Thread Block Script Functions': scriptFunctions
    }), scriptPositions.length > 0 && {
        '[Amplitude] Main Thread Block Script Positions': scriptPositions
    }), invokerTypes.length > 0 && {
        '[Amplitude] Main Thread Block Invoker Types': invokerTypes
    }), invokers.length > 0 && {
        '[Amplitude] Main Thread Block Invokers': invokers
    });
}
function buildLongTaskProperties(entry, measures) {
    var _a;
    var overlappingMeasures = getOverlappingMeasures(entry, measures);
    var attribution = (_a = entry.attribution) !== null && _a !== void 0 ? _a : [];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
        '[Amplitude] Main Thread Block Source': 'long-task',
        '[Amplitude] Main Thread Block Duration': entry.duration,
        '[Amplitude] Main Thread Block Blocking Duration': entry.duration,
        '[Amplitude] Main Thread Block Start Time': entry.startTime
    }, overlappingMeasures.length > 0 && {
        '[Amplitude] Main Thread Block Measures': overlappingMeasures
    }), attribution.length > 0 && {
        '[Amplitude] Main Thread Block Attribution': attribution.map(function(a) {
            return a.name;
        })
    });
}
function getSupportedEntryType() {
    /* istanbul ignore next */ if (typeof PerformanceObserver === 'undefined') return null;
    try {
        var supported = PerformanceObserver.supportedEntryTypes;
        if (supported.includes('long-animation-frame')) return 'long-animation-frame';
        if (supported.includes('longtask')) return 'longtask';
    } catch (_a) {
    // ignore
    }
    return null;
}
function trackMainThreadBlock(_a) {
    var amplitude = _a.amplitude, options = _a.options, _b = _a.durationThreshold, durationThreshold = _b === void 0 ? DEFAULT_DURATION_THRESHOLD : _b;
    var entryType = getSupportedEntryType();
    /* istanbul ignore next */ if (!entryType) {
        return {
            unsubscribe: function() {
                return void 0;
            }
        };
    }
    var measures = [];
    var measureObserver = new PerformanceObserver(function(list) {
        var e_1, _a;
        var now = performance.now();
        try {
            for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(list.getEntries()), _c = _b.next(); !_c.done; _c = _b.next()){
                var entry = _c.value;
                measures.push(entry);
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally{
                if (e_1) throw e_1.error;
            }
        }
        var cutoff = now - MEASURE_BUFFER_WINDOW_MS;
        while(measures.length > 0 && measures[0].startTime < cutoff){
            measures.shift();
        }
    });
    try {
        measureObserver.observe({
            entryTypes: [
                'measure'
            ]
        });
    } catch (_c) {
    // measure not supported — continue without it
    }
    var blockObserver = new PerformanceObserver(function(list) {
        var e_2, _a;
        try {
            for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(list.getEntries()), _c = _b.next(); !_c.done; _c = _b.next()){
                var entry = _c.value;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUrlAllowed"])(options)) {
                    return;
                }
                if (entry.duration < durationThreshold) {
                    continue;
                }
                var properties = entryType === 'long-animation-frame' ? buildLoAFProperties(entry, measures) : buildLongTaskProperties(entry, measures);
                amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AMPLITUDE_MAIN_THREAD_BLOCK_EVENT"], properties);
            }
        } catch (e_2_1) {
            e_2 = {
                error: e_2_1
            };
        } finally{
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally{
                if (e_2) throw e_2.error;
            }
        }
    });
    try {
        blockObserver.observe({
            entryTypes: [
                entryType
            ]
        });
    } catch (_d) {
        measureObserver.disconnect();
        return {
            unsubscribe: function() {
                return void 0;
            }
        };
    }
    return {
        unsubscribe: function() {
            blockObserver.disconnect();
            measureObserver.disconnect();
        }
    };
}
}),
"[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/performance-plugin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "performancePlugin",
    ()=>performancePlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/constants.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$long$2d$task$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture/track-long-task.js [app-client] (ecmascript)");
;
;
;
var DEFAULT_DURATION_THRESHOLD = 100; // ms
var performancePlugin = function(options) {
    if (options === void 0) {
        options = {};
    }
    var name = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PERFORMANCE_PLUGIN_NAME"];
    var type = 'enrichment';
    var subscriptions = [];
    var mainThreadBlockEnabled = options.mainThreadBlock === true || typeof options.mainThreadBlock === 'object' && options.mainThreadBlock !== null;
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var durationThreshold, subscription;
            var _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                /* istanbul ignore if */ if (typeof document === 'undefined') {
                    return [
                        2 /*return*/ 
                    ];
                }
                if (mainThreadBlockEnabled) {
                    durationThreshold = DEFAULT_DURATION_THRESHOLD;
                    if (typeof options.mainThreadBlock === 'object' && options.mainThreadBlock.durationThreshold !== undefined) {
                        durationThreshold = options.mainThreadBlock.durationThreshold;
                    }
                    subscription = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2f$track$2d$long$2d$task$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackMainThreadBlock"])({
                        amplitude: amplitude,
                        options: options,
                        durationThreshold: durationThreshold
                    });
                    subscriptions.push(subscription);
                }
                /* istanbul ignore next */ (_a = config === null || config === void 0 ? void 0 : config.loggerProvider) === null || _a === void 0 ? void 0 : _a.log("".concat(name, " performance tracking has been successfully added."));
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var subscriptions_1, subscriptions_1_1, subscription;
            var e_1, _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                try {
                    for(subscriptions_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(subscriptions), subscriptions_1_1 = subscriptions_1.next(); !subscriptions_1_1.done; subscriptions_1_1 = subscriptions_1.next()){
                        subscription = subscriptions_1_1.value;
                        subscription.unsubscribe();
                    }
                } catch (e_1_1) {
                    e_1 = {
                        error: e_1_1
                    };
                } finally{
                    try {
                        if (subscriptions_1_1 && !subscriptions_1_1.done && (_a = subscriptions_1.return)) _a.call(subscriptions_1);
                    } finally{
                        if (e_1) throw e_1.error;
                    }
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
}),
]);

//# sourceMappingURL=0lzq_%40amplitude_plugin-autocapture-browser_lib_esm_1nwk6qi._.js.map