(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/default-tracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAttributionTrackingConfig",
    ()=>getAttributionTrackingConfig,
    "getElementInteractionsConfig",
    ()=>getElementInteractionsConfig,
    "getFormInteractionsConfig",
    ()=>getFormInteractionsConfig,
    "getFrustrationInteractionsConfig",
    ()=>getFrustrationInteractionsConfig,
    "getNetworkTrackingConfig",
    ()=>getNetworkTrackingConfig,
    "getPageViewTrackingConfig",
    ()=>getPageViewTrackingConfig,
    "getPerformanceTrackingConfig",
    ()=>getPerformanceTrackingConfig,
    "isAttributionTrackingEnabled",
    ()=>isAttributionTrackingEnabled,
    "isCustomEnrichmentEnabled",
    ()=>isCustomEnrichmentEnabled,
    "isElementInteractionsEnabled",
    ()=>isElementInteractionsEnabled,
    "isFileDownloadTrackingEnabled",
    ()=>isFileDownloadTrackingEnabled,
    "isFormInteractionTrackingEnabled",
    ()=>isFormInteractionTrackingEnabled,
    "isFrustrationInteractionsEnabled",
    ()=>isFrustrationInteractionsEnabled,
    "isNetworkTrackingEnabled",
    ()=>isNetworkTrackingEnabled,
    "isPageUrlEnrichmentEnabled",
    ()=>isPageUrlEnrichmentEnabled,
    "isPageViewTrackingEnabled",
    ()=>isPageViewTrackingEnabled,
    "isPerformanceTrackingEnabled",
    ()=>isPerformanceTrackingEnabled,
    "isSessionTrackingEnabled",
    ()=>isSessionTrackingEnabled,
    "isWebVitalsEnabled",
    ()=>isWebVitalsEnabled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$environment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/environment.js [app-client] (ecmascript)");
;
;
/**
 * Returns false if autocapture === false or if autocapture[event],
 * otherwise returns true (even if "config.autocapture === undefined")
 */ var isTrackingEnabled = function(autocapture, event) {
    if (typeof autocapture === 'boolean') {
        return autocapture;
    }
    if ((autocapture === null || autocapture === void 0 ? void 0 : autocapture[event]) === false) {
        return false;
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$environment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isChromeExtension"])()) {
        return !!(autocapture === null || autocapture === void 0 ? void 0 : autocapture[event]);
    }
    return true;
};
var isAttributionTrackingEnabled = function(autocapture) {
    return isTrackingEnabled(autocapture, 'attribution');
};
var isFileDownloadTrackingEnabled = function(autocapture) {
    return isTrackingEnabled(autocapture, 'fileDownloads');
};
var isFormInteractionTrackingEnabled = function(autocapture) {
    return isTrackingEnabled(autocapture, 'formInteractions');
};
var isPageViewTrackingEnabled = function(autocapture) {
    return isTrackingEnabled(autocapture, 'pageViews');
};
var isSessionTrackingEnabled = function(autocapture) {
    return isTrackingEnabled(autocapture, 'sessions');
};
var isPageUrlEnrichmentEnabled = function(autocapture) {
    return isTrackingEnabled(autocapture, 'pageUrlEnrichment');
};
var isNetworkTrackingEnabled = function(autocapture) {
    if (typeof autocapture === 'boolean') {
        return autocapture;
    }
    if (typeof autocapture === 'object' && (autocapture.networkTracking === true || typeof autocapture.networkTracking === 'object')) {
        return true;
    }
    return false;
};
var isElementInteractionsEnabled = function(autocapture) {
    if (typeof autocapture === 'boolean') {
        return autocapture;
    }
    if (typeof autocapture === 'object' && (autocapture.elementInteractions === true || typeof autocapture.elementInteractions === 'object')) {
        return true;
    }
    return false;
};
var isWebVitalsEnabled = function(autocapture) {
    if (typeof autocapture === 'boolean') {
        return autocapture;
    }
    if (typeof autocapture === 'object' && autocapture.webVitals === true) {
        return true;
    }
    return false;
};
var isFrustrationInteractionsEnabled = function(autocapture) {
    if (typeof autocapture === 'boolean') {
        return autocapture;
    }
    if (typeof autocapture === 'object' && (autocapture.frustrationInteractions === true || typeof autocapture.frustrationInteractions === 'object')) {
        return true;
    }
    return false;
};
var isPerformanceTrackingEnabled = function(autocapture) {
    if (typeof autocapture === 'object' && (autocapture.performanceTracking === true || typeof autocapture.performanceTracking === 'object')) {
        return true;
    }
    return false;
};
var getPerformanceTrackingConfig = function(config) {
    if (typeof config.autocapture !== 'object') {
        return undefined;
    }
    var performanceTracking = config.autocapture.performanceTracking;
    if (performanceTracking === true) {
        return {
            mainThreadBlock: true
        };
    }
    if (typeof performanceTracking === 'object' && performanceTracking !== null) {
        return performanceTracking;
    }
    return undefined;
};
var isCustomEnrichmentEnabled = function(customEnrichment) {
    if (typeof customEnrichment === 'boolean') {
        return customEnrichment;
    }
    if (typeof customEnrichment === 'object' && customEnrichment !== null && customEnrichment.enabled !== false) {
        return true;
    }
    return false;
};
var getElementInteractionsConfig = function(config) {
    if (isElementInteractionsEnabled(config.autocapture) && typeof config.autocapture === 'object' && typeof config.autocapture.elementInteractions === 'object') {
        return config.autocapture.elementInteractions;
    }
    return undefined;
};
var getFrustrationInteractionsConfig = function(config) {
    if (isFrustrationInteractionsEnabled(config.autocapture) && typeof config.autocapture === 'object' && typeof config.autocapture.frustrationInteractions === 'object') {
        return config.autocapture.frustrationInteractions;
    }
    return undefined;
};
var getNetworkTrackingConfig = function(config) {
    var _a;
    if (isNetworkTrackingEnabled(config.autocapture)) {
        var networkTrackingConfig = void 0;
        if (typeof config.autocapture === 'object' && typeof config.autocapture.networkTracking === 'object') {
            networkTrackingConfig = config.autocapture.networkTracking;
        } else if (config.networkTrackingOptions) {
            networkTrackingConfig = config.networkTrackingOptions;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, networkTrackingConfig), {
            captureRules: (_a = networkTrackingConfig === null || networkTrackingConfig === void 0 ? void 0 : networkTrackingConfig.captureRules) === null || _a === void 0 ? void 0 : _a.map(function(rule) {
                var _a, _b, _c;
                // if URLs and hosts are both set, URLs take precedence over hosts
                if (((_a = rule.urls) === null || _a === void 0 ? void 0 : _a.length) && ((_b = rule.hosts) === null || _b === void 0 ? void 0 : _b.length)) {
                    var hostsString = JSON.stringify(rule.hosts);
                    var urlsString = JSON.stringify(rule.urls);
                    /* istanbul ignore next */ (_c = config.loggerProvider) === null || _c === void 0 ? void 0 : _c.warn("Found network capture rule with both urls='".concat(urlsString, "' and hosts='").concat(hostsString, "' set. ") + "Definition of urls takes precedence over hosts, so ignoring hosts.");
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, rule), {
                        hosts: undefined
                    });
                }
                return rule;
            })
        });
    }
    return;
};
var getPageViewTrackingConfig = function(config) {
    var trackOn = function() {
        return false;
    };
    var trackHistoryChanges = undefined;
    var eventType;
    var pageCounter = config.pageCounter;
    var isDefaultPageViewTrackingEnabled = isPageViewTrackingEnabled(config.defaultTracking);
    if (isDefaultPageViewTrackingEnabled) {
        trackOn = undefined;
        eventType = undefined;
        if (config.defaultTracking && typeof config.defaultTracking === 'object' && config.defaultTracking.pageViews && typeof config.defaultTracking.pageViews === 'object') {
            if ('trackOn' in config.defaultTracking.pageViews) {
                trackOn = config.defaultTracking.pageViews.trackOn;
            }
            if ('trackHistoryChanges' in config.defaultTracking.pageViews) {
                trackHistoryChanges = config.defaultTracking.pageViews.trackHistoryChanges;
            }
            if ('eventType' in config.defaultTracking.pageViews && config.defaultTracking.pageViews.eventType) {
                eventType = config.defaultTracking.pageViews.eventType;
            }
        }
    }
    return {
        trackOn: trackOn,
        trackHistoryChanges: trackHistoryChanges,
        eventType: eventType,
        pageCounter: pageCounter
    };
};
var getAttributionTrackingConfig = function(config) {
    if (isAttributionTrackingEnabled(config.defaultTracking) && config.defaultTracking && typeof config.defaultTracking === 'object' && config.defaultTracking.attribution && typeof config.defaultTracking.attribution === 'object') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, config.defaultTracking.attribution);
    }
    return {};
};
var getFormInteractionsConfig = function(config) {
    if (isFormInteractionTrackingEnabled(config.defaultTracking) && config.defaultTracking && typeof config.defaultTracking === 'object' && typeof config.defaultTracking.formInteractions === 'object') {
        return config.defaultTracking.formInteractions;
    }
    return undefined;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/utils/snippet-helper.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Applies the proxied functions on the proxied amplitude snippet to an instance of the real object.
 * @ignore
 */ __turbopack_context__.s([
    "convertProxyObjectToRealObject",
    ()=>convertProxyObjectToRealObject,
    "isInstanceProxy",
    ()=>isInstanceProxy,
    "runQueuedFunctions",
    ()=>runQueuedFunctions
]);
var runQueuedFunctions = function(instance, queue) {
    convertProxyObjectToRealObject(instance, queue);
};
var convertProxyObjectToRealObject = function(instance, queue) {
    for(var i = 0; i < queue.length; i++){
        var _a = queue[i], name_1 = _a.name, args = _a.args, resolve = _a.resolve;
        var fn = instance && instance[name_1];
        if (typeof fn === 'function') {
            var result = fn.apply(instance, args);
            if (typeof resolve === 'function') {
                resolve(result === null || result === void 0 ? void 0 : result.promise);
            }
        }
    }
    return instance;
};
var isInstanceProxy = function(instance) {
    var instanceProxy = instance;
    return instanceProxy && instanceProxy._q !== undefined;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/version.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VERSION",
    ()=>VERSION
]);
var VERSION = '2.42.5';
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/lib-prefix.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LIBPREFIX",
    ()=>LIBPREFIX
]);
var LIBPREFIX = 'amplitude-ts';
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Context",
    ()=>Context
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$language$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/language.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/version.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$lib$2d$prefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/lib-prefix.js [app-client] (ecmascript)");
;
;
;
;
var BROWSER_PLATFORM = 'Web';
var IP_ADDRESS = '$remote';
var Context = function() {
    function Context() {
        this.name = '@amplitude/plugin-context-browser';
        this.type = 'before';
        this.library = "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$lib$2d$prefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LIBPREFIX"], "/").concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VERSION"]);
        /* istanbul ignore else */ if (typeof navigator !== 'undefined') {
            this.userAgent = navigator.userAgent;
        }
    }
    Context.prototype.setup = function(config) {
        this.config = config;
        return Promise.resolve(undefined);
    };
    Context.prototype.execute = function(context) {
        var _a, _b;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var time, lastEventId, nextEventId, event;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_c) {
                time = new Date().getTime();
                lastEventId = (_a = this.config.lastEventId) !== null && _a !== void 0 ? _a : -1;
                nextEventId = (_b = context.event_id) !== null && _b !== void 0 ? _b : lastEventId + 1;
                this.config.lastEventId = nextEventId;
                if (!context.time) {
                    this.config.lastEventTime = time;
                }
                event = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
                    user_id: this.config.userId,
                    device_id: this.config.deviceId,
                    session_id: this.config.sessionId,
                    time: time
                }, this.config.appVersion && {
                    app_version: this.config.appVersion
                }), this.config.trackingOptions.platform && {
                    platform: BROWSER_PLATFORM
                }), this.config.trackingOptions.language && {
                    language: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$language$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLanguage"])()
                }), this.config.trackingOptions.ipAddress && {
                    ip: IP_ADDRESS
                }), {
                    insert_id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])(),
                    partner_id: this.config.partnerId,
                    plan: this.config.plan
                }), this.config.ingestionMetadata && {
                    ingestion_metadata: {
                        source_name: this.config.ingestionMetadata.sourceName,
                        source_version: this.config.ingestionMetadata.sourceVersion
                    }
                }), context), {
                    event_id: nextEventId,
                    library: this.library,
                    user_agent: this.userAgent
                });
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    return Context;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/storage/local-storage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LocalStorage",
    ()=>LocalStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/browser-storage.js [app-client] (ecmascript)");
;
;
var MAX_ARRAY_LENGTH = 1000;
var LocalStorage = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(LocalStorage, _super);
    function LocalStorage(config) {
        var _this = this;
        var _a, _b;
        var localStorage;
        try {
            localStorage = (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.localStorage;
        } catch (e) {
            (_b = config === null || config === void 0 ? void 0 : config.loggerProvider) === null || _b === void 0 ? void 0 : _b.debug("Failed to access localStorage. error=".concat(JSON.stringify(e)));
            localStorage = undefined;
        }
        _this = _super.call(this, localStorage) || this;
        _this.loggerProvider = config === null || config === void 0 ? void 0 : config.loggerProvider;
        return _this;
    }
    LocalStorage.prototype.set = function(key, value) {
        var _a;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var droppedEventsCount;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        if (!(Array.isArray(value) && value.length > MAX_ARRAY_LENGTH)) return [
                            3 /*break*/ ,
                            2
                        ];
                        droppedEventsCount = value.length - MAX_ARRAY_LENGTH;
                        return [
                            4 /*yield*/ ,
                            _super.prototype.set.call(this, key, value.slice(0, MAX_ARRAY_LENGTH))
                        ];
                    case 1:
                        _b.sent();
                        (_a = this.loggerProvider) === null || _a === void 0 ? void 0 : _a.error("Failed to save ".concat(droppedEventsCount, " events because the queue length exceeded ").concat(MAX_ARRAY_LENGTH, "."));
                        return [
                            3 /*break*/ ,
                            4
                        ];
                    case 2:
                        return [
                            4 /*yield*/ ,
                            _super.prototype.set.call(this, key, value)
                        ];
                    case 3:
                        _b.sent();
                        _b.label = 4;
                    case 4:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    return LocalStorage;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BrowserStorage"]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/storage/session-storage.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SessionStorage",
    ()=>SessionStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/browser-storage.js [app-client] (ecmascript)");
;
;
var SessionStorage = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(SessionStorage, _super);
    function SessionStorage() {
        var _a;
        return _super.call(this, (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.sessionStorage) || this;
    }
    return SessionStorage;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$browser$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BrowserStorage"]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/transports/xhr.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "XHRTransport",
    ()=>XHRTransport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/gzip.js [app-client] (ecmascript)");
;
;
var XHRTransport = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(XHRTransport, _super);
    function XHRTransport(customHeaders) {
        if (customHeaders === void 0) {
            customHeaders = {};
        }
        var _this = _super.call(this) || this;
        _this.state = {
            done: 4
        };
        _this.customHeaders = customHeaders;
        return _this;
    }
    XHRTransport.prototype.send = function(serverUrl, payload, shouldCompressUploadBody) {
        if (shouldCompressUploadBody === void 0) {
            shouldCompressUploadBody = false;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    new Promise(function(resolve, reject) {
                        /* istanbul ignore if */ if (typeof XMLHttpRequest === 'undefined') {
                            reject(new Error('XHRTransport is not supported.'));
                        }
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', serverUrl, true);
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === _this.state.done) {
                                var responseText = xhr.responseText;
                                try {
                                    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                                    resolve(_this.buildResponse(JSON.parse(responseText)));
                                } catch (_a) {
                                    resolve(_this.buildResponse({
                                        code: xhr.status
                                    }));
                                }
                            }
                        };
                        var headers = {
                            'Content-Type': 'application/json',
                            Accept: '*/*'
                        };
                        var bodyString = JSON.stringify(payload);
                        var shouldCompressBody = shouldCompressUploadBody && bodyString.length >= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIN_GZIP_UPLOAD_BODY_SIZE_BYTES"] && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCompressionStreamAvailable"])();
                        var sendBody = function(body) {
                            var e_1, _a;
                            headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, _this.customHeaders), headers);
                            try {
                                for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(Object.entries(headers)), _c = _b.next(); !_c.done; _c = _b.next()){
                                    var _d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_c.value, 2), key = _d[0], value = _d[1];
                                    xhr.setRequestHeader(key, value);
                                }
                            } catch (e_1_1) {
                                e_1 = {
                                    error: e_1_1
                                };
                            } finally{
                                try {
                                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                                } finally{
                                    if (e_1) throw e_1.error;
                                }
                            }
                            xhr.send(body);
                        };
                        var doSend = function() {
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
                                var compressed;
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                                    switch(_a.label){
                                        case 0:
                                            if (!shouldCompressBody) return [
                                                3 /*break*/ ,
                                                2
                                            ];
                                            return [
                                                4 /*yield*/ ,
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compressToGzipArrayBuffer"])(bodyString)
                                            ];
                                        case 1:
                                            compressed = _a.sent();
                                            if (compressed) {
                                                headers['Content-Encoding'] = 'gzip';
                                                sendBody(compressed);
                                            } else {
                                                sendBody(bodyString);
                                            }
                                            return [
                                                3 /*break*/ ,
                                                3
                                            ];
                                        case 2:
                                            sendBody(bodyString);
                                            _a.label = 3;
                                        case 3:
                                            return [
                                                2 /*return*/ 
                                            ];
                                    }
                                });
                            });
                        };
                        doSend().catch(reject);
                    })
                ];
            });
        });
    };
    return XHRTransport;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTransport"]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/transports/fetch.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FetchTransport",
    ()=>FetchTransport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/gzip.js [app-client] (ecmascript)");
;
;
// Temporary browser-specific fetch transport with gzip support.
// TODO: Merge this implementation back into @amplitude/analytics-core FetchTransport
// once React Native SDK supports request body gzip.
var FetchTransport = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(FetchTransport, _super);
    function FetchTransport(customHeaders) {
        if (customHeaders === void 0) {
            customHeaders = {};
        }
        var _this = _super.call(this) || this;
        _this.customHeaders = customHeaders;
        return _this;
    }
    FetchTransport.prototype.send = function(serverUrl, payload, shouldCompressUploadBody) {
        if (shouldCompressUploadBody === void 0) {
            shouldCompressUploadBody = false;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var bodyString, shouldCompressBody, body, headers, compressed, options, response, responseText;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        /* istanbul ignore if */ if (typeof fetch === 'undefined') {
                            throw new Error('FetchTransport is not supported');
                        }
                        bodyString = JSON.stringify(payload);
                        shouldCompressBody = shouldCompressUploadBody && bodyString.length >= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MIN_GZIP_UPLOAD_BODY_SIZE_BYTES"] && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCompressionStreamAvailable"])();
                        body = bodyString;
                        headers = {
                            'Content-Type': 'application/json',
                            Accept: '*/*'
                        };
                        if (!shouldCompressBody) return [
                            3 /*break*/ ,
                            2
                        ];
                        return [
                            4 /*yield*/ ,
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$gzip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compressToGzipArrayBuffer"])(bodyString)
                        ];
                    case 1:
                        compressed = _a.sent();
                        if (compressed) {
                            headers['Content-Encoding'] = 'gzip';
                            body = compressed;
                        }
                        _a.label = 2;
                    case 2:
                        headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, this.customHeaders), headers);
                        options = {
                            headers: headers,
                            body: body,
                            method: 'POST'
                        };
                        return [
                            4 /*yield*/ ,
                            fetch(serverUrl, options)
                        ];
                    case 3:
                        response = _a.sent();
                        return [
                            4 /*yield*/ ,
                            response.text()
                        ];
                    case 4:
                        responseText = _a.sent();
                        try {
                            // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                            return [
                                2 /*return*/ ,
                                this.buildResponse(JSON.parse(responseText))
                            ];
                        } catch (_b) {
                            return [
                                2 /*return*/ ,
                                this.buildResponse({
                                    code: response.status
                                })
                            ];
                        }
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    return FetchTransport;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTransport"]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/transports/send-beacon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SendBeaconTransport",
    ()=>SendBeaconTransport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/transports/base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
/**
 * SendBeacon does not support custom headers (e.g. Content-Encoding: gzip),
 * so request body compression is not applied even when enableRequestBodyCompression is true.
 */ var SendBeaconTransport = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(SendBeaconTransport, _super);
    function SendBeaconTransport() {
        return _super.call(this) || this;
    }
    SendBeaconTransport.prototype.send = function(serverUrl, payload, _enableRequestBodyCompression) {
        if (_enableRequestBodyCompression === void 0) {
            _enableRequestBodyCompression = false;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    new Promise(function(resolve, reject) {
                        var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
                        /* istanbul ignore if */ if (!(globalScope === null || globalScope === void 0 ? void 0 : globalScope.navigator.sendBeacon)) {
                            throw new Error('SendBeaconTransport is not supported');
                        }
                        try {
                            var data = JSON.stringify(payload);
                            // SendBeacon cannot set Content-Encoding, so we always send uncompressed
                            var success = globalScope.navigator.sendBeacon(serverUrl, data);
                            if (success) {
                                return resolve(_this.buildResponse({
                                    code: 200,
                                    events_ingested: payload.events.length,
                                    payload_size_bytes: data.length,
                                    server_upload_time: Date.now()
                                }));
                            }
                            return resolve(_this.buildResponse({
                                code: 500
                            }));
                        } catch (e) {
                            reject(e);
                        }
                    })
                ];
            });
        });
    };
    return SendBeaconTransport;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$transports$2f$base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTransport"]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/cookie-migration/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "decode",
    ()=>decode,
    "parseLegacyCookies",
    ()=>parseLegacyCookies,
    "parseTime",
    ()=>parseTime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$cookie$2d$name$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/cookie-name.js [app-client] (ecmascript)");
;
;
var parseLegacyCookies = function(apiKey, cookieStorage, deleteLegacyCookies) {
    if (deleteLegacyCookies === void 0) {
        deleteLegacyCookies = true;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
        var cookieName, cookies, _a, deviceId, userId, optOut, sessionId, lastEventTime, lastEventId;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
            switch(_b.label){
                case 0:
                    cookieName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$cookie$2d$name$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOldCookieName"])(apiKey);
                    return [
                        4 /*yield*/ ,
                        cookieStorage.getRaw(cookieName)
                    ];
                case 1:
                    cookies = _b.sent();
                    if (!cookies) {
                        return [
                            2 /*return*/ ,
                            {
                                optOut: false
                            }
                        ];
                    }
                    if (!deleteLegacyCookies) return [
                        3 /*break*/ ,
                        3
                    ];
                    return [
                        4 /*yield*/ ,
                        cookieStorage.remove(cookieName)
                    ];
                case 2:
                    _b.sent();
                    _b.label = 3;
                case 3:
                    _a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(cookies.split('.'), 6), deviceId = _a[0], userId = _a[1], optOut = _a[2], sessionId = _a[3], lastEventTime = _a[4], lastEventId = _a[5];
                    return [
                        2 /*return*/ ,
                        {
                            deviceId: deviceId,
                            userId: decode(userId),
                            sessionId: parseTime(sessionId),
                            lastEventId: parseTime(lastEventId),
                            lastEventTime: parseTime(lastEventTime),
                            optOut: Boolean(optOut)
                        }
                    ];
            }
        });
    });
};
var parseTime = function(num) {
    var integer = parseInt(num, 32);
    if (isNaN(integer)) {
        return undefined;
    }
    return integer;
};
var decode = function(value) {
    if (!atob || !escape || !value) {
        return undefined;
    }
    try {
        return decodeURIComponent(escape(atob(value)));
    } catch (_a) {
        return undefined;
    }
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_EVENT_PREFIX",
    ()=>DEFAULT_EVENT_PREFIX,
    "DEFAULT_FILE_DOWNLOAD_EVENT",
    ()=>DEFAULT_FILE_DOWNLOAD_EVENT,
    "DEFAULT_FORM_START_EVENT",
    ()=>DEFAULT_FORM_START_EVENT,
    "DEFAULT_FORM_SUBMIT_EVENT",
    ()=>DEFAULT_FORM_SUBMIT_EVENT,
    "DEFAULT_IDENTITY_STORAGE",
    ()=>DEFAULT_IDENTITY_STORAGE,
    "DEFAULT_PAGE_VIEW_EVENT",
    ()=>DEFAULT_PAGE_VIEW_EVENT,
    "DEFAULT_SERVER_ZONE",
    ()=>DEFAULT_SERVER_ZONE,
    "DEFAULT_SESSION_END_EVENT",
    ()=>DEFAULT_SESSION_END_EVENT,
    "DEFAULT_SESSION_START_EVENT",
    ()=>DEFAULT_SESSION_START_EVENT,
    "FILE_EXTENSION",
    ()=>FILE_EXTENSION,
    "FILE_NAME",
    ()=>FILE_NAME,
    "FORM_DESTINATION",
    ()=>FORM_DESTINATION,
    "FORM_ID",
    ()=>FORM_ID,
    "FORM_NAME",
    ()=>FORM_NAME,
    "LINK_ID",
    ()=>LINK_ID,
    "LINK_TEXT",
    ()=>LINK_TEXT,
    "LINK_URL",
    ()=>LINK_URL
]);
var DEFAULT_EVENT_PREFIX = '[Amplitude]';
var DEFAULT_PAGE_VIEW_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " Page Viewed");
var DEFAULT_FORM_START_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " Form Started");
var DEFAULT_FORM_SUBMIT_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " Form Submitted");
var DEFAULT_FILE_DOWNLOAD_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " File Downloaded");
var DEFAULT_SESSION_START_EVENT = 'session_start';
var DEFAULT_SESSION_END_EVENT = 'session_end';
var FILE_EXTENSION = "".concat(DEFAULT_EVENT_PREFIX, " File Extension");
var FILE_NAME = "".concat(DEFAULT_EVENT_PREFIX, " File Name");
var LINK_ID = "".concat(DEFAULT_EVENT_PREFIX, " Link ID");
var LINK_TEXT = "".concat(DEFAULT_EVENT_PREFIX, " Link Text");
var LINK_URL = "".concat(DEFAULT_EVENT_PREFIX, " Link URL");
var FORM_ID = "".concat(DEFAULT_EVENT_PREFIX, " Form ID");
var FORM_NAME = "".concat(DEFAULT_EVENT_PREFIX, " Form Name");
var FORM_DESTINATION = "".concat(DEFAULT_EVENT_PREFIX, " Form Destination");
var DEFAULT_IDENTITY_STORAGE = 'cookie';
var DEFAULT_SERVER_ZONE = 'US';
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/helpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "KNOWN_2LDS",
    ()=>KNOWN_2LDS,
    "createCampaignEvent",
    ()=>createCampaignEvent,
    "getDefaultExcludedReferrers",
    ()=>getDefaultExcludedReferrers,
    "getDomain",
    ()=>getDomain,
    "isExcludedReferrer",
    ()=>isExcludedReferrer,
    "isNewCampaign",
    ()=>isNewCampaign,
    "isSubdomainOf",
    ()=>isSubdomainOf
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/event-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/identify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$config$2f$browser$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/config/browser-config.js [app-client] (ecmascript)");
;
;
;
var domainWithoutSubdomain = function(domain) {
    var parts = domain.split('.');
    if (parts.length <= 2) {
        return domain;
    }
    return parts.slice(parts.length - 2, parts.length).join('.');
};
//Direct traffic mean no external referral, no UTMs, no click-ids, and no other customer identified marketing campaign url params.
var isDirectTraffic = function(current) {
    return Object.values(current).every(function(value) {
        return !value;
    });
};
var isEmptyCampaign = function(campaign) {
    var campaignWithoutReferrer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, campaign), {
        referring_domain: undefined,
        referrer: undefined
    });
    return Object.values(campaignWithoutReferrer).every(function(value) {
        return !value;
    });
};
var isNewCampaign = function(current, previous, options, logger, isNewSession, topLevelDomain) {
    if (isNewSession === void 0) {
        isNewSession = true;
    }
    var referrer = current.referrer, referring_domain = current.referring_domain, currentCampaign = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__rest"])(current, [
        "referrer",
        "referring_domain"
    ]);
    var _a = previous || {}, _previous_referrer = _a.referrer, prevReferringDomain = _a.referring_domain, previousCampaign = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__rest"])(_a, [
        "referrer",
        "referring_domain"
    ]);
    var excludeInternalReferrers = options.excludeInternalReferrers;
    if (excludeInternalReferrers) {
        var condition = getExcludeInternalReferrersCondition(excludeInternalReferrers, logger);
        if (!(condition instanceof TypeError) && current.referring_domain && isInternalReferrer(current.referring_domain, topLevelDomain)) {
            if (condition === 'always') {
                debugLogInternalReferrerExclude(condition, current.referring_domain, logger);
                return false;
            } else if (condition === 'ifEmptyCampaign' && isEmptyCampaign(current)) {
                debugLogInternalReferrerExclude(condition, current.referring_domain, logger);
                return false;
            }
        }
    }
    if (isExcludedReferrer(options.excludeReferrers, current.referring_domain)) {
        // eslint-disable-next-line @typescript-eslint/restrict-template-expressions
        logger.debug("This is not a new campaign because ".concat(current.referring_domain, " is in the exclude referrer list."));
        return false;
    }
    //In the same session, direct traffic should not override or unset any persisting query params
    if (!isNewSession && isDirectTraffic(current) && previous) {
        logger.debug('This is not a new campaign because this is a direct traffic in the same session.');
        return false;
    }
    var hasNewCampaign = JSON.stringify(currentCampaign) !== JSON.stringify(previousCampaign);
    var hasNewDomain = domainWithoutSubdomain(referring_domain || '') !== domainWithoutSubdomain(prevReferringDomain || '');
    var result = !previous || hasNewCampaign || hasNewDomain;
    if (!result) {
        logger.debug("This is not a new campaign because it's the same as the previous one.");
    } else {
        logger.debug("This is a new campaign. An $identify event will be sent.");
    }
    return result;
};
var isExcludedReferrer = function(excludeReferrers, referringDomain) {
    if (excludeReferrers === void 0) {
        excludeReferrers = [];
    }
    if (referringDomain === void 0) {
        referringDomain = '';
    }
    return excludeReferrers.some(function(value) {
        return value instanceof RegExp ? value.test(referringDomain) : value === referringDomain;
    });
};
var isSubdomainOf = function(subDomain, domain) {
    var cookieDomainWithLeadingDot = domain.startsWith('.') ? domain : ".".concat(domain);
    var subDomainWithLeadingDot = subDomain.startsWith('.') ? subDomain : ".".concat(subDomain);
    if (subDomainWithLeadingDot.endsWith(cookieDomainWithLeadingDot)) return true;
    return false;
};
var createCampaignEvent = function(campaign, options) {
    var campaignParameters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_CAMPAIGN"]), campaign);
    var identifyEvent = Object.entries(campaignParameters).reduce(function(identify, _a) {
        var _b;
        var _c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_a, 2), key = _c[0], value = _c[1];
        identify.setOnce("initial_".concat(key), (_b = value !== null && value !== void 0 ? value : options.initialEmptyValue) !== null && _b !== void 0 ? _b : 'EMPTY');
        if (value) {
            return identify.set(key, value);
        }
        return identify.unset(key);
    }, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Identify"]());
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createIdentifyEvent"])(identifyEvent);
};
var getDefaultExcludedReferrers = function(cookieDomain) {
    var domain = cookieDomain;
    if (domain) {
        if (domain.startsWith('.')) {
            domain = domain.substring(1);
        }
        return [
            new RegExp("".concat(domain.replace('.', '\\.'), "$"))
        ];
    }
    return [];
};
/**
 * Parses the excludeInternalReferrers configuration to determine the condition on which to
 * exclude internal referrers for campaign attribution.
 *
 * If the config is invalid type, log and return a TypeError.
 *
 * (this does explicit type checking so don't have to rely on TS compiler to catch invalid types)
 *
 * @param excludeInternalReferrers - attribution.excludeInternalReferrers configuration
 * @param logger - logger instance to log error when TypeError
 * @returns The condition if the config is valid, TypeError if the config is invalid.
 */ var getExcludeInternalReferrersCondition = function(excludeInternalReferrers, logger) {
    if (excludeInternalReferrers === true) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$config$2f$browser$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXCLUDE_INTERNAL_REFERRERS_CONDITIONS"].always;
    }
    if (typeof excludeInternalReferrers === 'object') {
        var condition = excludeInternalReferrers.condition;
        if (typeof condition === 'string' && Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$config$2f$browser$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXCLUDE_INTERNAL_REFERRERS_CONDITIONS"]).includes(condition)) {
            return condition;
        } else if (typeof condition === 'undefined') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$config$2f$browser$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXCLUDE_INTERNAL_REFERRERS_CONDITIONS"].always;
        }
    }
    var errorMessage = "Invalid configuration provided for attribution.excludeInternalReferrers: ".concat(JSON.stringify(excludeInternalReferrers));
    logger.error(errorMessage);
    return new TypeError(errorMessage);
};
// helper function to log debug message when internal referrer is excluded
// (added this to prevent code duplication and improve readability)
function debugLogInternalReferrerExclude(condition, referringDomain, logger) {
    var baseMessage = "This is not a new campaign because referring_domain=".concat(referringDomain, " is on the same domain as the current page and it is configured to exclude internal referrers");
    if (condition === 'always') {
        logger.debug(baseMessage);
    } else if (condition === 'ifEmptyCampaign') {
        logger.debug("".concat(baseMessage, " with empty campaign parameters"));
    }
}
var KNOWN_2LDS = [
    'ac.in',
    'ac.jp',
    'ac.kr',
    'ac.th',
    'ac.uk',
    'ac.za',
    'appspot.com',
    'asn.au',
    'azurewebsites.net',
    'cloudfront.net',
    'myshopify.com',
    'blogspot.com',
    'co.ca',
    'co.in',
    'co.jp',
    'co.kr',
    'co.nz',
    'co.th',
    'co.uk',
    'co.za',
    'com.ar',
    'com.au',
    'com.br',
    'com.cn',
    'com.hk',
    'com.in',
    'com.jp',
    'com.kr',
    'com.mx',
    'com.pl',
    'com.sg',
    'com.tr',
    'com.tw',
    'ed.jp',
    'edu.au',
    'edu.br',
    'edu.cn',
    'edu.hk',
    'edu.sg',
    'edu.th',
    'edu.tr',
    'edu.tw',
    'firebaseapp.com',
    'fly.dev',
    'gc.ca',
    'geek.nz',
    'github.io',
    'gitlab.io',
    'go.jp',
    'go.kr',
    'go.th',
    'gob.ar',
    'gob.mx',
    'gov.au',
    'gov.br',
    'gov.cn',
    'gov.hk',
    'gov.in',
    'gov.pl',
    'gov.sg',
    'gov.tr',
    'gov.tw',
    'gov.uk',
    'gov.za',
    'govt.nz',
    'gr.jp',
    'herokuapp.com',
    'id.au',
    'idv.hk',
    'iwi.nz',
    'lg.jp',
    'ltd.uk',
    'maori.nz',
    'me.uk',
    'mil.kr',
    'ne.jp',
    'ne.kr',
    'net.au',
    'net.br',
    'net.cn',
    'net.hk',
    'net.in',
    'net.nz',
    'net.pl',
    'net.sg',
    'net.tr',
    'net.tw',
    'net.za',
    'onrender.com',
    'or.jp',
    'or.kr',
    'or.th',
    'org.ar',
    'org.au',
    'org.br',
    'org.cn',
    'org.hk',
    'org.in',
    'org.mx',
    'org.nz',
    'org.pl',
    'org.sg',
    'org.tw',
    'org.uk',
    'org.za',
    'pages.dev',
    'pe.kr',
    'plc.uk',
    're.kr',
    'res.in',
    'sch.uk',
    'vercel.app',
    'netlify.app',
    'workers.dev'
];
var getDomain = function(hostnameParam) {
    var _a, _b;
    /* istanbul ignore next */ var hostname = hostnameParam || ((_b = (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])()) === null || _a === void 0 ? void 0 : _a.location) === null || _b === void 0 ? void 0 : _b.hostname);
    if (!hostname) {
        return '';
    }
    var parts = hostname.split('.');
    var tld = parts[parts.length - 1];
    var name = parts[parts.length - 2];
    if (KNOWN_2LDS.find(function(tld) {
        return hostname.endsWith(".".concat(tld));
    })) {
        tld = parts[parts.length - 2] + '.' + parts[parts.length - 1];
        name = parts[parts.length - 3];
    }
    if (!name) return tld;
    return "".concat(name, ".").concat(tld);
};
var isInternalReferrer = function(referringDomain, topLevelDomain) {
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    /* istanbul ignore if */ if (!globalScope) return false;
    // if referring domain is subdomain of config.cookieDomain, return true
    var internalDomain = (topLevelDomain || '').trim() || getDomain(globalScope.location.hostname);
    return isSubdomainOf(referringDomain, internalDomain);
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BrowserConfig",
    ()=>BrowserConfig,
    "createCookieStorage",
    ()=>createCookieStorage,
    "createTransport",
    ()=>createTransport,
    "getTopLevelDomain",
    ()=>getTopLevelDomain,
    "shouldFetchRemoteConfig",
    ()=>shouldFetchRemoteConfig,
    "useBrowserConfig",
    ()=>useBrowserConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$logger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/logger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$memory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/memory.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/cookie.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$cookie$2d$name$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/cookie-name.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/query-params.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$storage$2f$local$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/storage/local-storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$storage$2f$session$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/storage/session-storage.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$transports$2f$xhr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/transports/xhr.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$transports$2f$fetch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/transports/fetch.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$transports$2f$send$2d$beacon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/transports/send-beacon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$cookie$2d$migration$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/cookie-migration/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/version.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/helpers.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
// Exported for testing purposes only. Do not expose to public interface.
var BrowserConfig = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(BrowserConfig, _super);
    function BrowserConfig(apiKey, appVersion, cookieStorage, cookieOptions, defaultTracking, autocapture, deviceId, flushIntervalMillis, flushMaxRetries, flushQueueSize, identityStorage, ingestionMetadata, instanceName, lastEventId, lastEventTime, loggerProvider, logLevel, minIdLength, offline, optOut, partnerId, plan, serverUrl, serverZone, sessionId, deferredSessionId, sessionTimeout, storageProvider, trackingOptions, transport, useBatch, fetchRemoteConfig, userId, pageCounter, debugLogsEnabled, networkTrackingOptions, identify, enableDiagnostics, diagnosticsSampleRate, diagnosticsClient, remoteConfig, topLevelDomain, enableRequestBodyCompression, customEnrichment) {
        if (cookieStorage === void 0) {
            cookieStorage = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$memory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MemoryStorage"]();
        }
        if (cookieOptions === void 0) {
            cookieOptions = {
                domain: '',
                expiration: 365,
                sameSite: 'Lax',
                secure: false,
                upgrade: true
            };
        }
        if (flushIntervalMillis === void 0) {
            flushIntervalMillis = 1000;
        }
        if (flushMaxRetries === void 0) {
            flushMaxRetries = 5;
        }
        if (flushQueueSize === void 0) {
            flushQueueSize = 30;
        }
        if (identityStorage === void 0) {
            identityStorage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_IDENTITY_STORAGE"];
        }
        if (loggerProvider === void 0) {
            loggerProvider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$logger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logger"]();
        }
        if (logLevel === void 0) {
            logLevel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Warn;
        }
        if (offline === void 0) {
            offline = false;
        }
        if (optOut === void 0) {
            optOut = false;
        }
        if (serverUrl === void 0) {
            serverUrl = '';
        }
        if (serverZone === void 0) {
            serverZone = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SERVER_ZONE"];
        }
        if (sessionTimeout === void 0) {
            sessionTimeout = 30 * 60 * 1000;
        }
        if (storageProvider === void 0) {
            storageProvider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$storage$2f$local$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalStorage"]({
                loggerProvider: loggerProvider
            });
        }
        if (trackingOptions === void 0) {
            trackingOptions = {
                ipAddress: true,
                language: true,
                platform: true
            };
        }
        if (transport === void 0) {
            transport = 'fetch';
        }
        if (useBatch === void 0) {
            useBatch = false;
        }
        if (fetchRemoteConfig === void 0) {
            fetchRemoteConfig = true;
        }
        if (enableDiagnostics === void 0) {
            enableDiagnostics = true;
        }
        if (diagnosticsSampleRate === void 0) {
            diagnosticsSampleRate = 0;
        }
        if (enableRequestBodyCompression === void 0) {
            enableRequestBodyCompression = false;
        }
        var _this = this;
        var _a;
        _this = _super.call(this, {
            apiKey: apiKey,
            storageProvider: storageProvider,
            transportProvider: createTransport(transport)
        }) || this;
        _this.apiKey = apiKey;
        _this.appVersion = appVersion;
        _this.cookieOptions = cookieOptions;
        _this.defaultTracking = defaultTracking;
        _this.autocapture = autocapture;
        _this.flushIntervalMillis = flushIntervalMillis;
        _this.flushMaxRetries = flushMaxRetries;
        _this.flushQueueSize = flushQueueSize;
        _this.identityStorage = identityStorage;
        _this.ingestionMetadata = ingestionMetadata;
        _this.instanceName = instanceName;
        _this.loggerProvider = loggerProvider;
        _this.logLevel = logLevel;
        _this.minIdLength = minIdLength;
        _this.offline = offline;
        _this.partnerId = partnerId;
        _this.plan = plan;
        _this.serverUrl = serverUrl;
        _this.serverZone = serverZone;
        _this.sessionTimeout = sessionTimeout;
        _this.storageProvider = storageProvider;
        _this.trackingOptions = trackingOptions;
        _this.transport = transport;
        _this.useBatch = useBatch;
        _this.fetchRemoteConfig = fetchRemoteConfig;
        _this.networkTrackingOptions = networkTrackingOptions;
        _this.identify = identify;
        _this.enableDiagnostics = enableDiagnostics;
        _this.diagnosticsSampleRate = diagnosticsSampleRate;
        _this.diagnosticsClient = diagnosticsClient;
        _this.remoteConfig = remoteConfig;
        _this.topLevelDomain = topLevelDomain;
        _this.enableRequestBodyCompression = enableRequestBodyCompression;
        _this.customEnrichment = customEnrichment;
        _this.version = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VERSION"];
        _this._optOut = false;
        _this._cookieStorage = cookieStorage;
        _this.deviceId = deviceId;
        _this.lastEventId = lastEventId;
        _this.lastEventTime = lastEventTime;
        _this.optOut = optOut;
        _this.deferredSessionId = deferredSessionId;
        _this.sessionId = sessionId;
        _this.pageCounter = pageCounter;
        _this.userId = userId;
        _this.debugLogsEnabled = debugLogsEnabled;
        _this.loggerProvider.enable(debugLogsEnabled ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Debug : _this.logLevel);
        _this.networkTrackingOptions = networkTrackingOptions;
        _this.identify = identify;
        _this.enableDiagnostics = enableDiagnostics;
        _this.diagnosticsSampleRate = diagnosticsSampleRate;
        _this.diagnosticsClient = diagnosticsClient;
        // Note: The canonical logic for determining fetchRemoteConfig is in shouldFetchRemoteConfig().
        // This logic is duplicated here to maintain the BrowserConfig constructor contract and ensure
        // the config object has the correct fetchRemoteConfig value set on its properties.
        // The value passed to this constructor should already be computed via shouldFetchRemoteConfig().
        var _fetchRemoteConfig = (_a = remoteConfig === null || remoteConfig === void 0 ? void 0 : remoteConfig.fetchRemoteConfig) !== null && _a !== void 0 ? _a : fetchRemoteConfig;
        _this.remoteConfig = _this.remoteConfig || {};
        _this.remoteConfig.fetchRemoteConfig = _fetchRemoteConfig;
        _this.fetchRemoteConfig = _fetchRemoteConfig;
        _this.topLevelDomain = topLevelDomain || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDomain"])();
        return _this;
    }
    Object.defineProperty(BrowserConfig.prototype, "cookieStorage", {
        get: function() {
            return this._cookieStorage;
        },
        set: function(cookieStorage) {
            if (this._cookieStorage !== cookieStorage) {
                this._cookieStorage = cookieStorage;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "deviceId", {
        get: function() {
            return this._deviceId;
        },
        set: function(deviceId) {
            if (this._deviceId !== deviceId) {
                this._deviceId = deviceId;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "userId", {
        get: function() {
            return this._userId;
        },
        set: function(userId) {
            if (this._userId !== userId) {
                this._userId = userId;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "sessionId", {
        get: function() {
            return this._sessionId;
        },
        set: function(sessionId) {
            if (this._sessionId !== sessionId) {
                this._sessionId = sessionId;
                // Clear deferredSessionId when sessionId is set to prevent stale values
                // from overriding legitimate sessionIds on subsequent page loads
                if (sessionId !== undefined && this._deferredSessionId !== undefined) {
                    this._deferredSessionId = undefined;
                }
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "deferredSessionId", {
        get: function() {
            return this._deferredSessionId;
        },
        set: function(deferredSessionId) {
            if (this._deferredSessionId !== deferredSessionId && deferredSessionId !== this.sessionId) {
                this._deferredSessionId = deferredSessionId;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "optOut", {
        get: function() {
            return this._optOut;
        },
        set: function(optOut) {
            if (this._optOut !== optOut) {
                this._optOut = optOut;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "lastEventTime", {
        get: function() {
            return this._lastEventTime;
        },
        set: function(lastEventTime) {
            if (this._lastEventTime !== lastEventTime) {
                this._lastEventTime = lastEventTime;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "lastEventId", {
        get: function() {
            return this._lastEventId;
        },
        set: function(lastEventId) {
            if (this._lastEventId !== lastEventId) {
                this._lastEventId = lastEventId;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "pageCounter", {
        get: function() {
            return this._pageCounter;
        },
        set: function(pageCounter) {
            if (this._pageCounter !== pageCounter) {
                this._pageCounter = pageCounter;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(BrowserConfig.prototype, "debugLogsEnabled", {
        set: function(debugLogsEnabled) {
            if (this._debugLogsEnabled !== debugLogsEnabled) {
                this._debugLogsEnabled = debugLogsEnabled;
                this.updateStorage();
            }
        },
        enumerable: false,
        configurable: true
    });
    BrowserConfig.prototype.updateStorage = function() {
        var cache = {
            deviceId: this._deviceId,
            userId: this._userId,
            sessionId: this._sessionId,
            deferredSessionId: this._deferredSessionId,
            optOut: this._optOut,
            lastEventTime: this._lastEventTime,
            lastEventId: this._lastEventId,
            pageCounter: this._pageCounter,
            debugLogsEnabled: this._debugLogsEnabled,
            cookieDomain: undefined
        };
        if (this.cookieStorage instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CookieStorage"]) {
            cache.cookieDomain = this.cookieStorage.options.domain;
        }
        void this.cookieStorage.set((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$cookie$2d$name$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCookieName"])(this.apiKey), cache);
    };
    return BrowserConfig;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Config"]);
;
var useBrowserConfig = function(apiKey, options, amplitudeInstance, diagnosticsClient, earlyConfig) {
    if (options === void 0) {
        options = {};
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
        var identityStorage, defaultCookieDomain, cookieOptions, cookieConfig, cookieStorage, legacyCookies, previousCookies, queryParams, ampTimestamp, isWithinTimeLimit, deviceId, lastEventId, lastEventTime, optOut, sessionId, deferredSessionId, userId, trackingOptions, pageCounter, debugLogsEnabled, browserConfig;
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_6) {
            switch(_6.label){
                case 0:
                    identityStorage = options.identityStorage || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_IDENTITY_STORAGE"];
                    defaultCookieDomain = '';
                    if (!(identityStorage === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_IDENTITY_STORAGE"] && !((_a = options.cookieOptions) === null || _a === void 0 ? void 0 : _a.domain) && ((_b = options.cookieOptions) === null || _b === void 0 ? void 0 : _b.domain) !== '')) return [
                        3 /*break*/ ,
                        2
                    ];
                    return [
                        4 /*yield*/ ,
                        getTopLevelDomain(undefined, diagnosticsClient)
                    ];
                case 1:
                    defaultCookieDomain = _6.sent();
                    _6.label = 2;
                case 2:
                    cookieOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
                        domain: (_d = (_c = options.cookieOptions) === null || _c === void 0 ? void 0 : _c.domain) !== null && _d !== void 0 ? _d : defaultCookieDomain,
                        expiration: 365,
                        sameSite: 'Lax',
                        secure: false,
                        upgrade: true
                    }, options.cookieOptions);
                    cookieConfig = {
                        // if more than one cookie with the same key exists,
                        // look for the cookie that has the domain attribute set to cookieOptions.domain
                        duplicateResolverFn: function(value) {
                            var decodedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeCookieValue"])(value);
                            if (!decodedValue) {
                                return false;
                            }
                            var parsed = JSON.parse(decodedValue);
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDomainEqual"])(parsed.cookieDomain, cookieOptions.domain);
                        },
                        diagnosticsClient: diagnosticsClient
                    };
                    cookieStorage = createCookieStorage(options.identityStorage, cookieOptions, cookieConfig);
                    return [
                        4 /*yield*/ ,
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$cookie$2d$migration$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseLegacyCookies"])(apiKey, cookieStorage, (_f = (_e = options.cookieOptions) === null || _e === void 0 ? void 0 : _e.upgrade) !== null && _f !== void 0 ? _f : true)
                    ];
                case 3:
                    legacyCookies = _6.sent();
                    return [
                        4 /*yield*/ ,
                        cookieStorage.get((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$cookie$2d$name$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCookieName"])(apiKey))
                    ];
                case 4:
                    previousCookies = _6.sent();
                    queryParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getQueryParams"])();
                    ampTimestamp = queryParams.ampTimestamp ? Number(queryParams.ampTimestamp) : undefined;
                    isWithinTimeLimit = ampTimestamp ? Date.now() < ampTimestamp : true;
                    deviceId = (_l = (_k = (_j = (_g = options.deviceId) !== null && _g !== void 0 ? _g : isWithinTimeLimit ? (_h = queryParams.ampDeviceId) !== null && _h !== void 0 ? _h : queryParams.deviceId : undefined) !== null && _j !== void 0 ? _j : previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.deviceId) !== null && _k !== void 0 ? _k : legacyCookies.deviceId) !== null && _l !== void 0 ? _l : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])();
                    lastEventId = (_m = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.lastEventId) !== null && _m !== void 0 ? _m : legacyCookies.lastEventId;
                    lastEventTime = (_o = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.lastEventTime) !== null && _o !== void 0 ? _o : legacyCookies.lastEventTime;
                    optOut = (_q = (_p = options.optOut) !== null && _p !== void 0 ? _p : previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.optOut) !== null && _q !== void 0 ? _q : legacyCookies.optOut;
                    sessionId = (_r = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.sessionId) !== null && _r !== void 0 ? _r : legacyCookies.sessionId;
                    deferredSessionId = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.deferredSessionId;
                    userId = (_t = (_s = options.userId) !== null && _s !== void 0 ? _s : previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.userId) !== null && _t !== void 0 ? _t : legacyCookies.userId;
                    amplitudeInstance.previousSessionDeviceId = (_u = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.deviceId) !== null && _u !== void 0 ? _u : legacyCookies.deviceId;
                    amplitudeInstance.previousSessionUserId = (_v = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.userId) !== null && _v !== void 0 ? _v : legacyCookies.userId;
                    trackingOptions = {
                        ipAddress: (_x = (_w = options.trackingOptions) === null || _w === void 0 ? void 0 : _w.ipAddress) !== null && _x !== void 0 ? _x : true,
                        language: (_z = (_y = options.trackingOptions) === null || _y === void 0 ? void 0 : _y.language) !== null && _z !== void 0 ? _z : true,
                        platform: (_1 = (_0 = options.trackingOptions) === null || _0 === void 0 ? void 0 : _0.platform) !== null && _1 !== void 0 ? _1 : true
                    };
                    pageCounter = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.pageCounter;
                    debugLogsEnabled = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.debugLogsEnabled;
                    // Override default tracking options if autocapture is set
                    if (options.autocapture !== undefined) {
                        options.defaultTracking = options.autocapture;
                    }
                    browserConfig = new BrowserConfig(apiKey, options.appVersion, cookieStorage, cookieOptions, options.defaultTracking, options.autocapture, deviceId, options.flushIntervalMillis, options.flushMaxRetries, options.flushQueueSize, identityStorage, options.ingestionMetadata, options.instanceName, lastEventId, lastEventTime, // Use earlyConfig.loggerProvider to ensure consistent logger across DiagnosticsClient/RemoteConfigClient/BrowserConfig
                    (_2 = earlyConfig === null || earlyConfig === void 0 ? void 0 : earlyConfig.loggerProvider) !== null && _2 !== void 0 ? _2 : options.loggerProvider, options.logLevel, options.minIdLength, options.offline, optOut, options.partnerId, options.plan, options.serverUrl, // Use earlyConfig.serverZone to ensure consistent serverZone
                    (_3 = earlyConfig === null || earlyConfig === void 0 ? void 0 : earlyConfig.serverZone) !== null && _3 !== void 0 ? _3 : options.serverZone, sessionId, deferredSessionId, options.sessionTimeout, options.storageProvider, trackingOptions, options.transport, options.useBatch, options.fetchRemoteConfig, userId, pageCounter, debugLogsEnabled, options.networkTrackingOptions, options.identify, // Use earlyConfig values (already has remote config applied), otherwise fall back to options
                    (_4 = earlyConfig === null || earlyConfig === void 0 ? void 0 : earlyConfig.enableDiagnostics) !== null && _4 !== void 0 ? _4 : options.enableDiagnostics, (_5 = earlyConfig === null || earlyConfig === void 0 ? void 0 : earlyConfig.diagnosticsSampleRate) !== null && _5 !== void 0 ? _5 : amplitudeInstance._diagnosticsSampleRate, diagnosticsClient, options.remoteConfig, defaultCookieDomain, options.enableRequestBodyCompression, options.customEnrichment);
                    return [
                        4 /*yield*/ ,
                        browserConfig.storageProvider.isEnabled()
                    ];
                case 5:
                    if (!_6.sent()) {
                        browserConfig.loggerProvider.warn("Storage provider ".concat(browserConfig.storageProvider.constructor.name, " is not enabled. Falling back to MemoryStorage."));
                        browserConfig.storageProvider = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$memory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MemoryStorage"]();
                    }
                    return [
                        2 /*return*/ ,
                        browserConfig
                    ];
            }
        });
    });
};
var createCookieStorage = function(identityStorage, cookieOptions, cookieConfig) {
    if (identityStorage === void 0) {
        identityStorage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_IDENTITY_STORAGE"];
    }
    if (cookieOptions === void 0) {
        cookieOptions = {};
    }
    switch(identityStorage){
        case 'localStorage':
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$storage$2f$local$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LocalStorage"]();
        case 'sessionStorage':
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$storage$2f$session$2d$storage$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SessionStorage"]();
        case 'none':
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$memory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MemoryStorage"]();
        case 'cookie':
        default:
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CookieStorage"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, cookieOptions), {
                expirationDays: cookieOptions.expiration
            }), cookieConfig);
    }
};
var shouldFetchRemoteConfig = function(options) {
    var _a, _b;
    if (options === void 0) {
        options = {};
    }
    if (((_a = options.remoteConfig) === null || _a === void 0 ? void 0 : _a.fetchRemoteConfig) === true) {
        // set to true if remoteConfig explicitly set to true
        return true;
    } else if (((_b = options.remoteConfig) === null || _b === void 0 ? void 0 : _b.fetchRemoteConfig) === false || options.fetchRemoteConfig === false) {
        // set to false if either are set to false explicitly
        return false;
    } else {
        // default to true if both undefined
        return true;
    }
};
var createTransport = function(transport) {
    var type = typeof transport === 'object' ? transport.type : transport;
    var headers = typeof transport === 'object' ? transport.headers : undefined;
    if (type === 'xhr') {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$transports$2f$xhr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XHRTransport"](headers);
    }
    if (type === 'beacon') {
        // SendBeacon does not support custom headers
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$transports$2f$send$2d$beacon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendBeaconTransport"]();
    }
    // Keep a browser-local fetch transport for gzip support.
    // TODO: Merge back to core FetchTransport after React Native supports gzip.
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$transports$2f$fetch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FetchTransport"](headers);
};
var getTopLevelDomain = function(url, diagnosticsClient) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
        var host, parts, levels, skipLevel, i, i, domain, result, e_1;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
            switch(_a.label){
                case 0:
                    return [
                        4 /*yield*/ ,
                        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CookieStorage"](undefined, {
                            diagnosticsClient: diagnosticsClient
                        }).isEnabled()
                    ];
                case 1:
                    if (!_a.sent() || !url && (typeof location === 'undefined' || !location.hostname)) {
                        return [
                            2 /*return*/ ,
                            ''
                        ];
                    }
                    host = url !== null && url !== void 0 ? url : location.hostname;
                    parts = host.split('.');
                    // if hostname has less than 2 parts, it's not a registrable domain
                    // and the browser won't allow setting domain-scoped cookies for it so return empty string
                    if (parts.length === 1) {
                        return [
                            2 /*return*/ ,
                            ''
                        ];
                    }
                    levels = [];
                    skipLevel = 1;
                    // if the hostname ends with a TLD we know is in the Public Suffix List
                    // then the last two parts are definitely not writable as a domain
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KNOWN_2LDS"].find(function(tld) {
                        return host.endsWith(".".concat(tld));
                    })) {
                        skipLevel = 2;
                    }
                    for(i = parts.length - skipLevel - 1; i >= 0; --i){
                        levels.push(parts.slice(i).join('.'));
                    }
                    i = 0;
                    _a.label = 2;
                case 2:
                    if (!(i < levels.length)) return [
                        3 /*break*/ ,
                        7
                    ];
                    domain = levels[i];
                    _a.label = 3;
                case 3:
                    _a.trys.push([
                        3,
                        5,
                        ,
                        6
                    ]);
                    return [
                        4 /*yield*/ ,
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$cookie$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CookieStorage"].isDomainWritable(domain)
                    ];
                case 4:
                    result = _a.sent();
                    // if the transaction succeeded, the domain is valid
                    if (result) {
                        return [
                            2 /*return*/ ,
                            '.' + domain
                        ];
                    }
                    return [
                        3 /*break*/ ,
                        6
                    ];
                case 5:
                    e_1 = _a.sent();
                    /* istanbul ignore if */ if (diagnosticsClient) {
                        diagnosticsClient.recordEvent('cookies.tld.failure', {
                            reason: "Unexpected exception checking domain is writable: ".concat(domain),
                            error: e_1 instanceof Error ? e_1.message : String(e_1)
                        });
                    }
                    return [
                        3 /*break*/ ,
                        6
                    ];
                case 6:
                    i++;
                    return [
                        3 /*break*/ ,
                        2
                    ];
                case 7:
                    // if the transaction failed, the domain is invalid
                    // record a diagnostic event
                    if (diagnosticsClient) {
                        diagnosticsClient.recordEvent('cookies.tld.failure', {
                            reason: "Could not determine TLD for host ".concat(host)
                        });
                    }
                    // return an empty string to indicate that we couldn't determine the TLD
                    // so fallback to host-only cookies (scoped to the current host)
                    return [
                        2 /*return*/ ,
                        ''
                    ];
            }
        });
    });
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/form-interaction-tracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "extractFormAction",
    ()=>extractFormAction,
    "formInteractionTracking",
    ()=>formInteractionTracking,
    "stringOrUndefined",
    ()=>stringOrUndefined
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/default-tracking.js [app-client] (ecmascript)");
;
;
;
;
var formInteractionTracking = function() {
    var observer;
    var eventListeners = [];
    var addEventListener = function(element, type, handler) {
        element.addEventListener(type, handler);
        eventListeners.push({
            element: element,
            type: type,
            handler: handler
        });
    };
    var removeClickListeners = function() {
        eventListeners.forEach(function(_a) {
            var element = _a.element, type = _a.type, handler = _a.handler;
            /* istanbul ignore next */ element === null || element === void 0 ? void 0 : element.removeEventListener(type, handler);
        });
        eventListeners = [];
    };
    var formInteractionsConfig;
    var name = '@amplitude/plugin-form-interaction-tracking-browser';
    var type = 'enrichment';
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var initializeFormTracking, window_1;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                formInteractionsConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFormInteractionsConfig"])(config);
                initializeFormTracking = function() {
                    /* istanbul ignore if */ if (!amplitude) {
                        // TODO: Add required minimum version of @amplitude/analytics-browser
                        config.loggerProvider.warn('Form interaction tracking requires a later version of @amplitude/analytics-browser. Form interaction events are not tracked.');
                        return;
                    }
                    /* istanbul ignore if */ if (typeof document === 'undefined') {
                        return;
                    }
                    var addedFormNodes = new WeakSet();
                    var addFormInteractionListener = function(form) {
                        if (addedFormNodes.has(form)) {
                            return;
                        }
                        addedFormNodes.add(form);
                        var hasFormChanged = false;
                        addEventListener(form, 'change', function() {
                            var _a;
                            var formDestination = extractFormAction(form);
                            if (!hasFormChanged) {
                                amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FORM_START_EVENT"], (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_ID"]] = stringOrUndefined(form.id), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_NAME"]] = stringOrUndefined(form.name), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_DESTINATION"]] = formDestination, _a));
                            }
                            hasFormChanged = true;
                        });
                        addEventListener(form, 'submit', function(event) {
                            var _a, _b;
                            var formDestination = extractFormAction(form);
                            if (!hasFormChanged) {
                                amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FORM_START_EVENT"], (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_ID"]] = stringOrUndefined(form.id), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_NAME"]] = stringOrUndefined(form.name), _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_DESTINATION"]] = formDestination, _a));
                            }
                            hasFormChanged = true;
                            // Check if shouldTrackSubmit callback is provided and use it to determine whether to track form_submit
                            if ((formInteractionsConfig === null || formInteractionsConfig === void 0 ? void 0 : formInteractionsConfig.shouldTrackSubmit) !== undefined) {
                                if (typeof formInteractionsConfig.shouldTrackSubmit === 'function' && typeof SubmitEvent !== 'undefined' && event instanceof SubmitEvent) {
                                    try {
                                        var shouldTrack = formInteractionsConfig.shouldTrackSubmit(event);
                                        if (!shouldTrack) {
                                            return;
                                        }
                                    } catch (e) {
                                        config.loggerProvider.warn('shouldTrackSubmit callback threw an error, proceeding with tracking.');
                                    }
                                } else {
                                    config.loggerProvider.warn('shouldTrackSubmit is ignored because it is not a function or event is not a SubmitEvent.');
                                }
                            }
                            amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FORM_SUBMIT_EVENT"], (_b = {}, _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_ID"]] = stringOrUndefined(form.id), _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_NAME"]] = stringOrUndefined(form.name), _b[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORM_DESTINATION"]] = formDestination, _b));
                            hasFormChanged = false;
                        });
                    };
                    // Adds listener to existing anchor tags
                    var forms = Array.from(document.getElementsByTagName('form'));
                    forms.forEach(addFormInteractionListener);
                    // Adds listener to anchor tags added after initial load
                    /* istanbul ignore else */ if (typeof MutationObserver !== 'undefined') {
                        observer = new MutationObserver(function(mutations) {
                            mutations.forEach(function(mutation) {
                                mutation.addedNodes.forEach(function(node) {
                                    if (node.nodeName === 'FORM') {
                                        addFormInteractionListener(node);
                                    }
                                    if ('querySelectorAll' in node && typeof node.querySelectorAll === 'function') {
                                        Array.from(node.querySelectorAll('form')).map(addFormInteractionListener);
                                    }
                                });
                            });
                        });
                        observer.observe(document.body, {
                            subtree: true,
                            childList: true
                        });
                    }
                };
                // If the document is already loaded, initialize immediately.
                if (document.readyState === 'complete') {
                    initializeFormTracking();
                } else {
                    window_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
                    /* istanbul ignore else*/ if (window_1) {
                        window_1.addEventListener('load', initializeFormTracking);
                    } else {
                        config.loggerProvider.debug('Form interaction tracking is not installed because global is undefined.');
                    }
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                observer === null || observer === void 0 ? void 0 : observer.disconnect();
                removeClickListeners();
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
var stringOrUndefined = function(name) {
    /* istanbul ignore if */ if (typeof name !== 'string') {
        // We found instances where the value of `name` is an Element and not a string.
        // Elements may have circular references and would throw an error when passed to `JSON.stringify(...)`.
        // If a non-string value is seen, assume there is no value.
        return undefined;
    }
    return name;
};
var extractFormAction = function(form) {
    var formDestination = form.getAttribute('action');
    try {
        // eslint-disable-next-line no-restricted-globals
        formDestination = new URL(encodeURI(formDestination !== null && formDestination !== void 0 ? formDestination : ''), window.location.href).href;
    } catch (_a) {
    //
    }
    return formDestination;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/file-download-tracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fileDownloadTracking",
    ()=>fileDownloadTracking
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
;
var fileDownloadTracking = function() {
    var observer;
    var eventListeners = [];
    var addEventListener = function(element, type, handler) {
        element.addEventListener(type, handler);
        eventListeners.push({
            element: element,
            type: type,
            handler: handler
        });
    };
    var removeClickListeners = function() {
        eventListeners.forEach(function(_a) {
            var element = _a.element, type = _a.type, handler = _a.handler;
            /* istanbul ignore next */ element === null || element === void 0 ? void 0 : element.removeEventListener(type, handler);
        });
        eventListeners = [];
    };
    var name = '@amplitude/plugin-file-download-tracking-browser';
    var type = 'enrichment';
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            var initializeFileDownloadTracking, window_1;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                initializeFileDownloadTracking = function() {
                    /* istanbul ignore if */ if (!amplitude) {
                        // TODO: Add required minimum version of @amplitude/analytics-browser
                        config.loggerProvider.warn('File download tracking requires a later version of @amplitude/analytics-browser. File download events are not tracked.');
                        return;
                    }
                    /* istanbul ignore if */ if (typeof document === 'undefined') {
                        return;
                    }
                    var addFileDownloadListener = function(a) {
                        var url;
                        try {
                            // eslint-disable-next-line no-restricted-globals
                            url = new URL(a.href, window.location.href);
                        } catch (_a) {
                            /* istanbul ignore next */ return;
                        }
                        var result = ext.exec(url.href);
                        var fileExtension = result === null || result === void 0 ? void 0 : result[1];
                        if (fileExtension) {
                            addEventListener(a, 'click', function() {
                                var _a;
                                if (fileExtension) {
                                    amplitude.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FILE_DOWNLOAD_EVENT"], (_a = {}, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FILE_EXTENSION"]] = fileExtension, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FILE_NAME"]] = url.pathname, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LINK_ID"]] = a.id, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LINK_TEXT"]] = a.text, _a[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LINK_URL"]] = a.href, _a));
                                }
                            });
                        }
                    };
                    var ext = /\.(pdf|xlsx?|docx?|txt|rtf|csv|exe|key|pp(s|t|tx)|7z|pkg|rar|gz|zip|avi|mov|mp4|mpe?g|wmv|midi?|mp3|wav|wma)(\?.+)?$/;
                    // Adds listener to existing anchor tags
                    var links = Array.from(document.getElementsByTagName('a'));
                    links.forEach(addFileDownloadListener);
                    // Adds listener to anchor tags added after initial load
                    /* istanbul ignore else */ if (typeof MutationObserver !== 'undefined') {
                        observer = new MutationObserver(function(mutations) {
                            mutations.forEach(function(mutation) {
                                mutation.addedNodes.forEach(function(node) {
                                    if (node.nodeName === 'A') {
                                        addFileDownloadListener(node);
                                    }
                                    if ('querySelectorAll' in node && typeof node.querySelectorAll === 'function') {
                                        Array.from(node.querySelectorAll('a')).map(addFileDownloadListener);
                                    }
                                });
                            });
                        });
                        observer.observe(document.body, {
                            subtree: true,
                            childList: true
                        });
                    }
                };
                // If the document is already loaded, initialize immediately.
                /* istanbul ignore else*/ if (document.readyState === 'complete') {
                    initializeFileDownloadTracking();
                } else {
                    window_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
                    /* istanbul ignore else*/ if (window_1) {
                        window_1.addEventListener('load', initializeFileDownloadTracking);
                    } else {
                        config.loggerProvider.debug('File download tracking is not installed because global is undefined.');
                    }
                }
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var execute = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                return [
                    2 /*return*/ ,
                    event
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                observer === null || observer === void 0 ? void 0 : observer.disconnect();
                removeClickListeners();
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        execute: execute,
        teardown: teardown
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/det-notification.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "detNotify",
    ()=>detNotify,
    "resetNotify",
    ()=>resetNotify
]);
var notified = false;
var detNotify = function(config) {
    if (notified || config.defaultTracking !== undefined) {
        return;
    }
    var message = "`options.defaultTracking` is set to undefined. This implicitly configures your Amplitude instance to track Page Views, Sessions, File Downloads, and Form Interactions. You can suppress this warning by explicitly setting a value to `options.defaultTracking`. The value must either be a boolean, to enable and disable all default events, or an object, for advanced configuration. For example:\n\namplitude.init(<YOUR_API_KEY>, {\n  defaultTracking: true,\n});\n\nVisit https://www.docs.developers.amplitude.com/data/sdks/browser-2/#tracking-default-events for more details.";
    config.loggerProvider.warn(message);
    notified = true;
};
var resetNotify = function() {
    notified = false;
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/network-connectivity-checker.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "networkConnectivityCheckerPlugin",
    ()=>networkConnectivityCheckerPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/global-scope.js [app-client] (ecmascript)");
;
;
var networkConnectivityCheckerPlugin = function() {
    var name = '@amplitude/plugin-network-checker-browser';
    var type = 'before';
    var globalScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$global$2d$scope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGlobalScope"])();
    var eventListeners = [];
    var addNetworkListener = function(type, handler) {
        /* istanbul ignore next */ if (globalScope === null || globalScope === void 0 ? void 0 : globalScope.addEventListener) {
            globalScope === null || globalScope === void 0 ? void 0 : globalScope.addEventListener(type, handler);
            eventListeners.push({
                type: type,
                handler: handler
            });
        }
    };
    var removeNetworkListeners = function() {
        eventListeners.forEach(function(_a) {
            var type = _a.type, handler = _a.handler;
            /* istanbul ignore next */ globalScope === null || globalScope === void 0 ? void 0 : globalScope.removeEventListener(type, handler);
        });
        eventListeners = [];
    };
    var setup = function(config, amplitude) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                if (typeof navigator === 'undefined') {
                    config.loggerProvider.debug('Network connectivity checker plugin is disabled because navigator is not available.');
                    config.offline = false;
                    return [
                        2 /*return*/ 
                    ];
                }
                config.offline = !navigator.onLine;
                addNetworkListener('online', function() {
                    config.loggerProvider.debug('Network connectivity changed to online.');
                    config.offline = false;
                    // Flush immediately will cause ERR_NETWORK_CHANGED
                    setTimeout(function() {
                        amplitude.flush();
                    }, config.flushIntervalMillis);
                });
                addNetworkListener('offline', function() {
                    config.loggerProvider.debug('Network connectivity changed to offline.');
                    config.offline = true;
                });
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    var teardown = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(void 0, void 0, void 0, function() {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                removeNetworkListeners();
                return [
                    2 /*return*/ 
                ];
            });
        });
    };
    return {
        name: name,
        type: type,
        setup: setup,
        teardown: teardown
    };
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/config/joined-config.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "translateRemoteConfigToLocal",
    ()=>translateRemoteConfigToLocal,
    "updateBrowserConfigWithRemoteConfig",
    ()=>updateBrowserConfigWithRemoteConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
;
;
function translateRemoteConfigToLocal(config) {
    var e_1, _a, e_2, _b, e_3, _c;
    var _d, _e, _f, _g, _h, _j;
    // Disabling type checking rules because remote config comes from a remote source
    // and this function needs to handle any unexpected values
    /* eslint-disable @typescript-eslint/no-unsafe-member-access,
       @typescript-eslint/no-unsafe-assignment,
       @typescript-eslint/no-unsafe-argument
   */ if (typeof config !== 'object' || config === null) {
        return;
    }
    // translations are not applied on array properties
    if (Array.isArray(config)) {
        return;
    }
    var propertyNames = Object.keys(config);
    try {
        for(var propertyNames_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(propertyNames), propertyNames_1_1 = propertyNames_1.next(); !propertyNames_1_1.done; propertyNames_1_1 = propertyNames_1.next()){
            var propertyName = propertyNames_1_1.value;
            try {
                var value = config[propertyName];
                // transform objects with { enabled } property to boolean | object
                if (typeof (value === null || value === void 0 ? void 0 : value.enabled) === 'boolean') {
                    if (value.enabled) {
                        // if enabled is true, set the value to the rest of the object
                        // or true if the object has no other properties
                        delete value.enabled;
                        if (Object.keys(value).length === 0) {
                            config[propertyName] = true;
                        }
                    } else {
                        // If enabled is false, set the value to false
                        config[propertyName] = false;
                    }
                }
                // recursively translate properties of the value
                translateRemoteConfigToLocal(value);
            } catch (e) {
            // a failure here means that an accessor threw an error
            // so don't translate it
            // TODO(diagnostics): add a diagnostic event for this
            }
        }
    } catch (e_1_1) {
        e_1 = {
            error: e_1_1
        };
    } finally{
        try {
            if (propertyNames_1_1 && !propertyNames_1_1.done && (_a = propertyNames_1.return)) _a.call(propertyNames_1);
        } finally{
            if (e_1) throw e_1.error;
        }
    }
    // translate remote responseHeaders and requestHeaders to local responseHeaders and requestHeaders
    try {
        if ((_f = (_e = (_d = config.autocapture) === null || _d === void 0 ? void 0 : _d.networkTracking) === null || _e === void 0 ? void 0 : _e.captureRules) === null || _f === void 0 ? void 0 : _f.length) {
            try {
                for(var _k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(config.autocapture.networkTracking.captureRules), _l = _k.next(); !_l.done; _l = _k.next()){
                    var rule = _l.value;
                    try {
                        for(var _m = (e_3 = void 0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])([
                            'responseHeaders',
                            'requestHeaders'
                        ])), _o = _m.next(); !_o.done; _o = _m.next()){
                            var header = _o.value;
                            var _p = (_g = rule[header]) !== null && _g !== void 0 ? _g : {}, captureSafeHeaders = _p.captureSafeHeaders, allowlist = _p.allowlist;
                            if (!captureSafeHeaders && !allowlist) {
                                continue;
                            }
                            // if allowlist is not an array, remote config contract is violated, remove it
                            if (allowlist !== undefined && !Array.isArray(allowlist)) {
                                delete rule[header];
                                continue;
                            }
                            rule[header] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(captureSafeHeaders ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SAFE_HEADERS"] : []), false), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(allowlist !== null && allowlist !== void 0 ? allowlist : []), false);
                        }
                    } catch (e_3_1) {
                        e_3 = {
                            error: e_3_1
                        };
                    } finally{
                        try {
                            if (_o && !_o.done && (_c = _m.return)) _c.call(_m);
                        } finally{
                            if (e_3) throw e_3.error;
                        }
                    }
                }
            } catch (e_2_1) {
                e_2 = {
                    error: e_2_1
                };
            } finally{
                try {
                    if (_l && !_l.done && (_b = _k.return)) _b.call(_k);
                } finally{
                    if (e_2) throw e_2.error;
                }
            }
        }
    } catch (e) {
    /* istanbul ignore next */ // surprise exception, so don't translate it
    }
    // translate frustrationInteractions pluralization
    var frustrationInteractions = (_h = config.autocapture) === null || _h === void 0 ? void 0 : _h.frustrationInteractions;
    if (frustrationInteractions) {
        if (frustrationInteractions.rageClick) {
            frustrationInteractions.rageClicks = frustrationInteractions.rageClick;
            delete frustrationInteractions.rageClick;
        }
        if (frustrationInteractions.deadClick) {
            frustrationInteractions.deadClicks = frustrationInteractions.deadClick;
            delete frustrationInteractions.deadClick;
        }
    }
    // normalize viewportContentUpdated inside elementInteractions
    try {
        var elementInteractions = (_j = config.autocapture) === null || _j === void 0 ? void 0 : _j.elementInteractions;
        if (elementInteractions && typeof elementInteractions === 'object') {
            // { enabled: true } (no other fields) collapses to `true`; convert back to {} for the SDK.
            if (elementInteractions.viewportContentUpdated === true) {
                elementInteractions.viewportContentUpdated = {};
            }
            // { enabled: false, ... } collapses to `false`; convert back to { enabled: false } for the SDK.
            if (elementInteractions.viewportContentUpdated === false) {
                elementInteractions.viewportContentUpdated = {
                    enabled: false
                };
            }
            // Migrate deprecated top-level exposureDuration to viewportContentUpdated.exposureDuration
            if (elementInteractions.exposureDuration !== undefined) {
                var viewportContentUpdated = elementInteractions.viewportContentUpdated;
                if (viewportContentUpdated === undefined) {
                    elementInteractions.viewportContentUpdated = {
                        exposureDuration: elementInteractions.exposureDuration
                    };
                } else if (typeof viewportContentUpdated === 'object' && viewportContentUpdated.exposureDuration === undefined && viewportContentUpdated.enabled !== false) {
                    viewportContentUpdated.exposureDuration = elementInteractions.exposureDuration;
                }
                delete elementInteractions.exposureDuration;
            }
        }
    } catch (e) {
    /* istanbul ignore next */ // surprise exception, so don't translate it
    }
}
function mergeUrls(urlsExact, urlsRegex, browserConfig) {
    var e_4, _a;
    // Convert string patterns to RegExp objects, warn on invalid patterns and skip them
    var regexList = [];
    try {
        for(var _b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(urlsRegex !== null && urlsRegex !== void 0 ? urlsRegex : []), _c = _b.next(); !_c.done; _c = _b.next()){
            var pattern = _c.value;
            try {
                regexList.push(new RegExp(pattern));
            } catch (regexError) {
                browserConfig.loggerProvider.warn("Invalid regex pattern: ".concat(pattern), regexError);
            }
        }
    } catch (e_4_1) {
        e_4 = {
            error: e_4_1
        };
    } finally{
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        } finally{
            if (e_4) throw e_4.error;
        }
    }
    return urlsExact.concat(regexList);
}
function updateBrowserConfigWithRemoteConfig(remoteConfig, browserConfig) {
    var e_5, _a;
    var _b, _c, _d, _e, _f;
    if (!remoteConfig) {
        return;
    }
    // translate remote config to local compatible format
    translateRemoteConfigToLocal(remoteConfig);
    try {
        browserConfig.loggerProvider.debug('Update browser config with remote configuration:', JSON.stringify(remoteConfig));
        // type cast error will be thrown if remoteConfig is not a valid RemoteConfigBrowserSDK
        // and it will be caught by the try-catch block
        var typedRemoteConfig = remoteConfig;
        // merge remoteConfig.autocapture and browserConfig.autocapture
        // if a field is in remoteConfig.autocapture, use that value
        // if a field is not in remoteConfig.autocapture, use the value from browserConfig.autocapture
        if (typedRemoteConfig && 'autocapture' in typedRemoteConfig) {
            if (typeof typedRemoteConfig.autocapture === 'boolean') {
                browserConfig.autocapture = typedRemoteConfig.autocapture;
            }
            if (typeof typedRemoteConfig.autocapture === 'object' && typedRemoteConfig.autocapture !== null) {
                var transformedAutocaptureRemoteConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, typedRemoteConfig.autocapture);
                if (browserConfig.autocapture === undefined) {
                    browserConfig.autocapture = typedRemoteConfig.autocapture;
                }
                // Handle Element Interactions config initialization
                if (typeof typedRemoteConfig.autocapture.elementInteractions === 'object' && typedRemoteConfig.autocapture.elementInteractions !== null && ((_b = typedRemoteConfig.autocapture.elementInteractions.pageUrlAllowlistRegex) === null || _b === void 0 ? void 0 : _b.length)) {
                    transformedAutocaptureRemoteConfig.elementInteractions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, typedRemoteConfig.autocapture.elementInteractions);
                    var transformedRcElementInteractions = transformedAutocaptureRemoteConfig.elementInteractions;
                    // combine exact allow list and regex allow list into just 'pageUrlAllowlist'
                    var exactAllowList = (_c = transformedRcElementInteractions.pageUrlAllowlist) !== null && _c !== void 0 ? _c : [];
                    var urlsRegex = typedRemoteConfig.autocapture.elementInteractions.pageUrlAllowlistRegex;
                    transformedRcElementInteractions.pageUrlAllowlist = mergeUrls(exactAllowList, urlsRegex, browserConfig);
                    // clean up the regex allow list
                    delete transformedRcElementInteractions.pageUrlAllowlistRegex;
                }
                // Handle Network Tracking config initialization
                if (typeof typedRemoteConfig.autocapture.networkTracking === 'object' && typedRemoteConfig.autocapture.networkTracking !== null && ((_d = typedRemoteConfig.autocapture.networkTracking.captureRules) === null || _d === void 0 ? void 0 : _d.length)) {
                    transformedAutocaptureRemoteConfig.networkTracking = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, typedRemoteConfig.autocapture.networkTracking);
                    var transformedRcNetworkTracking = transformedAutocaptureRemoteConfig.networkTracking;
                    /* istanbul ignore next */ var captureRules = (_e = transformedRcNetworkTracking.captureRules) !== null && _e !== void 0 ? _e : [];
                    try {
                        for(var captureRules_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(captureRules), captureRules_1_1 = captureRules_1.next(); !captureRules_1_1.done; captureRules_1_1 = captureRules_1.next()){
                            var rule = captureRules_1_1.value;
                            rule.urls = mergeUrls((_f = rule.urls) !== null && _f !== void 0 ? _f : [], rule.urlsRegex, browserConfig);
                            delete rule.urlsRegex;
                        }
                    } catch (e_5_1) {
                        e_5 = {
                            error: e_5_1
                        };
                    } finally{
                        try {
                            if (captureRules_1_1 && !captureRules_1_1.done && (_a = captureRules_1.return)) _a.call(captureRules_1);
                        } finally{
                            if (e_5) throw e_5.error;
                        }
                    }
                }
                if (typeof browserConfig.autocapture === 'boolean') {
                    browserConfig.autocapture = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
                        attribution: browserConfig.autocapture,
                        fileDownloads: browserConfig.autocapture,
                        formInteractions: browserConfig.autocapture,
                        pageViews: browserConfig.autocapture,
                        sessions: browserConfig.autocapture,
                        elementInteractions: browserConfig.autocapture,
                        webVitals: browserConfig.autocapture,
                        frustrationInteractions: browserConfig.autocapture
                    }, transformedAutocaptureRemoteConfig);
                }
                if (typeof browserConfig.autocapture === 'object') {
                    browserConfig.autocapture = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, browserConfig.autocapture), transformedAutocaptureRemoteConfig);
                }
            }
            // Override default tracking options if autocapture is updated by remote config
            browserConfig.defaultTracking = browserConfig.autocapture;
        }
        if ('customEnrichment' in typedRemoteConfig && typedRemoteConfig.customEnrichment !== null) {
            // Respect a locally-explicit false: if the user disabled custom enrichment at init time,
            // remote config must not re-enable it.
            if (browserConfig.customEnrichment !== false) {
                browserConfig.customEnrichment = typedRemoteConfig.customEnrichment;
            }
        }
        browserConfig.loggerProvider.debug('Browser config after remote config update:', JSON.stringify(browserConfig));
    } catch (e) {
        browserConfig.loggerProvider.error('Failed to apply remote configuration because of error: ', e);
    }
}
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/web-attribution.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WebAttribution",
    ()=>WebAttribution
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/storage/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/session.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$campaign$2f$campaign$2d$parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/campaign/campaign-parser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/helpers.js [app-client] (ecmascript)");
;
;
;
var WebAttribution = function() {
    function WebAttribution(options, config) {
        var _a;
        this.shouldTrackNewCampaign = false;
        this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({
            initialEmptyValue: 'EMPTY',
            resetSessionOnNewCampaign: false,
            excludeReferrers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultExcludedReferrers"])(((_a = config.cookieOptions) === null || _a === void 0 ? void 0 : _a.domain) || config.topLevelDomain),
            optOut: config.optOut
        }, options);
        this.storage = config.cookieStorage;
        this.storageKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageKey"])(config.apiKey, 'MKTG');
        this.webExpStorageKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$storage$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorageKey"])(config.apiKey, 'MKTG_ORIGINAL');
        this.currentCampaign = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_CAMPAIGN"];
        this.sessionTimeout = config.sessionTimeout;
        this.lastEventTime = config.lastEventTime;
        this.logger = config.loggerProvider;
        this.topLevelDomain = config.topLevelDomain;
        config.loggerProvider.log('Installing web attribution tracking.');
    }
    WebAttribution.prototype.init = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var isEventInNewSession;
            var _a;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_b) {
                switch(_b.label){
                    case 0:
                        // skip attribution if optOut is true
                        if (this.options.optOut) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        return [
                            4 /*yield*/ ,
                            this.fetchCampaign()
                        ];
                    case 1:
                        _a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"].apply(void 0, [
                            _b.sent(),
                            2
                        ]), this.currentCampaign = _a[0], this.previousCampaign = _a[1];
                        isEventInNewSession = !this.lastEventTime ? true : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNewSession"])(this.sessionTimeout, this.lastEventTime);
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNewCampaign"])(this.currentCampaign, this.previousCampaign, this.options, this.logger, isEventInNewSession, this.topLevelDomain)) return [
                            3 /*break*/ ,
                            3
                        ];
                        this.shouldTrackNewCampaign = true;
                        return [
                            4 /*yield*/ ,
                            this.storage.set(this.storageKey, this.currentCampaign)
                        ];
                    case 2:
                        _b.sent();
                        _b.label = 3;
                    case 3:
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    WebAttribution.prototype.fetchCampaign = function() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var originalCampaign;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                switch(_a.label){
                    case 0:
                        return [
                            4 /*yield*/ ,
                            this.storage.get(this.webExpStorageKey)
                        ];
                    case 1:
                        originalCampaign = _a.sent();
                        if (!originalCampaign) return [
                            3 /*break*/ ,
                            3
                        ];
                        return [
                            4 /*yield*/ ,
                            this.storage.remove(this.webExpStorageKey)
                        ];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3:
                        return [
                            4 /*yield*/ ,
                            Promise.all([
                                originalCampaign || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$campaign$2f$campaign$2d$parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CampaignParser"]().parse(),
                                this.storage.get(this.storageKey)
                            ])
                        ];
                    case 4:
                        return [
                            2 /*return*/ ,
                            _a.sent()
                        ];
                }
            });
        });
    };
    /**
     * This can be called when enable web attribution and either
     * 1. set a new session
     * 2. has new campaign and enable resetSessionOnNewCampaign
     */ WebAttribution.prototype.generateCampaignEvent = function(event_id) {
        // Mark this campaign has been tracked
        this.shouldTrackNewCampaign = false;
        var campaignEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCampaignEvent"])(this.currentCampaign, this.options);
        if (event_id) {
            campaignEvent.event_id = event_id;
        }
        return campaignEvent;
    };
    WebAttribution.prototype.shouldSetSessionIdOnNewCampaign = function() {
        return this.shouldTrackNewCampaign && !!this.options.resetSessionOnNewCampaign;
    };
    return WebAttribution;
}();
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/tracking-methods.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EVENT_PROPERTY_TRACKING_METHOD",
    ()=>EVENT_PROPERTY_TRACKING_METHOD,
    "USER_PROPERTY_TRACKING_METHOD",
    ()=>USER_PROPERTY_TRACKING_METHOD,
    "hasTrackingMethod",
    ()=>hasTrackingMethod,
    "isEventPropertyAttributionEnabled",
    ()=>isEventPropertyAttributionEnabled,
    "isUserPropertyAttributionEnabled",
    ()=>isUserPropertyAttributionEnabled,
    "normalizeTrackingMethod",
    ()=>normalizeTrackingMethod
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var USER_PROPERTY_TRACKING_METHOD = 'userProperty';
var EVENT_PROPERTY_TRACKING_METHOD = 'eventProperty';
var isTrackingMethod = function(value) {
    return value === USER_PROPERTY_TRACKING_METHOD || value === EVENT_PROPERTY_TRACKING_METHOD;
};
var normalizeTrackingMethod = function(trackingMethod) {
    var normalized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__spreadArray"])([], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(new Set((Array.isArray(trackingMethod) ? trackingMethod : [
        trackingMethod
    ]).filter(isTrackingMethod))), false);
    return normalized.length > 0 ? normalized : [
        USER_PROPERTY_TRACKING_METHOD
    ];
};
var hasTrackingMethod = function(options, trackingMethod) {
    return normalizeTrackingMethod(options.trackingMethod).includes(trackingMethod);
};
var isUserPropertyAttributionEnabled = function(options) {
    return hasTrackingMethod(options, USER_PROPERTY_TRACKING_METHOD);
};
var isEventPropertyAttributionEnabled = function(options) {
    return hasTrackingMethod(options, EVENT_PROPERTY_TRACKING_METHOD);
};
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/browser-client.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AmplitudeBrowser",
    ()=>AmplitudeBrowser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$core$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/core-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$destination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/destination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/identify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/return-wrapper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$revenue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/revenue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/uuid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/analytics-connector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/session.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/plugins/identity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/query-params.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$offline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/offline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$remote$2d$config$2f$remote$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/remote-config/remote-config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$diagnostics$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/diagnostics/diagnostics-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/event-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$logger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/logger.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$safe$2d$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/safe-stringify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/default-tracking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/utils/snippet-helper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$page$2d$view$2d$tracking$2d$browser$40$2$2e$11$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$page$2d$view$2d$tracking$2d$browser$2f$lib$2f$esm$2f$page$2d$view$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-page-view-tracking-browser@2.11.1/node_modules/@amplitude/plugin-page-view-tracking-browser/lib/esm/page-view-tracking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$form$2d$interaction$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/form-interaction-tracking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$file$2d$download$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/file-download-tracking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$det$2d$notification$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/det-notification.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$network$2d$connectivity$2d$checker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/plugins/network-connectivity-checker.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$config$2f$joined$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/config/joined-config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/autocapture-plugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$frustration$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/frustration-plugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$performance$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-autocapture-browser@1.27.2/node_modules/@amplitude/plugin-autocapture-browser/lib/esm/performance-plugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$network$2d$capture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__networkCapturePlugin__as__plugin$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-network-capture-browser@1.10.1/node_modules/@amplitude/plugin-network-capture-browser/lib/esm/network-capture-plugin.js [app-client] (ecmascript) <export networkCapturePlugin as plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$web$2d$vitals$2d$browser$40$1$2e$1$2e$33$2f$node_modules$2f40$amplitude$2f$plugin$2d$web$2d$vitals$2d$browser$2f$lib$2f$esm$2f$web$2d$vitals$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-web-vitals-browser@1.1.33/node_modules/@amplitude/plugin-web-vitals-browser/lib/esm/web-vitals-plugin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$web$2d$attribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/web-attribution.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$event$2d$property$2d$attribution$2d$browser$40$0$2e$2$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$event$2d$property$2d$attribution$2d$browser$2f$lib$2f$esm$2f$event$2d$property$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-event-property-attribution-browser@0.2.1/node_modules/@amplitude/plugin-event-property-attribution-browser/lib/esm/event-property-tracking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$lib$2d$prefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/lib-prefix.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/version.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$page$2d$url$2d$enrichment$2d$browser$40$0$2e$7$2e$11$2f$node_modules$2f40$amplitude$2f$plugin$2d$page$2d$url$2d$enrichment$2d$browser$2f$lib$2f$esm$2f$page$2d$url$2d$enrichment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-page-url-enrichment-browser@0.7.11/node_modules/@amplitude/plugin-page-url-enrichment-browser/lib/esm/page-url-enrichment.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$custom$2d$enrichment$2d$browser$40$0$2e$1$2e$9$2f$node_modules$2f40$amplitude$2f$plugin$2d$custom$2d$enrichment$2d$browser$2f$lib$2f$esm$2f$custom$2d$enrichment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+plugin-custom-enrichment-browser@0.1.9/node_modules/@amplitude/plugin-custom-enrichment-browser/lib/esm/custom-enrichment.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$tracking$2d$methods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/attribution/tracking-methods.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var UNSPECIFIED_SESSION_ID = -1;
/**
 * Exported for `@amplitude/unified` or integration with blade plugins.
 * If you only use `@amplitude/analytics-browser`, use `amplitude.init()` or `amplitude.createInstance()` instead.
 */ var AmplitudeBrowser = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(AmplitudeBrowser, _super);
    function AmplitudeBrowser() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // Backdoor to set diagnostics sample rate
        // by calling amplitude._setDiagnosticsSampleRate(1); before amplitude.init()
        _this._diagnosticsSampleRate = 0;
        return _this;
    }
    AmplitudeBrowser.prototype.init = function(apiKey, userIdOrOptions, maybeOptions) {
        if (apiKey === void 0) {
            apiKey = '';
        }
        var userId;
        var options;
        if (arguments.length > 2) {
            userId = userIdOrOptions;
            options = maybeOptions;
        } else {
            if (typeof userIdOrOptions === 'string') {
                userId = userIdOrOptions;
                options = undefined;
            } else {
                userId = userIdOrOptions === null || userIdOrOptions === void 0 ? void 0 : userIdOrOptions.userId;
                options = userIdOrOptions;
            }
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(this._init((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, options), {
            userId: userId,
            apiKey: apiKey
        })));
    };
    AmplitudeBrowser.prototype._init = function(options) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var fetchRemoteConfig, loggerProvider, serverZone, remoteConfigClient, diagnosticsSampleRate, enableDiagnostics, diagnosticsClient, browserOptions, attributionTrackingOptions, queryParams, ampTimestamp, isWithinTimeLimit, querySessionId, deferredSessionId, connector;
            var _this = this;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_j) {
                switch(_j.label){
                    case 0:
                        // Step 1: Block concurrent initialization
                        if (this.initializing) {
                            return [
                                2 /*return*/ 
                            ];
                        }
                        this.initializing = true;
                        fetchRemoteConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldFetchRemoteConfig"])(options);
                        loggerProvider = (_a = options.loggerProvider) !== null && _a !== void 0 ? _a : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$logger$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logger"]();
                        if (!options.loggerProvider) {
                            loggerProvider.enable((_b = options.logLevel) !== null && _b !== void 0 ? _b : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"].Warn);
                        }
                        serverZone = (_c = options.serverZone) !== null && _c !== void 0 ? _c : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SERVER_ZONE"];
                        diagnosticsSampleRate = this._diagnosticsSampleRate;
                        enableDiagnostics = (_d = options.enableDiagnostics) !== null && _d !== void 0 ? _d : true;
                        if (!fetchRemoteConfig) return [
                            3 /*break*/ ,
                            2
                        ];
                        remoteConfigClient = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$remote$2d$config$2f$remote$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoteConfigClient"](options.apiKey, loggerProvider, serverZone, /* istanbul ignore next */ (_e = options.remoteConfig) === null || _e === void 0 ? void 0 : _e.serverUrl);
                        // Fetch diagnostics config first to get sample rate
                        return [
                            4 /*yield*/ ,
                            new Promise(function(resolve) {
                                // Disable coverage for this line because remote config client will always be defined in this case.
                                // istanbul ignore next
                                remoteConfigClient === null || remoteConfigClient === void 0 ? void 0 : remoteConfigClient.subscribe('configs.diagnostics.browserSDK', 'all', function(remoteConfig, source, lastFetch) {
                                    loggerProvider.debug('Diagnostics remote configuration received:', JSON.stringify({
                                        remoteConfig: remoteConfig,
                                        source: source,
                                        lastFetch: lastFetch
                                    }, null, 2));
                                    if (remoteConfig) {
                                        // Validate and set sampleRate (must be a valid number)
                                        var sampleRate = remoteConfig.sampleRate;
                                        if (typeof sampleRate === 'number' && !isNaN(sampleRate)) {
                                            diagnosticsSampleRate = sampleRate;
                                        }
                                        // Validate and set enabled (must be a boolean)
                                        var enabled = remoteConfig.enabled;
                                        if (typeof enabled === 'boolean') {
                                            enableDiagnostics = enabled;
                                        }
                                    }
                                    resolve();
                                });
                            })
                        ];
                    case 1:
                        // Fetch diagnostics config first to get sample rate
                        _j.sent();
                        _j.label = 2;
                    case 2:
                        diagnosticsClient = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$diagnostics$2f$diagnostics$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DiagnosticsClient"](options.apiKey, loggerProvider, serverZone, {
                            enabled: enableDiagnostics,
                            sampleRate: diagnosticsSampleRate
                        });
                        diagnosticsClient.setTag('library', "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$lib$2d$prefix$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LIBPREFIX"], "/").concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$version$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VERSION"]));
                        if (typeof navigator !== 'undefined') {
                            diagnosticsClient.setTag('user_agent', navigator.userAgent);
                        }
                        return [
                            4 /*yield*/ ,
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBrowserConfig"])(options.apiKey, options, this, diagnosticsClient, {
                                loggerProvider: loggerProvider,
                                serverZone: serverZone,
                                enableDiagnostics: enableDiagnostics,
                                diagnosticsSampleRate: diagnosticsSampleRate
                            })
                        ];
                    case 3:
                        browserOptions = _j.sent();
                        if (!(fetchRemoteConfig && remoteConfigClient)) return [
                            3 /*break*/ ,
                            5
                        ];
                        return [
                            4 /*yield*/ ,
                            new Promise(function(resolve) {
                                // Disable coverage for this line because remote config client will always be defined in this case.
                                // istanbul ignore next
                                remoteConfigClient === null || remoteConfigClient === void 0 ? void 0 : remoteConfigClient.subscribe('configs.analyticsSDK.browserSDK', 'all', function(remoteConfig, source, lastFetch) {
                                    browserOptions.loggerProvider.debug('Remote configuration received:', JSON.stringify({
                                        remoteConfig: remoteConfig,
                                        source: source,
                                        lastFetch: lastFetch
                                    }, null, 2));
                                    if (remoteConfig) {
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$config$2f$joined$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBrowserConfigWithRemoteConfig"])(remoteConfig, browserOptions);
                                    }
                                    // Resolve the promise on first callback (initial config)
                                    resolve();
                                });
                            })
                        ];
                    case 4:
                        _j.sent();
                        _j.label = 5;
                    case 5:
                        return [
                            4 /*yield*/ ,
                            _super.prototype._init.call(this, browserOptions)
                        ];
                    case 6:
                        _j.sent();
                        this.logBrowserOptions(browserOptions);
                        this.config.remoteConfigClient = remoteConfigClient;
                        attributionTrackingOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAttributionTrackingConfig"])(this.config);
                        if (!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAttributionTrackingEnabled"])(this.config.defaultTracking) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$tracking$2d$methods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUserPropertyAttributionEnabled"])(attributionTrackingOptions))) return [
                            3 /*break*/ ,
                            8
                        ];
                        if (this.config.optOut) {
                            this.timeline.addOptOutListener(function(optOut) {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
                                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                                        switch(_a.label){
                                            case 0:
                                                if (!!optOut) return [
                                                    3 /*break*/ ,
                                                    2
                                                ];
                                                this.webAttribution = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$web$2d$attribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WebAttribution"](attributionTrackingOptions, this.config);
                                                return [
                                                    4 /*yield*/ ,
                                                    this.webAttribution.init()
                                                ];
                                            case 1:
                                                _a.sent();
                                                _a.label = 2;
                                            case 2:
                                                return [
                                                    2 /*return*/ 
                                                ];
                                        }
                                    });
                                });
                            });
                        }
                        this.webAttribution = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$web$2d$attribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WebAttribution"](attributionTrackingOptions, this.config);
                        // Fetch the current campaign, check if need to track web attribution later
                        return [
                            4 /*yield*/ ,
                            this.webAttribution.init()
                        ];
                    case 7:
                        // Fetch the current campaign, check if need to track web attribution later
                        _j.sent();
                        _j.label = 8;
                    case 8:
                        queryParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$query$2d$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getQueryParams"])();
                        ampTimestamp = queryParams.ampTimestamp ? Number(queryParams.ampTimestamp) : undefined;
                        isWithinTimeLimit = ampTimestamp ? Date.now() < ampTimestamp : true;
                        querySessionId = isWithinTimeLimit && !Number.isNaN(Number(queryParams.ampSessionId)) ? Number(queryParams.ampSessionId) : undefined;
                        deferredSessionId = this.config.deferredSessionId;
                        if (deferredSessionId === UNSPECIFIED_SESSION_ID && !this.config.optOut) {
                            deferredSessionId = Date.now();
                        }
                        this.setSessionId((_h = (_g = (_f = options.sessionId) !== null && _f !== void 0 ? _f : querySessionId) !== null && _g !== void 0 ? _g : deferredSessionId) !== null && _h !== void 0 ? _h : this.config.sessionId);
                        if (this.config.optOut) {
                            this.timeline.addOptOutListener(function(optOut) {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
                                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                                        if (!optOut && this.config.deferredSessionId) {
                                            if (this.config.deferredSessionId === UNSPECIFIED_SESSION_ID) {
                                                this.setSessionId(undefined);
                                            } else {
                                                this.setSessionId(this.config.deferredSessionId);
                                            }
                                        }
                                        return [
                                            2 /*return*/ 
                                        ];
                                    });
                                });
                            });
                        }
                        connector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAnalyticsConnector"])(options.instanceName);
                        connector.identityStore.setIdentity({
                            userId: this.config.userId,
                            deviceId: this.config.deviceId
                        });
                        if (!(this.config.offline !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$offline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineDisabled"])) return [
                            3 /*break*/ ,
                            10
                        ];
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$network$2d$connectivity$2d$checker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networkConnectivityCheckerPlugin"])()).promise
                        ];
                    case 9:
                        _j.sent();
                        _j.label = 10;
                    case 10:
                        return [
                            4 /*yield*/ ,
                            this.add(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$destination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Destination"]({
                                diagnosticsClient: diagnosticsClient
                            })).promise
                        ];
                    case 11:
                        _j.sent();
                        return [
                            4 /*yield*/ ,
                            this.add(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Context"]()).promise
                        ];
                    case 12:
                        _j.sent();
                        return [
                            4 /*yield*/ ,
                            this.add(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$plugins$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentityEventSender"]()).promise
                        ];
                    case 13:
                        _j.sent();
                        // Notify if DET is enabled
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$det$2d$notification$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detNotify"])(this.config);
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFileDownloadTrackingEnabled"])(this.config.defaultTracking)) return [
                            3 /*break*/ ,
                            15
                        ];
                        this.config.loggerProvider.debug('Adding file download tracking plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$file$2d$download$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fileDownloadTracking"])()).promise
                        ];
                    case 14:
                        _j.sent();
                        _j.label = 15;
                    case 15:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFormInteractionTrackingEnabled"])(this.config.defaultTracking)) return [
                            3 /*break*/ ,
                            17
                        ];
                        this.config.loggerProvider.debug('Adding form interaction plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$plugins$2f$form$2d$interaction$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formInteractionTracking"])()).promise
                        ];
                    case 16:
                        _j.sent();
                        _j.label = 17;
                    case 17:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageViewTrackingEnabled"])(this.config.defaultTracking)) return [
                            3 /*break*/ ,
                            20
                        ];
                        if (!!this.config.optOut) return [
                            3 /*break*/ ,
                            19
                        ];
                        this.config.loggerProvider.debug('Adding page view tracking plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$page$2d$view$2d$tracking$2d$browser$40$2$2e$11$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$page$2d$view$2d$tracking$2d$browser$2f$lib$2f$esm$2f$page$2d$view$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageViewTrackingPlugin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageViewTrackingConfig"])(this.config))).promise
                        ];
                    case 18:
                        _j.sent();
                        return [
                            3 /*break*/ ,
                            20
                        ];
                    case 19:
                        this.timeline.addOptOutListener(function(optOut) {
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(_this, void 0, void 0, function() {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                                    switch(_a.label){
                                        case 0:
                                            /* istanbul ignore if */ if (optOut) {
                                                return [
                                                    2 /*return*/ 
                                                ];
                                            }
                                            this.config.loggerProvider.debug('Adding page view tracking plugin');
                                            return [
                                                4 /*yield*/ ,
                                                this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$page$2d$view$2d$tracking$2d$browser$40$2$2e$11$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$page$2d$view$2d$tracking$2d$browser$2f$lib$2f$esm$2f$page$2d$view$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageViewTrackingPlugin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageViewTrackingConfig"])(this.config))).promise
                                            ];
                                        case 1:
                                            _a.sent();
                                            return [
                                                2 /*return*/ 
                                            ];
                                    }
                                });
                            });
                        });
                        _j.label = 20;
                    case 20:
                        if (!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAttributionTrackingEnabled"])(this.config.defaultTracking) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$tracking$2d$methods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEventPropertyAttributionEnabled"])(attributionTrackingOptions))) return [
                            3 /*break*/ ,
                            22
                        ];
                        this.config.loggerProvider.debug('Adding event property attribution plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$event$2d$property$2d$attribution$2d$browser$40$0$2e$2$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$event$2d$property$2d$attribution$2d$browser$2f$lib$2f$esm$2f$event$2d$property$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventPropertyTrackingPlugin"])(attributionTrackingOptions)).promise
                        ];
                    case 21:
                        _j.sent();
                        _j.label = 22;
                    case 22:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElementInteractionsEnabled"])(this.config.autocapture)) return [
                            3 /*break*/ ,
                            24
                        ];
                        this.config.loggerProvider.debug('Adding user interactions plugin (autocapture plugin)');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$autocapture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["autocapturePlugin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getElementInteractionsConfig"])(this.config), {
                                diagnosticsClient: diagnosticsClient
                            })).promise
                        ];
                    case 23:
                        _j.sent();
                        _j.label = 24;
                    case 24:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFrustrationInteractionsEnabled"])(this.config.autocapture)) return [
                            3 /*break*/ ,
                            26
                        ];
                        this.config.loggerProvider.debug('Adding frustration interactions plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$frustration$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["frustrationPlugin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFrustrationInteractionsConfig"])(this.config))).promise
                        ];
                    case 25:
                        _j.sent();
                        _j.label = 26;
                    case 26:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNetworkTrackingEnabled"])(this.config.autocapture)) return [
                            3 /*break*/ ,
                            28
                        ];
                        this.config.loggerProvider.debug('Adding network tracking plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$network$2d$capture$2d$browser$40$1$2e$10$2e$1$2f$node_modules$2f40$amplitude$2f$plugin$2d$network$2d$capture$2d$browser$2f$lib$2f$esm$2f$network$2d$capture$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__networkCapturePlugin__as__plugin$3e$__["plugin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNetworkTrackingConfig"])(this.config))).promise
                        ];
                    case 27:
                        _j.sent();
                        _j.label = 28;
                    case 28:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebVitalsEnabled"])(this.config.autocapture)) return [
                            3 /*break*/ ,
                            30
                        ];
                        this.config.loggerProvider.debug('Adding web vitals plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$web$2d$vitals$2d$browser$40$1$2e$1$2e$33$2f$node_modules$2f40$amplitude$2f$plugin$2d$web$2d$vitals$2d$browser$2f$lib$2f$esm$2f$web$2d$vitals$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["webVitalsPlugin"])()).promise
                        ];
                    case 29:
                        _j.sent();
                        _j.label = 30;
                    case 30:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPerformanceTrackingEnabled"])(this.config.autocapture)) return [
                            3 /*break*/ ,
                            32
                        ];
                        this.config.loggerProvider.debug('Adding performance tracking plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$autocapture$2d$browser$40$1$2e$27$2e$2$2f$node_modules$2f40$amplitude$2f$plugin$2d$autocapture$2d$browser$2f$lib$2f$esm$2f$performance$2d$plugin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["performancePlugin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPerformanceTrackingConfig"])(this.config))).promise
                        ];
                    case 31:
                        _j.sent();
                        _j.label = 32;
                    case 32:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPageUrlEnrichmentEnabled"])(this.config.autocapture)) return [
                            3 /*break*/ ,
                            34
                        ];
                        this.config.loggerProvider.debug('Adding referrer page url plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$page$2d$url$2d$enrichment$2d$browser$40$0$2e$7$2e$11$2f$node_modules$2f40$amplitude$2f$plugin$2d$page$2d$url$2d$enrichment$2d$browser$2f$lib$2f$esm$2f$page$2d$url$2d$enrichment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pageUrlEnrichmentPlugin"])()).promise
                        ];
                    case 33:
                        _j.sent();
                        _j.label = 34;
                    case 34:
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCustomEnrichmentEnabled"])(this.config.customEnrichment)) return [
                            3 /*break*/ ,
                            36
                        ];
                        this.config.loggerProvider.debug('Adding custom enrichment plugin');
                        return [
                            4 /*yield*/ ,
                            this.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$plugin$2d$custom$2d$enrichment$2d$browser$40$0$2e$1$2e$9$2f$node_modules$2f40$amplitude$2f$plugin$2d$custom$2d$enrichment$2d$browser$2f$lib$2f$esm$2f$custom$2d$enrichment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["customEnrichmentPlugin"])()).promise
                        ];
                    case 35:
                        _j.sent();
                        _j.label = 36;
                    case 36:
                        this.initializing = false;
                        // Step 6: Run queued dispatch functions
                        return [
                            4 /*yield*/ ,
                            this.runQueuedFunctions('dispatchQ')
                        ];
                    case 37:
                        // Step 6: Run queued dispatch functions
                        _j.sent();
                        // Step 7: Add the event receiver after running remaining queued functions.
                        connector.eventBridge.setEventReceiver(function(event) {
                            var _a = event.eventProperties || {}, time = _a.time, cleanEventProperties = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__rest"])(_a, [
                                "time"
                            ]);
                            var eventOptions = typeof time === 'number' ? {
                                time: time
                            } : undefined;
                            void _this.track(event.eventType, cleanEventProperties, eventOptions);
                        });
                        return [
                            2 /*return*/ 
                        ];
                }
            });
        });
    };
    AmplitudeBrowser.prototype.getUserId = function() {
        var _a;
        return (_a = this.config) === null || _a === void 0 ? void 0 : _a.userId;
    };
    AmplitudeBrowser.prototype.setUserId = function(userId) {
        if (!this.config) {
            this.q.push(this.setUserId.bind(this, userId));
            return;
        }
        this.config.loggerProvider.debug('function setUserId: ', userId);
        if (userId !== this.config.userId || userId === undefined) {
            this.config.userId = userId;
            // eslint-disable-next-line @typescript-eslint/no-unsafe-call
            this.timeline.onIdentityChanged({
                userId: userId
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setConnectorUserId"])(userId, this.config.instanceName);
        }
    };
    AmplitudeBrowser.prototype.getDeviceId = function() {
        var _a;
        return (_a = this.config) === null || _a === void 0 ? void 0 : _a.deviceId;
    };
    AmplitudeBrowser.prototype.setDeviceId = function(deviceId) {
        if (!this.config) {
            this.q.push(this.setDeviceId.bind(this, deviceId));
            return;
        }
        this.config.loggerProvider.debug('function setDeviceId: ', deviceId);
        if (deviceId !== this.config.deviceId) {
            this.config.deviceId = deviceId;
            // eslint-disable-next-line @typescript-eslint/no-unsafe-call
            this.timeline.onIdentityChanged({
                deviceId: deviceId
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$analytics$2d$connector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setConnectorDeviceId"])(deviceId, this.config.instanceName);
        }
    };
    AmplitudeBrowser.prototype.reset = function() {
        this.setDeviceId((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$uuid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UUID"])());
        this.setUserId(undefined);
        this.timeline.onReset();
    };
    AmplitudeBrowser.prototype.getIdentity = function() {
        var _a, _b;
        return {
            deviceId: (_a = this.config) === null || _a === void 0 ? void 0 : _a.deviceId,
            userId: (_b = this.config) === null || _b === void 0 ? void 0 : _b.userId,
            userProperties: this.userProperties
        };
    };
    AmplitudeBrowser.prototype.setIdentity = function(identity) {
        var e_1, _a;
        var _b;
        // Handle userId change
        if ('userId' in identity) {
            this.setUserId(identity.userId);
        }
        // Handle deviceId change
        if ('deviceId' in identity && identity.deviceId) {
            this.setDeviceId(identity.deviceId);
        }
        // Handle userProperties change - auto-send identify
        if ('userProperties' in identity) {
            this.userProperties = identity.userProperties;
            // Auto-send identify event with $set operations
            var identifyObj = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Identify"]();
            // istanbul ignore next
            var userProperties = (_b = identity.userProperties) !== null && _b !== void 0 ? _b : {};
            try {
                for(var _c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__values"])(Object.entries(userProperties)), _d = _c.next(); !_d.done; _d = _c.next()){
                    var _e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__read"])(_d.value, 2), key = _e[0], value = _e[1];
                    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                    identifyObj.set(key, value);
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            // The identify event processing in core-client already calls onIdentityChanged,
            // so we don't need to call it explicitly here to avoid duplicate notifications.
            this.identify(identifyObj);
        }
    };
    AmplitudeBrowser.prototype.getOptOut = function() {
        var _a;
        return (_a = this.config) === null || _a === void 0 ? void 0 : _a.optOut;
    };
    AmplitudeBrowser.prototype.getSessionId = function() {
        var _a;
        return (_a = this.config) === null || _a === void 0 ? void 0 : _a.sessionId;
    };
    AmplitudeBrowser.prototype.setSessionId = function(sessionId) {
        var _a;
        var promises = [];
        if (!this.config) {
            this.q.push(this.setSessionId.bind(this, sessionId));
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(Promise.resolve());
        }
        // do not start a new session if optOut is true
        if (this.config.optOut) {
            // save the sessionId to storage to be used when optOut is false
            this.config.deferredSessionId = sessionId !== null && sessionId !== void 0 ? sessionId : UNSPECIFIED_SESSION_ID;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(Promise.resolve());
        }
        // default sessionId to current time
        if (sessionId === undefined) {
            sessionId = Date.now();
        }
        // Prevents starting a new session with the same session ID
        if (sessionId === this.config.sessionId) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(Promise.resolve());
        }
        this.config.loggerProvider.debug('function setSessionId: ', sessionId);
        var previousSessionId = this.getSessionId();
        if (previousSessionId !== sessionId) {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-call
            this.timeline.onSessionIdChanged(sessionId);
        }
        var lastEventTime = this.config.lastEventTime;
        var lastEventId = (_a = this.config.lastEventId) !== null && _a !== void 0 ? _a : -1;
        this.config.sessionId = sessionId;
        this.config.lastEventTime = undefined;
        this.config.pageCounter = 0;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSessionTrackingEnabled"])(this.config.defaultTracking)) {
            if (previousSessionId && lastEventTime) {
                promises.push(this.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SESSION_END_EVENT"], undefined, {
                    device_id: this.previousSessionDeviceId,
                    event_id: ++lastEventId,
                    session_id: previousSessionId,
                    time: lastEventTime + 1,
                    user_id: this.previousSessionUserId
                }).promise);
            }
            this.config.lastEventTime = this.config.sessionId;
        }
        // Fire web attribution event when enable webAttribution tracking
        // 1. has new campaign (call setSessionId from init function)
        // 2. or shouldTrackNewCampaign (call setSessionId from async process(event) when there has new campaign and resetSessionOnNewCampaign = true )
        var isCampaignEventTracked = this.trackCampaignEventIfNeeded(++lastEventId, promises);
        // track the identify event if an Identify object is provided in the config
        if (this.config.identify) {
            promises.push(this.track((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$event$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createIdentifyEvent"])(this.config.identify)).promise);
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$default$2d$tracking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSessionTrackingEnabled"])(this.config.defaultTracking)) {
            promises.push(this.track(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SESSION_START_EVENT"], undefined, {
                event_id: isCampaignEventTracked ? ++lastEventId : lastEventId,
                session_id: this.config.sessionId,
                time: this.config.lastEventTime
            }).promise);
        }
        this.previousSessionDeviceId = this.config.deviceId;
        this.previousSessionUserId = this.config.userId;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$return$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["returnWrapper"])(Promise.all(promises));
    };
    AmplitudeBrowser.prototype.extendSession = function() {
        if (!this.config) {
            this.q.push(this.extendSession.bind(this));
            return;
        }
        this.config.lastEventTime = Date.now();
    };
    AmplitudeBrowser.prototype.setTransport = function(transport) {
        if (!this.config) {
            this.q.push(this.setTransport.bind(this, transport));
            return;
        }
        this.config.transportProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTransport"])(transport);
    };
    AmplitudeBrowser.prototype.identify = function(identify, eventOptions) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInstanceProxy"])(identify)) {
            var queue = identify._q;
            identify._q = [];
            identify = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertProxyObjectToRealObject"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Identify"](), queue);
        }
        if (eventOptions === null || eventOptions === void 0 ? void 0 : eventOptions.user_id) {
            this.setUserId(eventOptions.user_id);
        }
        if (eventOptions === null || eventOptions === void 0 ? void 0 : eventOptions.device_id) {
            this.setDeviceId(eventOptions.device_id);
        }
        return _super.prototype.identify.call(this, identify, eventOptions);
    };
    AmplitudeBrowser.prototype.groupIdentify = function(groupType, groupName, identify, eventOptions) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInstanceProxy"])(identify)) {
            var queue = identify._q;
            identify._q = [];
            identify = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertProxyObjectToRealObject"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$identify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Identify"](), queue);
        }
        return _super.prototype.groupIdentify.call(this, groupType, groupName, identify, eventOptions);
    };
    AmplitudeBrowser.prototype.revenue = function(revenue, eventOptions) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInstanceProxy"])(revenue)) {
            var queue = revenue._q;
            revenue._q = [];
            revenue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$utils$2f$snippet$2d$helper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertProxyObjectToRealObject"])(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$revenue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Revenue"](), queue);
        }
        return _super.prototype.revenue.call(this, revenue, eventOptions);
    };
    AmplitudeBrowser.prototype.trackCampaignEventIfNeeded = function(lastEventId, promises) {
        if (!this.webAttribution || !this.webAttribution.shouldTrackNewCampaign || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$attribution$2f$tracking$2d$methods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isUserPropertyAttributionEnabled"])(this.webAttribution.options)) {
            return false;
        }
        var campaignEvent = this.webAttribution.generateCampaignEvent(lastEventId);
        if (promises) {
            promises.push(this.track(campaignEvent).promise);
        } else {
            this.track(campaignEvent);
        }
        this.config.loggerProvider.log('Tracking attribution.');
        return true;
    };
    AmplitudeBrowser.prototype.process = function(event) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__awaiter"])(this, void 0, void 0, function() {
            var currentTime, isEventInNewSession, shouldSetSessionIdOnNewCampaign;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__generator"])(this, function(_a) {
                currentTime = Date.now();
                isEventInNewSession = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$session$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNewSession"])(this.config.sessionTimeout, this.config.lastEventTime);
                shouldSetSessionIdOnNewCampaign = this.webAttribution && this.webAttribution.shouldSetSessionIdOnNewCampaign();
                if (event.event_type !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SESSION_START_EVENT"] && event.event_type !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_SESSION_END_EVENT"] && (!event.session_id || event.session_id === this.getSessionId())) {
                    if (isEventInNewSession || shouldSetSessionIdOnNewCampaign) {
                        this.setSessionId(currentTime);
                        if (shouldSetSessionIdOnNewCampaign) {
                            this.config.loggerProvider.log('Created a new session for new campaign.');
                        }
                    } else if (!isEventInNewSession) {
                        // Web attribution should be tracked during the middle of a session
                        // if there has been a chance in the campaign information.
                        this.trackCampaignEventIfNeeded();
                    }
                }
                return [
                    2 /*return*/ ,
                    _super.prototype.process.call(this, event)
                ];
            });
        });
    };
    AmplitudeBrowser.prototype.logBrowserOptions = function(browserConfig) {
        try {
            var browserConfigCopy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$tslib$40$2$2e$8$2e$1$2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, browserConfig), {
                apiKey: browserConfig.apiKey.substring(0, 10) + '********'
            });
            this.config.loggerProvider.debug('Initialized Amplitude with BrowserConfig:', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$safe$2d$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeJsonStringify"])(browserConfigCopy));
        } catch (e) {
            /* istanbul ignore next */ this.config.loggerProvider.error('Error logging browser config', e);
        }
    };
    /**
     * @experimental
     * WARNING: This method is for internal testing only and is not part of the public API.
     * It may be changed or removed at any time without notice.
     *
     * Sets the diagnostics sample rate before amplitude.init()
     * @param sampleRate - The sample rate to set
     */ AmplitudeBrowser.prototype._setDiagnosticsSampleRate = function(sampleRate) {
        if (sampleRate > 1 || sampleRate < 0) {
            return;
        }
        // Set diagnostics sample rate before initializing the config
        if (!this.config) {
            this._diagnosticsSampleRate = sampleRate;
            return;
        }
    };
    return AmplitudeBrowser;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$core$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplitudeCore"]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/browser-client-factory.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createInstance",
    ()=>createInstance,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/utils/debug.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/browser-client.js [app-client] (ecmascript)");
;
;
var createInstance = function() {
    var client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AmplitudeBrowser"]();
    return {
        init: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.init.bind(client), 'init', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        add: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.add.bind(client), 'add', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.plugins'
        ])),
        remove: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.remove.bind(client), 'remove', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.plugins'
        ])),
        track: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.track.bind(client), 'track', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        logEvent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.logEvent.bind(client), 'logEvent', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        identify: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.identify.bind(client), 'identify', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        groupIdentify: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.groupIdentify.bind(client), 'groupIdentify', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        setGroup: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setGroup.bind(client), 'setGroup', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        revenue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.revenue.bind(client), 'revenue', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        flush: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.flush.bind(client), 'flush', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config.apiKey',
            'timeline.queue.length'
        ])),
        getUserId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.getUserId.bind(client), 'getUserId', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config',
            'config.userId'
        ])),
        setUserId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setUserId.bind(client), 'setUserId', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config',
            'config.userId'
        ])),
        getDeviceId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.getDeviceId.bind(client), 'getDeviceId', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config',
            'config.deviceId'
        ])),
        setDeviceId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setDeviceId.bind(client), 'setDeviceId', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config',
            'config.deviceId'
        ])),
        reset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.reset.bind(client), 'reset', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config',
            'config.userId',
            'config.deviceId'
        ])),
        getSessionId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.getSessionId.bind(client), 'getSessionId', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        setSessionId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setSessionId.bind(client), 'setSessionId', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        extendSession: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.extendSession.bind(client), 'extendSession', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        setOptOut: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setOptOut.bind(client), 'setOptOut', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        setTransport: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setTransport.bind(client), 'setTransport', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        getIdentity: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.getIdentity.bind(client), 'getIdentity', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        setIdentity: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.setIdentity.bind(client), 'setIdentity', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config',
            'config.userId',
            'config.deviceId'
        ])),
        getOptOut: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client.getOptOut.bind(client), 'getOptOut', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ])),
        _setDiagnosticsSampleRate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debugWrapper"])(client._setDiagnosticsSampleRate.bind(client), '_setDiagnosticsSampleRate', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientLogConfig"])(client), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$utils$2f$debug$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientStates"])(client, [
            'config'
        ]))
    };
};
const __TURBOPACK__default__export__ = createInstance();
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/types.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/* eslint-disable @typescript-eslint/unbound-method */ __turbopack_context__.s([]);
;
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/types.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_ACTION_CLICK_ALLOWLIST",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_ACTION_CLICK_ALLOWLIST"],
    "DEFAULT_CSS_SELECTOR_ALLOWLIST",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CSS_SELECTOR_ALLOWLIST"],
    "DEFAULT_DATA_ATTRIBUTE_PREFIX",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_DATA_ATTRIBUTE_PREFIX"],
    "EXCLUDE_INTERNAL_REFERRERS_CONDITIONS",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$config$2f$browser$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EXCLUDE_INTERNAL_REFERRERS_CONDITIONS"],
    "IdentifyOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifyOperation"],
    "LogLevel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogLevel"],
    "OfflineDisabled",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$offline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineDisabled"],
    "RevenueProperty",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$revenue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RevenueProperty"],
    "ServerZone",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$server$2d$zone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServerZone"],
    "SpecialEventType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpecialEventType"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/types.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$event$2f$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/event/event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$revenue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/revenue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$loglevel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/loglevel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$server$2d$zone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/server-zone.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$offline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/offline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$element$2d$interactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/element-interactions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$core$40$2$2e$48$2e$2$2f$node_modules$2f40$amplitude$2f$analytics$2d$core$2f$lib$2f$esm$2f$types$2f$config$2f$browser$2d$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-core@2.48.2/node_modules/@amplitude/analytics-core/lib/esm/types/config/browser-config.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_setDiagnosticsSampleRate",
    ()=>_setDiagnosticsSampleRate,
    "add",
    ()=>add,
    "extendSession",
    ()=>extendSession,
    "flush",
    ()=>flush,
    "getDeviceId",
    ()=>getDeviceId,
    "getIdentity",
    ()=>getIdentity,
    "getOptOut",
    ()=>getOptOut,
    "getSessionId",
    ()=>getSessionId,
    "getUserId",
    ()=>getUserId,
    "groupIdentify",
    ()=>groupIdentify,
    "identify",
    ()=>identify,
    "init",
    ()=>init,
    "logEvent",
    ()=>logEvent,
    "remove",
    ()=>remove,
    "reset",
    ()=>reset,
    "revenue",
    ()=>revenue,
    "setDeviceId",
    ()=>setDeviceId,
    "setGroup",
    ()=>setGroup,
    "setIdentity",
    ()=>setIdentity,
    "setOptOut",
    ()=>setOptOut,
    "setSessionId",
    ()=>setSessionId,
    "setTransport",
    ()=>setTransport,
    "setUserId",
    ()=>setUserId,
    "track",
    ()=>track
]);
/* eslint-disable @typescript-eslint/unbound-method */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/browser-client-factory.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@amplitude+analytics-browser@2.42.5/node_modules/@amplitude/analytics-browser/lib/esm/types.js [app-client] (ecmascript)");
;
;
var add = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].add, extendSession = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].extendSession, flush = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].flush, getDeviceId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getDeviceId, getIdentity = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getIdentity, getOptOut = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getOptOut, getSessionId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getSessionId, getUserId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getUserId, groupIdentify = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].groupIdentify, identify = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].identify, init = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].init, logEvent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].logEvent, remove = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].remove, reset = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].reset, revenue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].revenue, setDeviceId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setDeviceId, setGroup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setGroup, setIdentity = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setIdentity, setOptOut = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setOptOut, setSessionId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setSessionId, setTransport = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setTransport, setUserId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].setUserId, track = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].track, _setDiagnosticsSampleRate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$amplitude$2b$analytics$2d$browser$40$2$2e$42$2e$5$2f$node_modules$2f40$amplitude$2f$analytics$2d$browser$2f$lib$2f$esm$2f$browser$2d$client$2d$factory$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]._setDiagnosticsSampleRate;
;
;
;
;
;
;
}),
]);

//# sourceMappingURL=1u_0_%40amplitude_analytics-browser_lib_esm_06o0hin._.js.map