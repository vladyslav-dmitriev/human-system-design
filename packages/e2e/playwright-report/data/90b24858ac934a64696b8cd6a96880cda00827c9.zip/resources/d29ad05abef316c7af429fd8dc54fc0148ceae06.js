(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_web_0u22wp9._.js","static/chunks/0b3e_@amplitude_analytics-core_lib_esm_150er9h._.js","static/chunks/1u_0_@amplitude_analytics-browser_lib_esm_06o0hin._.js","static/chunks/0lzq_@amplitude_plugin-autocapture-browser_lib_esm_1nwk6qi._.js","static/chunks/node_modules__pnpm_1cpqu6k._.js"],
    source: "dynamic"
});
